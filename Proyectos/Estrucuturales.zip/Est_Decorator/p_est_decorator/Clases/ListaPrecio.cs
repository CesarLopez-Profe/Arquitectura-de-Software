using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_est_decorator.Clases
{
    public static class ListaPrecio
    {
        public static readonly uint sonido_bose = 8700000;
        public static readonly uint gps = 5000000;
        public static readonly uint silla_cuero = 6500000;
    }
}