using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_est_decorator.Interfaces
{
    public interface IAuto
    {
        string ObtenerDescripcion();
        uint ObtenerCosto();
    }
}