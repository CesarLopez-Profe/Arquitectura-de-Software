using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_est_decora_capas.Clases
{
    public static class Informacion
    {
        public static float  val_impto = 0.16f;
        
    }
}