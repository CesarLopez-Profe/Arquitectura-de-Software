using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_estr_facade.Clases
{
    public class AireAcondicionado
    {
        public void Encender()
        {
            Console.WriteLine("Aire acondicionado encendido.");
        }

        public void Apagar()
        {
            Console.WriteLine("Aire acondicionado apagado.");
        }
    }
}