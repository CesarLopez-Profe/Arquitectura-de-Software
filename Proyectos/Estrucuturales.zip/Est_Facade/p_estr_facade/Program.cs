﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using p_estr_facade.Clases;

AutoFacade miAutomovil = new AutoFacade();
miAutomovil.ArrancarAutomovil();
Console.WriteLine();
miAutomovil.DetenerAutomovil();