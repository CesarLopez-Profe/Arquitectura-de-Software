using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_estr_adapter.Clases
{
    public class AutoElectrico
    {
        public void EncenderSistemaElectrico()
        {
            Console.WriteLine("Auto eléctrico encendido.");
        }

        public void PresionarAcelerador()
        {
            Console.WriteLine("Acelerando auto eléctrico.");
        }
    }
}