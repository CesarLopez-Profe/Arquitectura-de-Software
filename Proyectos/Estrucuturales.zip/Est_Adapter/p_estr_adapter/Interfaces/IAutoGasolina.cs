using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_estr_adapter.Interfaces
{
    public interface IAutoGasolina
    {
        
        void EncenderMotor();
        void Acelerar();

    }
}