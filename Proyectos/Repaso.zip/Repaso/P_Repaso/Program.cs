﻿// See https://aka.ms/new-console-template for more information
using P_Repaso.Clases;

//Console.WriteLine("Hello, World!");

Vendedor vendedor = new Vendedor("98555222", "Juan Perez", 0.016f);

Cliente cliente = new Cliente("77744555", "Pedro Gomez", 0.02f);

Console.WriteLine(vendedor.Id);