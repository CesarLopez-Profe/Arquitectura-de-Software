using Microsoft.Extensions.DependencyInjection;
using Pagos.Adaptadores.Salida.Eventos;
using Pagos.Adaptadores.Salida.Pasarela;
using Pagos.Adaptadores.Salida.Pasarela.ProveedorFicticio;
using Pagos.Adaptadores.Salida.Persistencia;
using Pagos.Adaptadores.Salida.Sanciones;
using Pagos.Contracts;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Adaptadores.Salida.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Conecta cada puerto de salida con su adaptador. Empieza llamando al bloque de su lado
    /// (AgregarBloquesDeInfraestructura): BD propia, unidad de trabajo, outbox, cliente HTTP...
    /// </summary>
    public static IServiceCollection AgregarAdaptadoresDeSalidaPagos(
        this IServiceCollection services, EntornoDeSimulacion entorno, OpcionesDeMicroservicio opciones)
    {
        services.AgregarBloquesDeInfraestructura(entorno, opciones);

        // Persistencia
        services.AddScoped<IPagoRepository, RepositorioDePagos>();
        services.AddScoped<IGeneradorNumeroRecibo, GeneradorNumeroReciboDocumental>();

        // Sanciones (capa anticorrupción)
        services.AddScoped<IConsultaDeObligaciones, ConsultaDeObligacionesDeSanciones>();

        // Pasarela
        services.AddSingleton<FakePayClient>();
        services.AddScoped<IPasarelaDePagos, PasarelaFakePayAdapter>();

        // Eventos: registro EXPLÍCITO. El registro por convención (AgregarBloquesDeAplicacion)
        // solo recorre el ensamblado del núcleo, y los traductores ya no están allí.
        services.AddScoped<ITraductorDeEventoDeDominio, PagoConfirmadoTraductor>();
        services.AddScoped<ITraductorDeEventoDeDominio, PagoReversadoTraductor>();

        // Canales de salida: bus, auditoría y buzón de archivos (solo pagos.*). Pagos no tiene webhooks.
        services.AgregarCanalesDeSalida(canales => canales
            .ConBusDeEventos()
            .ConBitacoraDeAuditoria()
            .ConBuzonDeArchivos(PagosTopicos.Todos));

        return services;
    }
}
