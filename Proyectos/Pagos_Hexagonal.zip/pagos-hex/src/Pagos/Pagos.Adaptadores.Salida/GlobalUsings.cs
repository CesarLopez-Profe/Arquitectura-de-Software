// Espacios de nombres del BuildingBlock que usan los adaptadores de salida.
// Si en el repositorio tienen otro nombre, solo se ajusta este archivo.
global using Transito.BuildingBlocks.Domain;
global using Transito.BuildingBlocks.Application.Integracion;
global using Transito.BuildingBlocks.Infrastructure.Persistencia;
global using Transito.BuildingBlocks.Infrastructure.Serializacion;
global using Transito.BuildingBlocks.Infrastructure.Http;
global using Transito.BuildingBlocks.Infrastructure.Simulacion;
global using Transito.BuildingBlocks.Infrastructure.DependencyInjection;
