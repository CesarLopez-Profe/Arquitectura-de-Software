using Pagos.Contracts;
using Pagos.Nucleo.Dominio.Pagos.Eventos;

namespace Pagos.Adaptadores.Salida.Eventos;

/// <summary>PagoReversado (dominio) → PagoReversadoV1 (lenguaje publicado).</summary>
public sealed class PagoReversadoTraductor : TraductorDeEventoDeDominio<PagoReversado>
{
    protected override string Topico => PagosTopicos.PagoReversado;

    protected override object CrearContrato(PagoReversado evento) => new PagoReversadoV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.PagoId.Valor,
        evento.NumeroRecibo,
        evento.TipoObligacion.ToString(),
        evento.ObligacionId,
        evento.Monto,
        evento.Moneda,
        evento.Motivo);
}
