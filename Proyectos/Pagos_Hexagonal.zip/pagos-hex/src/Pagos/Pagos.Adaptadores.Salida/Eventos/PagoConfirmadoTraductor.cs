using Pagos.Contracts;
using Pagos.Nucleo.Dominio.Pagos.Eventos;

namespace Pagos.Adaptadores.Salida.Eventos;

/// <summary>
/// PagoConfirmado (dominio) → PagoConfirmadoV1 (lenguaje publicado).
/// Antes vivía en Pagos.Application/Integracion/Traductores; al moverlo aquí, el núcleo
/// deja de depender de Pagos.Contracts.
/// </summary>
public sealed class PagoConfirmadoTraductor : TraductorDeEventoDeDominio<PagoConfirmado>
{
    protected override string Topico => PagosTopicos.PagoConfirmado;

    protected override object CrearContrato(PagoConfirmado evento) => new PagoConfirmadoV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.PagoId.Valor,                 // tipo rico → primitivo
        evento.NumeroRecibo,
        evento.TipoObligacion.ToString(),    // enum → texto: cada consumidor filtra lo que le interesa
        evento.ObligacionId,
        evento.Monto,
        evento.Moneda,
        evento.ReferenciaTransaccion);
}
