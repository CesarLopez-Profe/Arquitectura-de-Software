using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Pagos.Estados;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Adaptadores.Salida.Persistencia;

/// <summary>
/// Adaptador de salida de IPagoRepository sobre la BD documental del BuildingBlock.
/// El algoritmo (memento → JSON → colección) lo pone RepositorioDocumentalBase (Template Method).
/// </summary>
public sealed class RepositorioDePagos(
    BaseDeDatosDocumental baseDeDatos,
    UnidadDeTrabajoDocumental unidadDeTrabajo,
    ISerializador serializador)
    : RepositorioDocumentalBase<Pago, PagoId, PagoMemento>(baseDeDatos, unidadDeTrabajo, serializador),
      IPagoRepository
{
    protected override string Coleccion => "pagos";

    protected override string ClaveDe(PagoId id) => id.Valor.ToString();

    public Task<Pago?> ObtenerAsync(PagoId id, CancellationToken cancellationToken) =>
        ObtenerPorIdAsync(id, cancellationToken);

    /// <summary>La pregunta "¿está activo?" se delega al objeto estado, no a un switch.</summary>
    public async Task<bool> ExistePagoActivoParaAsync(ReferenciaObligacion obligacion, CancellationToken cancellationToken)
    {
        var activos = await BuscarAsync(
            m => m.TipoObligacion == obligacion.Tipo
                 && m.ObligacionId == obligacion.Id
                 && EstadoDePago.Desde(m.Estado).EstaActivo,
            cancellationToken);

        return activos.Count > 0;
    }
}
