using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Adaptadores.Salida.Persistencia;

/// <summary>Adaptador de IGeneradorNumeroRecibo: consecutivo "recibos-AAAA" en la BD documental.</summary>
public sealed class GeneradorNumeroReciboDocumental(GeneradorDeConsecutivos consecutivos) : IGeneradorNumeroRecibo
{
    public Task<NumeroRecibo> SiguienteAsync(int anio, CancellationToken cancellationToken) =>
        Task.FromResult(NumeroRecibo.Generar(anio, consecutivos.Siguiente($"recibos-{anio}")));
}
