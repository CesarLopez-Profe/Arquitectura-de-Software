using Pagos.Nucleo.Dominio.Obligaciones;
using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Salida;
using Sanciones.Contracts;

namespace Pagos.Adaptadores.Salida.Sanciones;

/// <summary>
/// CAPA ANTICORRUPCIÓN (patrón Adapter). Es el ÚNICO lugar de Pagos que entiende el lenguaje
/// de Sanciones: pide la obligación por HTTP y traduce ObligacionDeSancionV1 → ObligacionPorPagar.
/// Si Sanciones publica un V2, solo cambia esta clase.
/// </summary>
public sealed class ConsultaDeObligacionesDeSanciones(IClienteHttp http, ISerializador serializador)
    : IConsultaDeObligaciones
{
    private const string HostSanciones = "sanciones";

    public async Task<ObligacionPorPagar?> ObtenerAsync(
        ReferenciaObligacion referencia, DateTimeOffset fechaPago, CancellationToken cancellationToken)
    {
        // Esta ACL solo sabe de sanciones. Otro tipo de obligación tendría su propia ACL.
        if (referencia.Tipo != TipoObligacion.Sancion)
            return null;

        var ruta = $"/api/sanciones/{referencia.Id}/obligacion?fechaPago={Uri.EscapeDataString(fechaPago.ToString("O"))}";

        // ClienteHttpConReintentos → ClienteHttpSimulado (Decorator + Proxy, del BuildingBlock):
        // reintenta los 5xx y propaga X-Correlation-Id.
        var respuesta = await http.EnviarAsync(SolicitudHttp.Get(HostSanciones, ruta), cancellationToken);

        // 404 → null: la regla ObligacionDebeExistir la aplica el dominio, no el adaptador.
        if (respuesta.CodigoDeEstado == 404)
            return null;

        if (respuesta.CodigoDeEstado != 200 || respuesta.Cuerpo is null)
            throw new InvalidOperationException(
                $"Sanciones respondió {respuesta.CodigoDeEstado} al consultar la obligación {referencia}.");

        var contrato = serializador.Deserializar<ObligacionDeSancionV1>(respuesta.Cuerpo);
        return Traducir(contrato, referencia);
    }

    /// <summary>El contrato externo nunca entra al núcleo: se traduce aquí, en la frontera.</summary>
    private static ObligacionPorPagar Traducir(ObligacionDeSancionV1 contrato, ReferenciaObligacion referencia) => new(
        referencia,
        Dinero.De(contrato.ValorAPagar, contrato.Moneda),
        contrato.AdmitePago,
        contrato.Descripcion);
}
