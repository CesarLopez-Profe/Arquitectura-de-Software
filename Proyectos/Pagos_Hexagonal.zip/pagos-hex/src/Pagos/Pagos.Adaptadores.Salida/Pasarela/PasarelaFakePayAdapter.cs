using Pagos.Adaptadores.Salida.Pasarela.ProveedorFicticio;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Adaptadores.Salida.Pasarela;

/// <summary>
/// ADAPTER: implementa el puerto IPasarelaDePagos hablando el idioma del SDK.
/// Traduce pesos ↔ centavos, "approved" ↔ booleano y códigos en inglés ↔ mensajes en español.
/// Cambiar de proveedor (Wompi, PayU, Stripe) = escribir otro adaptador como este.
/// </summary>
public sealed class PasarelaFakePayAdapter(FakePayClient cliente) : IPasarelaDePagos
{
    public async Task<ResultadoDeAutorizacion> AutorizarAsync(
        SolicitudDeAutorizacion solicitud, CancellationToken cancellationToken)
    {
        var respuesta = await cliente.ChargeAsync(new FakePayChargeRequest
        {
            IdempotencyKey = solicitud.PagoId.Valor.ToString(),     // PagoId = clave de idempotencia
            AmountInCents = ACentavos(solicitud.Monto.Monto),         // pesos → centavos
            Currency = solicitud.Monto.Moneda,
            CardToken = solicitud.TokenDePago,
            Description = solicitud.Descripcion
        }, cancellationToken);

        return respuesta.Status == FakePayChargeResponse.Approved
            ? ResultadoDeAutorizacion.Aprobar(respuesta.TransactionId!)
            : ResultadoDeAutorizacion.Rechazar(Traducir(respuesta.DeclineCode));
    }

    /// <summary>La conversión a centavos ocurre SOLO aquí. El dinero nunca usa double.</summary>
    private static long ACentavos(decimal pesos) =>
        (long)decimal.Round(pesos * 100m, 0, MidpointRounding.AwayFromZero);

    private static string Traducir(string? codigo) => codigo switch
    {
        "card_declined" => "La tarjeta fue rechazada por la entidad emisora",
        "amount_limit_exceeded" => "El monto supera el límite permitido por la pasarela",
        _ => "La pasarela no autorizó el pago"
    };
}
