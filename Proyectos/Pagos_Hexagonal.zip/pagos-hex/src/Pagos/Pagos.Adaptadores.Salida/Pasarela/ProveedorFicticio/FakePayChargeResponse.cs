namespace Pagos.Adaptadores.Salida.Pasarela.ProveedorFicticio;

/// <summary>Respuesta del SDK: Status = "approved" / "declined" y un código en inglés.</summary>
public sealed record FakePayChargeResponse
{
    public const string Approved = "approved";
    public const string Declined = "declined";

    public required string Status { get; init; }
    public string? TransactionId { get; init; }
    public string? DeclineCode { get; init; }
}
