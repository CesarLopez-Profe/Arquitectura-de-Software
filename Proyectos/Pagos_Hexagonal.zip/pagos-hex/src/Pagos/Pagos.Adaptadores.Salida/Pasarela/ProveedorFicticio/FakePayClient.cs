using System.Collections.Concurrent;

namespace Pagos.Adaptadores.Salida.Pasarela.ProveedorFicticio;

/// <summary>
/// "SDK de terceros" simulado. Rechaza tokens que contienen "decline" o "rechaz" y montos
/// superiores al límite. Respeta la clave de idempotencia: la misma clave devuelve la misma
/// respuesta, así un reintento nunca cobra dos veces. Se registra como singleton.
/// </summary>
public sealed class FakePayClient
{
    public const long LimitInCents = 1_000_000_000; // 10 millones de pesos

    private readonly ConcurrentDictionary<string, FakePayChargeResponse> _charges = new();

    public Task<FakePayChargeResponse> ChargeAsync(FakePayChargeRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        cancellationToken.ThrowIfCancellationRequested();

        var response = _charges.GetOrAdd(request.IdempotencyKey, _ => Process(request));
        return Task.FromResult(response);
    }

    private static FakePayChargeResponse Process(FakePayChargeRequest request)
    {
        var token = request.CardToken.ToLowerInvariant();

        if (token.Contains("decline") || token.Contains("rechaz"))
            return new FakePayChargeResponse { Status = FakePayChargeResponse.Declined, DeclineCode = "card_declined" };

        if (request.AmountInCents > LimitInCents)
            return new FakePayChargeResponse { Status = FakePayChargeResponse.Declined, DeclineCode = "amount_limit_exceeded" };

        var transactionId = "FP-" + Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();
        return new FakePayChargeResponse { Status = FakePayChargeResponse.Approved, TransactionId = transactionId };
    }
}
