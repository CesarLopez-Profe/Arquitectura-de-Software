namespace Pagos.Adaptadores.Salida.Pasarela.ProveedorFicticio;

/// <summary>Modelo del "SDK de terceros": en inglés y con montos en CENTAVOS, a propósito.</summary>
public sealed record FakePayChargeRequest
{
    public required string IdempotencyKey { get; init; }
    public required long AmountInCents { get; init; }
    public required string Currency { get; init; }
    public required string CardToken { get; init; }
    public string Description { get; init; } = string.Empty;
}
