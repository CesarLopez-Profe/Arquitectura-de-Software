using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Aplicacion.Modelos;

/// <summary>Modelo de lectura de un pago.</summary>
public sealed record PagoDto(
    Guid Id,
    string Recibo,
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string Metodo,
    string CorreoPagador,
    string Estado,
    DateTimeOffset FechaCreacion,
    DateTimeOffset? FechaConfirmacion,
    string? ReferenciaTransaccion,
    string? Observacion)
{
    internal static PagoDto Desde(Pago pago) => new(
        pago.Id.Valor,
        pago.Recibo.Valor,
        pago.Obligacion.Tipo.ToString(),
        pago.Obligacion.Id,
        pago.Monto.Monto,
        pago.Monto.Moneda,
        pago.Metodo.ToString(),
        pago.CorreoPagador.Valor,
        pago.Estado.ToString(),
        pago.FechaCreacion,
        pago.FechaConfirmacion,
        pago.ReferenciaTransaccion,
        pago.Observacion);
}
