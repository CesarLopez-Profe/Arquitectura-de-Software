using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Aplicacion.Modelos;

/// <summary>Respuesta de PagarObligacion. El agregado nunca sale del núcleo.</summary>
public sealed record ResultadoDePagoDto(
    Guid PagoId,
    string NumeroRecibo,
    string Estado,
    bool Aprobado,
    string? ReferenciaTransaccion,
    string? Motivo)
{
    internal static ResultadoDePagoDto Desde(Pago pago) => new(
        pago.Id.Valor,
        pago.Recibo.Valor,
        pago.Estado.ToString(),
        pago.Estado == EstadoPago.Confirmado,
        pago.ReferenciaTransaccion,
        pago.Observacion);
}
