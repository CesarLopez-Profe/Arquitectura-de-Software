using Pagos.Nucleo.Aplicacion.Modelos;
using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Servicios;
using Pagos.Nucleo.Puertos.Entrada;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Aplicacion.PagarObligacion;

/// <summary>
/// Caso de uso. Orquesta; no tiene reglas. Solo ve puertos: no sabe que la obligación viene
/// de Sanciones por HTTP, ni que la pasarela es FakePay, ni que la BD es JSON.
/// No hay "guardar": lo hace TransaccionComportamiento (BuildingBlocks) al terminar.
/// </summary>
public sealed class PagarObligacionManejador(
    ServicioDeCobro servicioDeCobro,
    IPagoRepository pagos,
    IPasarelaDePagos pasarela,
    IClock reloj) : IManejadorDeComando<PagarObligacionComando, ResultadoDePagoDto>
{
    public async Task<ResultadoDePagoDto> ManejarAsync(PagarObligacionComando comando, CancellationToken cancellationToken)
    {
        var ahora = reloj.Now;

        // primitivos → tipos del dominio
        var referencia = new ReferenciaObligacion(
            Enum.Parse<TipoObligacion>(comando.TipoObligacion, ignoreCase: true), comando.ObligacionId);
        var monto = Dinero.De(comando.Monto, comando.Moneda);
        var metodo = Enum.Parse<MetodoPago>(comando.MetodoPago, ignoreCase: true);
        var correo = CorreoElectronico.De(comando.CorreoPagador);

        // 1) reglas entre contextos + número de recibo
        var pago = await servicioDeCobro.IniciarPagoAsync(referencia, monto, metodo, correo, ahora, cancellationToken);

        // 2) el pago queda guardado aunque la pasarela lo rechace
        await pagos.AgregarAsync(pago, cancellationToken);

        // 3) autorizar con el proveedor, por el puerto de salida
        var resultado = await pasarela.AutorizarAsync(
            new SolicitudDeAutorizacion(pago.Id, pago.Monto, pago.Metodo, comando.TokenDePago, $"Pago {pago.Recibo.Valor}"),
            cancellationToken);

        // 4) el rechazo no es una excepción: es un resultado de negocio
        if (resultado.Aprobado)
            pago.Confirmar(resultado.ReferenciaTransaccion!, ahora);
        else
            pago.Rechazar(resultado.MotivoRechazo!, ahora);

        return ResultadoDePagoDto.Desde(pago);
    }
}
