using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Entrada;

namespace Pagos.Nucleo.Aplicacion.PagarObligacion;

/// <summary>Revisa la FORMA de la solicitud (400). Las reglas de negocio (422) están en el dominio.</summary>
public sealed class PagarObligacionValidador : ValidadorBase<PagarObligacionComando>
{
    protected override void DefinirReglas(PagarObligacionComando instancia, ColectorDeErrores errores) =>
        errores
            .EnumValido<TipoObligacion>(instancia.TipoObligacion, nameof(instancia.TipoObligacion))
            .NoVacio(instancia.ObligacionId, nameof(instancia.ObligacionId))
            .Positivo(instancia.Monto, nameof(instancia.Monto))
            .Cumple(instancia.Moneda is { Length: 3 } moneda && moneda.All(char.IsLetter),
                nameof(instancia.Moneda), "La moneda debe tener 3 letras (ISO 4217).")
            .EnumValido<MetodoPago>(instancia.MetodoPago, nameof(instancia.MetodoPago))
            .Requerido(instancia.TokenDePago, nameof(instancia.TokenDePago), 100)
            .Requerido(instancia.CorreoPagador, nameof(instancia.CorreoPagador), 150);
}
