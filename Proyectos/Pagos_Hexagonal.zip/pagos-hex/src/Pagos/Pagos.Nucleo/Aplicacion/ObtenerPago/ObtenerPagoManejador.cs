using Pagos.Nucleo.Aplicacion.Modelos;
using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Entrada;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Aplicacion.ObtenerPago;

public sealed class ObtenerPagoManejador(IPagoRepository pagos) : IManejadorDeConsulta<ObtenerPagoConsulta, PagoDto>
{
    public async Task<PagoDto> ManejarAsync(ObtenerPagoConsulta consulta, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(new PagoId(consulta.PagoId), cancellationToken)
                   ?? throw new RecursoNoEncontradoException("el pago", consulta.PagoId);

        return PagoDto.Desde(pago);
    }
}
