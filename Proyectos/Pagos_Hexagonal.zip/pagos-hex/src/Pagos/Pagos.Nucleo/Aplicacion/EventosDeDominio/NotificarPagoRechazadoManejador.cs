using Pagos.Nucleo.Dominio.Pagos.Eventos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Aplicacion.EventosDeDominio;

public sealed class NotificarPagoRechazadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoRechazado>
{
    protected override async Task AlOcurrirAsync(PagoRechazado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null)
            return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            $"PAGO RECHAZADO {evento.NumeroRecibo}",
            $"Su pago no fue autorizado: {evento.Motivo}.",
            CanalDeNotificacion.Email), cancellationToken);
    }
}
