using Pagos.Nucleo.Dominio.Pagos.Eventos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Aplicacion.EventosDeDominio;

/// <summary>
/// Observador: envía el recibo por correo. Comparte el alcance con la unidad de trabajo,
/// así que el mapa de identidad devuelve el mismo agregado sin volver a la BD.
/// </summary>
public sealed class NotificarPagoConfirmadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoConfirmado>
{
    protected override async Task AlOcurrirAsync(PagoConfirmado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null)
            return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            $"RECIBO DE PAGO {evento.NumeroRecibo}",
            $"Recibimos su pago de {evento.Monto:N0} {evento.Moneda}. Transacción {evento.ReferenciaTransaccion}.",
            CanalDeNotificacion.Email), cancellationToken);
    }
}
