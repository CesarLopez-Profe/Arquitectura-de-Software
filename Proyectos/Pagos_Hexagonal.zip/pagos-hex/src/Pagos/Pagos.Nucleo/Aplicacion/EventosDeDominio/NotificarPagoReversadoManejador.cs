using Pagos.Nucleo.Dominio.Pagos.Eventos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Aplicacion.EventosDeDominio;

public sealed class NotificarPagoReversadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoReversado>
{
    protected override async Task AlOcurrirAsync(PagoReversado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null)
            return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            $"PAGO REVERSADO {evento.NumeroRecibo}",
            $"Su pago de {evento.Monto:N0} {evento.Moneda} fue reversado: {evento.Motivo}.",
            CanalDeNotificacion.Email), cancellationToken);
    }
}
