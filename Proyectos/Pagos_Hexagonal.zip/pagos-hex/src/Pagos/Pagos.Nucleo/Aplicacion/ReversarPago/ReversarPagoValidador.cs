using Pagos.Nucleo.Puertos.Entrada;

namespace Pagos.Nucleo.Aplicacion.ReversarPago;

public sealed class ReversarPagoValidador : ValidadorBase<ReversarPagoComando>
{
    protected override void DefinirReglas(ReversarPagoComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.PagoId, nameof(instancia.PagoId))
            .Requerido(instancia.Motivo, nameof(instancia.Motivo), 300);
}
