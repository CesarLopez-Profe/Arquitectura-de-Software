using Pagos.Nucleo.Aplicacion.Modelos;

namespace Pagos.Nucleo.Puertos.Entrada;

/// <summary>
/// PUERTO DE ENTRADA. El comando dice QUÉ se le puede pedir a Pagos; la puerta es
/// <c>IMediador</c> (BuildingBlocks), que lo hace pasar por el pipeline:
/// registro → validación → transacción → manejador.
/// Llega con primitivos: traducirlos a tipos del dominio es trabajo del manejador.
/// </summary>
public sealed record PagarObligacionComando(
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string MetodoPago,
    string TokenDePago,
    string CorreoPagador) : IComando<ResultadoDePagoDto>;
