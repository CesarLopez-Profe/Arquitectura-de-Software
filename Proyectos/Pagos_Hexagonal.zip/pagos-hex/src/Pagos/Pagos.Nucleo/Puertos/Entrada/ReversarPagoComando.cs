namespace Pagos.Nucleo.Puertos.Entrada;

/// <summary>PUERTO DE ENTRADA. Compensación de la saga (idempotente).</summary>
public sealed record ReversarPagoComando(Guid PagoId, string Motivo) : IComando<Unidad>;
