using Pagos.Nucleo.Aplicacion.Modelos;

namespace Pagos.Nucleo.Puertos.Entrada;

/// <summary>PUERTO DE ENTRADA (lectura). Nunca abre transacción.</summary>
public sealed record ObtenerPagoConsulta(Guid PagoId) : IConsulta<PagoDto>;
