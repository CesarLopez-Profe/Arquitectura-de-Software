namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>Respuesta de la pasarela ya traducida. Se crea con los métodos fábrica.</summary>
public sealed record ResultadoDeAutorizacion
{
    private ResultadoDeAutorizacion(bool aprobado, string? referenciaTransaccion, string? motivoRechazo)
    {
        Aprobado = aprobado;
        ReferenciaTransaccion = referenciaTransaccion;
        MotivoRechazo = motivoRechazo;
    }

    public bool Aprobado { get; }
    public string? ReferenciaTransaccion { get; }
    public string? MotivoRechazo { get; }

    public static ResultadoDeAutorizacion Aprobar(string referenciaTransaccion)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(referenciaTransaccion);
        return new(true, referenciaTransaccion, null);
    }

    public static ResultadoDeAutorizacion Rechazar(string motivo)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(motivo);
        return new(false, null, motivo);
    }
}
