namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>
/// PUERTO DE SALIDA hacia el proveedor de pagos. Antes vivía en Pagos.Application/Puertos;
/// en la hexagonal queda junto a los otros tres: desaparece la distinción "puerto de dominio"
/// frente a "puerto de aplicación". Lo implementa Adaptadores.Salida/Pasarela.
/// </summary>
public interface IPasarelaDePagos
{
    Task<ResultadoDeAutorizacion> AutorizarAsync(SolicitudDeAutorizacion solicitud, CancellationToken cancellationToken);
}
