using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>Lo que el núcleo pide a la pasarela, en su propio idioma (pesos, nombres en español).</summary>
public sealed record SolicitudDeAutorizacion(
    PagoId PagoId,
    Dinero Monto,
    MetodoPago Metodo,
    string TokenDePago,
    string Descripcion);
