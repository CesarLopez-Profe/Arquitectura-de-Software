using Pagos.Nucleo.Dominio.Obligaciones;
using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>
/// PUERTO DE SALIDA hacia el contexto dueño de la obligación (hoy Sanciones).
/// Lo implementa la capa anticorrupción en Adaptadores.Salida/Sanciones.
/// Devuelve null si la obligación no existe.
/// </summary>
public interface IConsultaDeObligaciones
{
    Task<ObligacionPorPagar?> ObtenerAsync(
        ReferenciaObligacion referencia, DateTimeOffset fechaPago, CancellationToken cancellationToken);
}
