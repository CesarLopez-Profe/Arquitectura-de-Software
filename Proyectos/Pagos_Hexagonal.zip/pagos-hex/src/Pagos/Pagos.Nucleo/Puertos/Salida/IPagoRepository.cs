using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>PUERTO DE SALIDA: persistencia. Lo implementa Adaptadores.Salida/Persistencia.</summary>
public interface IPagoRepository
{
    Task AgregarAsync(Pago pago, CancellationToken cancellationToken);

    Task ActualizarAsync(Pago pago, CancellationToken cancellationToken);

    Task<Pago?> ObtenerAsync(PagoId id, CancellationToken cancellationToken);

    /// <summary>¿Hay un pago pendiente o confirmado para esta obligación?</summary>
    Task<bool> ExistePagoActivoParaAsync(ReferenciaObligacion obligacion, CancellationToken cancellationToken);
}
