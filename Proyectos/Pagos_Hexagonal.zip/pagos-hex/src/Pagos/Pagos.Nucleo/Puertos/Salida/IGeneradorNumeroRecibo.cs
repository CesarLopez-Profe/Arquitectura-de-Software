using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Puertos.Salida;

/// <summary>PUERTO DE SALIDA: consecutivo de recibos.</summary>
public interface IGeneradorNumeroRecibo
{
    Task<NumeroRecibo> SiguienteAsync(int anio, CancellationToken cancellationToken);
}
