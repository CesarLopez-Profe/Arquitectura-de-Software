using Microsoft.Extensions.DependencyInjection;
using Pagos.Nucleo.Dominio.Servicios;

namespace Pagos.Nucleo.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra el núcleo. Empieza llamando al bloque de su lado (AgregarBloquesDeAplicacion),
    /// que recorre ESTE ensamblado y registra por convención los 3 manejadores, los 2 validadores
    /// y los 3 observadores. Los traductores ya no están aquí: se fueron a Adaptadores.Salida.
    /// </summary>
    public static IServiceCollection AgregarNucleoPagos(this IServiceCollection services)
    {
        services.AgregarBloquesDeAplicacion(typeof(ServiceCollectionExtensions).Assembly);

        // Lo único que no sigue la convención: el servicio de dominio.
        services.AddScoped<ServicioDeCobro>();
        return services;
    }
}
