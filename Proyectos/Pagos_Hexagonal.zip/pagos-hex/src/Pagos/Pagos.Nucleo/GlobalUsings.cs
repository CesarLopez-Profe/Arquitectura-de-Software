// Espacios de nombres del BuildingBlock que usa el núcleo.
// Si en el repositorio tienen otro nombre, solo se ajusta este archivo.
global using Transito.BuildingBlocks.Domain;
global using Transito.BuildingBlocks.Application.Cqrs;
global using Transito.BuildingBlocks.Application.Validacion;
global using Transito.BuildingBlocks.Application.Excepciones;
global using Transito.BuildingBlocks.Application.Tiempo;
global using Transito.BuildingBlocks.Application.EventosDeDominio;
global using Transito.BuildingBlocks.Application.Notificaciones;
global using Transito.BuildingBlocks.Application.DependencyInjection;
