using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Dominio.Obligaciones;

/// <summary>
/// La vista que Pagos tiene de una deuda. Es un modelo PROPIO: el adaptador anticorrupción
/// traduce a este tipo el contrato del contexto dueño de la obligación.
/// </summary>
public sealed record ObligacionPorPagar
{
    public ObligacionPorPagar(ReferenciaObligacion referencia, Dinero valorAPagar, bool admitePago, string descripcion)
    {
        Referencia = Guard.NoNulo(referencia, "referencia de la obligación");
        ValorAPagar = Guard.NoNulo(valorAPagar, "valor a pagar");
        AdmitePago = admitePago;
        Descripcion = Guard.Texto(descripcion, "descripción de la obligación", 300);
    }

    public ReferenciaObligacion Referencia { get; }
    public Dinero ValorAPagar { get; }
    public bool AdmitePago { get; }
    public string Descripcion { get; }
}
