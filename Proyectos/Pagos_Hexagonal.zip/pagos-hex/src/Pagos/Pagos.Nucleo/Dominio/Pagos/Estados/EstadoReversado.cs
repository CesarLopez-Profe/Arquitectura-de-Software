namespace Pagos.Nucleo.Dominio.Pagos.Estados;

/// <summary>Estado final: no permite nada.</summary>
public sealed class EstadoReversado : EstadoDePago
{
    internal EstadoReversado() { }

    public override EstadoPago Codigo => EstadoPago.Reversado;
    public override bool EstaActivo => false;

    private protected override EstadoDePago? Siguiente(OperacionDePago operacion) => null;
}
