namespace Pagos.Nucleo.Dominio.Pagos.Estados;

/// <summary>Estado final: no permite nada.</summary>
public sealed class EstadoRechazado : EstadoDePago
{
    internal EstadoRechazado() { }

    public override EstadoPago Codigo => EstadoPago.Rechazado;
    public override bool EstaActivo => false;

    private protected override EstadoDePago? Siguiente(OperacionDePago operacion) => null;
}
