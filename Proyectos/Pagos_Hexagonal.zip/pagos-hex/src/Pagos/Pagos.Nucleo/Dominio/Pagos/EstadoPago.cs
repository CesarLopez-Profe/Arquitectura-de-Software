namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>
/// Solo el CÓDIGO del estado, para mostrar y persistir.
/// El comportamiento vive en los objetos de <c>Estados/</c> (patrón State).
/// </summary>
public enum EstadoPago
{
    Pendiente = 1,
    Confirmado = 2,
    Rechazado = 3,
    Reversado = 4
}
