namespace Pagos.Nucleo.Dominio.Pagos;

public enum MetodoPago
{
    TarjetaCredito = 1,
    TarjetaDebito = 2,
    Pse = 3
}
