using Pagos.Nucleo.Dominio.Pagos.Estados;

namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

/// <summary>La regla no decide: le pregunta al objeto estado.</summary>
public sealed class PagoDebePermitirLaOperacion(EstadoDePago estado, OperacionDePago operacion) : IBusinessRule
{
    public bool IsBroken() => !estado.Permite(operacion);

    public string Message => $"Un pago en estado {estado.Codigo} no permite la operación {operacion}.";
}
