using Pagos.Nucleo.Dominio.Obligaciones;

namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

public sealed class ObligacionDebeAdmitirPago(ObligacionPorPagar obligacion) : IBusinessRule
{
    public bool IsBroken() => !obligacion.AdmitePago;

    public string Message => $"La obligación {obligacion.Referencia} no admite pagos ({obligacion.Descripcion}).";
}
