namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>Operaciones que cambian el estado de un pago.</summary>
public enum OperacionDePago
{
    Confirmar = 1,
    Rechazar = 2,
    Reversar = 3
}
