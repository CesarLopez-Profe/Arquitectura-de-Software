namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>Qué clase de obligación se paga. Hoy solo sanciones; mañana, trámites.</summary>
public enum TipoObligacion
{
    Sancion = 1
}
