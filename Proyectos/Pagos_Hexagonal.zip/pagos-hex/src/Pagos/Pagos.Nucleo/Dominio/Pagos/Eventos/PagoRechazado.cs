namespace Pagos.Nucleo.Dominio.Pagos.Eventos;

/// <summary>Solo interesa dentro de Pagos (se notifica al pagador). No se publica.</summary>
public sealed record PagoRechazado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    string NumeroRecibo,
    string Motivo) : DomainEvent(OcurrioEn);
