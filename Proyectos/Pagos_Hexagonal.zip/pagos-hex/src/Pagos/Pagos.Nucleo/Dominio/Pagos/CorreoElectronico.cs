using System.Text.RegularExpressions;

namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>Correo del pagador, donde se envía el recibo. Se guarda en minúsculas.</summary>
public sealed partial record CorreoElectronico
{
    private readonly string _valor = string.Empty;

    private CorreoElectronico(string valor) => Valor = valor;

    public string Valor
    {
        get => _valor;
        private init
        {
            var normalizado = Guard.Texto(value, "correo electrónico", 150).Trim().ToLowerInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un correo electrónico válido.");
            _valor = normalizado;
        }
    }

    public static CorreoElectronico De(string valor) => new(valor);

    public override string ToString() => Valor;

    [GeneratedRegex(@"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$")]
    private static partial Regex Formato();
}
