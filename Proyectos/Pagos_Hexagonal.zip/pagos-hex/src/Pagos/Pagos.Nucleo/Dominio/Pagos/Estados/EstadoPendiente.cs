namespace Pagos.Nucleo.Dominio.Pagos.Estados;

/// <summary>Permite Confirmar y Rechazar. Está activo.</summary>
public sealed class EstadoPendiente : EstadoDePago
{
    internal EstadoPendiente() { }

    public override EstadoPago Codigo => EstadoPago.Pendiente;
    public override bool EstaActivo => true;

    private protected override EstadoDePago? Siguiente(OperacionDePago operacion) => operacion switch
    {
        OperacionDePago.Confirmar => Confirmado,
        OperacionDePago.Rechazar => Rechazado,
        _ => null
    };
}
