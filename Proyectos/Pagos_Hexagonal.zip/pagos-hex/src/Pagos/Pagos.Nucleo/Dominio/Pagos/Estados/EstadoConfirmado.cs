namespace Pagos.Nucleo.Dominio.Pagos.Estados;

/// <summary>Solo permite Reversar. Está activo.</summary>
public sealed class EstadoConfirmado : EstadoDePago
{
    internal EstadoConfirmado() { }

    public override EstadoPago Codigo => EstadoPago.Confirmado;
    public override bool EstaActivo => true;

    private protected override EstadoDePago? Siguiente(OperacionDePago operacion) =>
        operacion == OperacionDePago.Reversar ? Reversado : null;
}
