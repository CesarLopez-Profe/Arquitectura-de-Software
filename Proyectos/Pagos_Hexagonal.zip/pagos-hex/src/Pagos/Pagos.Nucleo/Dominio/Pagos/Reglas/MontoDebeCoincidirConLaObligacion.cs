using Pagos.Nucleo.Dominio.Obligaciones;

namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

public sealed class MontoDebeCoincidirConLaObligacion(Dinero monto, ObligacionPorPagar obligacion) : IBusinessRule
{
    public bool IsBroken() => monto != obligacion.ValorAPagar;

    public string Message =>
        $"El monto {monto.Monto:N2} {monto.Moneda} no coincide con el valor a pagar " +
        $"{obligacion.ValorAPagar.Monto:N2} {obligacion.ValorAPagar.Moneda}.";
}
