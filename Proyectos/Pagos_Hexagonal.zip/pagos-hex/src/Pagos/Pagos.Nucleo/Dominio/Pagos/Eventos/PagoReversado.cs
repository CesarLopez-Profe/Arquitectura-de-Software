namespace Pagos.Nucleo.Dominio.Pagos.Eventos;

/// <summary>Se publica fuera como PagoReversadoV1 (lo traduce un adaptador de salida).</summary>
public sealed record PagoReversado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    string NumeroRecibo,
    TipoObligacion TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string Motivo) : DomainEvent(OcurrioEn);
