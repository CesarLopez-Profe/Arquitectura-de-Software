using Pagos.Nucleo.Dominio.Pagos.Estados;
using Pagos.Nucleo.Dominio.Pagos.Eventos;
using Pagos.Nucleo.Dominio.Pagos.Reglas;

namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>
/// Raíz de agregado. Su ciclo de vida lo gobierna el patrón State: no hay switch sobre un enum.
/// Este archivo es idéntico al de Pagos.Domain; solo cambia el namespace.
/// </summary>
public sealed class Pago : AggregateRoot<PagoId>, IOriginador<Pago, PagoMemento>
{
    private EstadoDePago _estado = EstadoDePago.Pendiente;
    private NumeroRecibo? _recibo;
    private ReferenciaObligacion? _obligacion;
    private Dinero? _monto;
    private MetodoPago _metodo;
    private CorreoElectronico? _correoPagador;
    private DateTimeOffset _fechaCreacion;
    private DateTimeOffset? _fechaConfirmacion;
    private string? _referenciaTransaccion;
    private string? _observacion;

    private Pago(PagoId id) : base(id) { }

    // ---------------------------------------------------------------- propiedades encapsuladas

    public NumeroRecibo Recibo
    {
        get => Guard.Inicializado(_recibo, nameof(Recibo));
        private set => _recibo = Guard.NoNulo(value, "número de recibo");
    }

    public ReferenciaObligacion Obligacion
    {
        get => Guard.Inicializado(_obligacion, nameof(Obligacion));
        private set => _obligacion = Guard.NoNulo(value, "obligación");
    }

    public Dinero Monto
    {
        get => Guard.Inicializado(_monto, nameof(Monto));
        private set => _monto = Guard.NoNulo(value, "monto");
    }

    public MetodoPago Metodo
    {
        get => _metodo;
        private set => _metodo = Guard.Definido(value, "método de pago");
    }

    public CorreoElectronico CorreoPagador
    {
        get => Guard.Inicializado(_correoPagador, nameof(CorreoPagador));
        private set => _correoPagador = Guard.NoNulo(value, "correo del pagador");
    }

    public DateTimeOffset FechaCreacion
    {
        get => _fechaCreacion;
        private set => _fechaCreacion = Guard.FechaValida(value, "fecha de creación");
    }

    public DateTimeOffset? FechaConfirmacion
    {
        get => _fechaConfirmacion;
        private set
        {
            if (value is { } fecha && fecha < FechaCreacion)
                throw new DomainException("La fecha de confirmación no puede ser anterior a la creación del pago.");
            _fechaConfirmacion = value;
        }
    }

    public string? ReferenciaTransaccion
    {
        get => _referenciaTransaccion;
        private set => _referenciaTransaccion = Guard.TextoOpcional(value, "referencia de la transacción", 60);
    }

    public string? Observacion
    {
        get => _observacion;
        private set => _observacion = Guard.TextoOpcional(value, "observación", 300);
    }

    /// <summary>Solo lectura: deriva del objeto estado.</summary>
    public EstadoPago Estado => _estado.Codigo;

    public bool EstaActivo => _estado.EstaActivo;

    public bool Permite(OperacionDePago operacion) => _estado.Permite(operacion);

    // ---------------------------------------------------------------- comportamiento

    /// <summary>
    /// Factory Method. Es <c>internal</c>: un pago solo nace a través de <c>ServicioDeCobro</c>,
    /// que verifica las reglas que dependen de la obligación y de los demás pagos.
    /// </summary>
    internal static Pago Iniciar(
        PagoId id,
        NumeroRecibo recibo,
        ReferenciaObligacion obligacion,
        Dinero monto,
        MetodoPago metodo,
        CorreoElectronico correoPagador,
        DateTimeOffset ahora)
    {
        CheckRule(new MontoDelPagoDebeSerPositivo(monto));

        var pago = new Pago(id)
        {
            Recibo = recibo,
            Obligacion = obligacion,
            Monto = monto,
            Metodo = metodo,
            CorreoPagador = correoPagador,
            FechaCreacion = ahora
        };

        pago.Raise(new PagoIniciado(ahora, id, recibo.Valor, obligacion.Tipo, obligacion.Id, monto.Monto, monto.Moneda));
        return pago;
    }

    public void Confirmar(string referenciaTransaccion, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Confirmar);              // 1. regla (consulta al estado)
        ReferenciaTransaccion = Guard.Texto(referenciaTransaccion, "referencia de la transacción", 60); // 2. datos
        FechaConfirmacion = ahora;
        TransicionarCon(OperacionDePago.Confirmar);                   // 3. al final, el estado

        Raise(new PagoConfirmado(
            ahora, Id, Recibo.Valor, Obligacion.Tipo, Obligacion.Id, Monto.Monto, Monto.Moneda, ReferenciaTransaccion));
    }

    public void Rechazar(string motivo, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Rechazar);
        Observacion = Guard.Texto(motivo, "motivo del rechazo", 300);
        TransicionarCon(OperacionDePago.Rechazar);

        Raise(new PagoRechazado(ahora, Id, Recibo.Valor, Observacion));
    }

    /// <summary>Compensación de la saga: devuelve un pago confirmado que el negocio no pudo aplicar.</summary>
    public void Reversar(string motivo, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Reversar);
        Observacion = Guard.Texto(motivo, "motivo de la reversión", 300);
        TransicionarCon(OperacionDePago.Reversar);

        Raise(new PagoReversado(
            ahora, Id, Recibo.Valor, Obligacion.Tipo, Obligacion.Id, Monto.Monto, Monto.Moneda, Observacion));
    }

    private void VerificarQuePermite(OperacionDePago operacion) =>
        CheckRule(new PagoDebePermitirLaOperacion(_estado, operacion));

    private void TransicionarCon(OperacionDePago operacion) => _estado = _estado.Aplicar(operacion);

    // ---------------------------------------------------------------- Memento

    public PagoMemento CrearMemento() => new(
        Id.Valor, Recibo.Valor, Obligacion.Tipo, Obligacion.Id, Monto.Monto, Monto.Moneda, Metodo,
        CorreoPagador.Valor, Estado, FechaCreacion, FechaConfirmacion, ReferenciaTransaccion, Observacion);

    /// <summary>Reconstruye el pago pasando por los mismos setters validados.</summary>
    public static Pago RestaurarDesde(PagoMemento memento) => new(new PagoId(memento.Id))
    {
        Recibo = NumeroRecibo.De(memento.Recibo),
        Obligacion = new ReferenciaObligacion(memento.TipoObligacion, memento.ObligacionId),
        Monto = Dinero.De(memento.Monto, memento.Moneda),
        Metodo = memento.Metodo,
        CorreoPagador = CorreoElectronico.De(memento.CorreoPagador),
        FechaCreacion = memento.FechaCreacion,
        FechaConfirmacion = memento.FechaConfirmacion,
        ReferenciaTransaccion = memento.ReferenciaTransaccion,
        Observacion = memento.Observacion,
        _estado = EstadoDePago.Desde(memento.Estado)
    };
}
