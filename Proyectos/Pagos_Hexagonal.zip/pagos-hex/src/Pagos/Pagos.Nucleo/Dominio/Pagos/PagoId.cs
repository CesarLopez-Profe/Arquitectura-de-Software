namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>Identidad del pago. Guid no vacío; el getter detecta un <c>default(PagoId)</c>.</summary>
public readonly record struct PagoId
{
    private readonly Guid _valor;

    public PagoId(Guid valor) => _valor = Guard.NoVacio(valor, "identificador del pago");

    public Guid Valor => _valor != Guid.Empty
        ? _valor
        : throw new InvalidOperationException("Se leyó un PagoId sin inicializar.");

    public static PagoId Nuevo() => new(Guid.NewGuid());

    public override string ToString() => Valor.ToString();
}
