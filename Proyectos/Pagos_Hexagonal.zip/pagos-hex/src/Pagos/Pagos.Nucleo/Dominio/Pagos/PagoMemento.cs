namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>
/// Memento: instantánea del pago con tipos primitivos. El estado se guarda como código
/// (<see cref="EstadoPago"/>) y se restaura con <c>EstadoDePago.Desde</c>.
/// </summary>
public sealed record PagoMemento(
    Guid Id,
    string Recibo,
    TipoObligacion TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    MetodoPago Metodo,
    string CorreoPagador,
    EstadoPago Estado,
    DateTimeOffset FechaCreacion,
    DateTimeOffset? FechaConfirmacion,
    string? ReferenciaTransaccion,
    string? Observacion);
