namespace Pagos.Nucleo.Dominio.Pagos.Eventos;

/// <summary>Se publica fuera como PagoConfirmadoV1 (lo traduce un adaptador de salida).</summary>
public sealed record PagoConfirmado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    string NumeroRecibo,
    TipoObligacion TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string ReferenciaTransaccion) : DomainEvent(OcurrioEn);
