namespace Pagos.Nucleo.Dominio.Pagos.Estados;

/// <summary>
/// Patrón State. Cada estado sabe qué operaciones permite y a qué estado lleva cada una.
/// Los estados no guardan datos: una sola instancia de cada uno sirve para todos los pagos
/// (Singleton / Flyweight). El constructor es <c>private protected</c>: nadie fuera del
/// ensamblado puede inventar estados.
/// </summary>
public abstract class EstadoDePago
{
    public static readonly EstadoDePago Pendiente = new EstadoPendiente();
    public static readonly EstadoDePago Confirmado = new EstadoConfirmado();
    public static readonly EstadoDePago Rechazado = new EstadoRechazado();
    public static readonly EstadoDePago Reversado = new EstadoReversado();

    private protected EstadoDePago() { }

    public abstract EstadoPago Codigo { get; }

    /// <summary>Un pago activo impide iniciar otro para la misma obligación.</summary>
    public abstract bool EstaActivo { get; }

    public bool Permite(OperacionDePago operacion) => Siguiente(operacion) is not null;

    public EstadoDePago Aplicar(OperacionDePago operacion) =>
        Siguiente(operacion)
        ?? throw new InvalidOperationException($"El estado {Codigo} no permite la operación {operacion}.");

    /// <summary>Estado al que lleva la operación, o null si no la permite.</summary>
    private protected abstract EstadoDePago? Siguiente(OperacionDePago operacion);

    /// <summary>Factory Method: reconstruye el objeto estado desde el código persistido.</summary>
    public static EstadoDePago Desde(EstadoPago codigo) => codigo switch
    {
        EstadoPago.Pendiente => Pendiente,
        EstadoPago.Confirmado => Confirmado,
        EstadoPago.Rechazado => Rechazado,
        EstadoPago.Reversado => Reversado,
        _ => throw new DomainException($"'{codigo}' no es un estado de pago válido.")
    };

    public override string ToString() => Codigo.ToString();
}
