namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>
/// Lo que se paga, visto desde Pagos: tipo + Id. Pagos no conoce la sanción,
/// así puede cobrar otros conceptos sin cambiar el agregado.
/// </summary>
public sealed record ReferenciaObligacion
{
    private readonly TipoObligacion _tipo;
    private readonly Guid _id;

    public ReferenciaObligacion(TipoObligacion tipo, Guid id)
    {
        Tipo = tipo;
        Id = id;
    }

    public TipoObligacion Tipo
    {
        get => _tipo;
        private init => _tipo = Guard.Definido(value, "tipo de obligación");
    }

    public Guid Id
    {
        get => _id;
        private init => _id = Guard.NoVacio(value, "identificador de la obligación");
    }

    public override string ToString() => $"{Tipo}:{Id}";
}
