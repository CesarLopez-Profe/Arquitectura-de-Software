namespace Pagos.Nucleo.Dominio.Pagos.Eventos;

public sealed record PagoIniciado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    string NumeroRecibo,
    TipoObligacion TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda) : DomainEvent(OcurrioEn);
