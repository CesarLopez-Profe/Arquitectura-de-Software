namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

public sealed class NoDebeExistirOtroPagoActivo(bool existePagoActivo, ReferenciaObligacion referencia) : IBusinessRule
{
    public bool IsBroken() => existePagoActivo;

    public string Message => $"Ya existe un pago pendiente o confirmado para la obligación {referencia}.";
}
