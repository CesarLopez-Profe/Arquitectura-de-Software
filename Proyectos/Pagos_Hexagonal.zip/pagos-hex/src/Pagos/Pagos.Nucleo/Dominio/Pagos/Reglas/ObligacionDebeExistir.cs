using Pagos.Nucleo.Dominio.Obligaciones;

namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

public sealed class ObligacionDebeExistir(ObligacionPorPagar? obligacion, ReferenciaObligacion referencia) : IBusinessRule
{
    public bool IsBroken() => obligacion is null;

    public string Message => $"No existe la obligación {referencia}.";
}
