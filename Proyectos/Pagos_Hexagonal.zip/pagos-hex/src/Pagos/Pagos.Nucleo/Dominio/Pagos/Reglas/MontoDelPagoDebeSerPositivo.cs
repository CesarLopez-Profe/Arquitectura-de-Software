namespace Pagos.Nucleo.Dominio.Pagos.Reglas;

public sealed class MontoDelPagoDebeSerPositivo(Dinero monto) : IBusinessRule
{
    public bool IsBroken() => monto.Monto <= 0m;

    public string Message => "El monto del pago debe ser mayor que cero.";
}
