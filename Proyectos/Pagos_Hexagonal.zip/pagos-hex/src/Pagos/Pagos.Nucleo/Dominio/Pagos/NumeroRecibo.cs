using System.Text.RegularExpressions;

namespace Pagos.Nucleo.Dominio.Pagos;

/// <summary>Número de recibo con formato REC-AAAA-NNN.</summary>
public sealed partial record NumeroRecibo
{
    private readonly string _valor = string.Empty;

    private NumeroRecibo(string valor) => Valor = valor;

    public string Valor
    {
        get => _valor;
        private init
        {
            var normalizado = Guard.Texto(value, "número de recibo", 30).Trim().ToUpperInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un número de recibo válido (REC-AAAA-NNN).");
            _valor = normalizado;
        }
    }

    public static NumeroRecibo De(string valor) => new(valor);

    /// <summary>Factory Method: arma el número a partir del año y el consecutivo.</summary>
    public static NumeroRecibo Generar(int anio, long consecutivo) => new($"REC-{anio:D4}-{consecutivo:D3}");

    public override string ToString() => Valor;

    [GeneratedRegex(@"^REC-\d{4}-\d{3,}$")]
    private static partial Regex Formato();
}
