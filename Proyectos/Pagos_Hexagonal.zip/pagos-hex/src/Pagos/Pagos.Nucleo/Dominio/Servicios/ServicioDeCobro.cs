using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Pagos.Reglas;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Dominio.Servicios;

/// <summary>
/// Servicio de dominio: reglas que cruzan agregados y contextos. Solo depende de puertos de
/// salida (que ahora viven en el mismo núcleo), así que se prueba con dobles en memoria.
/// </summary>
public sealed class ServicioDeCobro(
    IConsultaDeObligaciones obligaciones,
    IPagoRepository pagos,
    IGeneradorNumeroRecibo generadorDeRecibos)
{
    public async Task<Pago> IniciarPagoAsync(
        ReferenciaObligacion referencia,
        Dinero monto,
        MetodoPago metodo,
        CorreoElectronico correoPagador,
        DateTimeOffset ahora,
        CancellationToken cancellationToken)
    {
        var obligacion = await obligaciones.ObtenerAsync(referencia, ahora, cancellationToken);

        BusinessRules.Check(new ObligacionDebeExistir(obligacion, referencia));
        BusinessRules.Check(new ObligacionDebeAdmitirPago(obligacion!));
        BusinessRules.Check(new MontoDebeCoincidirConLaObligacion(monto, obligacion!));

        var existeActivo = await pagos.ExistePagoActivoParaAsync(referencia, cancellationToken);
        BusinessRules.Check(new NoDebeExistirOtroPagoActivo(existeActivo, referencia));

        var recibo = await generadorDeRecibos.SiguienteAsync(ahora.Year, cancellationToken);

        return Pago.Iniciar(PagoId.Nuevo(), recibo, referencia, monto, metodo, correoPagador, ahora);
    }
}
