using Pagos.Nucleo.Puertos.Entrada;

namespace Pagos.Adaptadores.Entrada.Http;

/// <summary>
/// ADAPTADOR PRIMARIO HTTP. Traduce la petición a un comando y lo entrega por el puerto de
/// entrada (contexto.Mediador). Los errores (400, 404, 422) los traduce el middleware del
/// BuildingBlock; aquí solo se decide entre 201 y 402.
/// </summary>
public sealed class PagosEndpoints : IModuloDeEndpoints
{
    public void Mapear(EnrutadorHttp enrutador) => enrutador
        .MapearPost("/api/pagos", PagarAsync)
        .MapearGet("/api/pagos/{id}", ObtenerAsync);

    private static async Task<RespuestaHttp> PagarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var solicitud = contexto.LeerCuerpo<PagarObligacionSolicitud>();

        var resultado = await contexto.Mediador.EnviarAsync(new PagarObligacionComando(
            solicitud.TipoObligacion,
            solicitud.ObligacionId,
            solicitud.Monto,
            solicitud.Moneda,
            solicitud.MetodoPago,
            solicitud.TokenDePago,
            solicitud.CorreoPagador), cancellationToken);

        // 201 confirmado; 402 Payment Required si la pasarela rechazó (el pago rechazado SÍ quedó guardado)
        return resultado.Aprobado
            ? Resultados.Creado($"/api/pagos/{resultado.PagoId}", resultado)
            : Resultados.Problema(402, "Pago rechazado por la pasarela", resultado.Motivo);
    }

    private static async Task<RespuestaHttp> ObtenerAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var pago = await contexto.Mediador.EnviarAsync(
            new ObtenerPagoConsulta(contexto.ParametroGuid("id")), cancellationToken);

        return Resultados.Ok(pago);
    }
}
