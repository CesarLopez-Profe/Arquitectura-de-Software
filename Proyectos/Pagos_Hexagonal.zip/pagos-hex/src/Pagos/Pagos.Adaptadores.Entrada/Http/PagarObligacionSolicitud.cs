namespace Pagos.Adaptadores.Entrada.Http;

/// <summary>Cuerpo JSON de POST /api/pagos.</summary>
public sealed record PagarObligacionSolicitud(
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string MetodoPago,
    string TokenDePago,
    string CorreoPagador);
