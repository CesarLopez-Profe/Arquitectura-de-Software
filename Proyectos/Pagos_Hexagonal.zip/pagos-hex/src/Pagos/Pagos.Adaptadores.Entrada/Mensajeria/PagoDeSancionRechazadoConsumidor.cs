using Pagos.Nucleo.Puertos.Entrada;
using Sanciones.Contracts;

namespace Pagos.Adaptadores.Entrada.Mensajeria;

/// <summary>
/// ADAPTADOR PRIMARIO DE MENSAJERÍA. Paso de compensación de la saga: recibe
/// PagoDeSancionRechazadoV1 y entrega ReversarPagoComando por el mismo puerto que usa HTTP.
/// La bandeja de entrada del BuildingBlock lo hace idempotente (Idempotent Consumer).
/// </summary>
public sealed class PagoDeSancionRechazadoConsumidor(IMediador mediador)
    : IManejadorDeEventoDeIntegracion<PagoDeSancionRechazadoV1>
{
    public Task ManejarAsync(
        PagoDeSancionRechazadoV1 mensaje, ContextoDeMensaje contexto, CancellationToken cancellationToken) =>
        mediador.EnviarAsync(new ReversarPagoComando(mensaje.PagoId, mensaje.Motivo), cancellationToken);
}
