using Microsoft.Extensions.DependencyInjection;
using Pagos.Adaptadores.Entrada.Http;
using Pagos.Adaptadores.Entrada.Mensajeria;
using Sanciones.Contracts;

namespace Pagos.Adaptadores.Entrada.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>Registra los dos adaptadores que conducen a Pagos: HTTP y el bus de eventos.</summary>
    public static IServiceCollection AgregarAdaptadoresDeEntradaPagos(this IServiceCollection services)
    {
        // HTTP
        services
            .AgregarApiSimulada()
            .AgregarModuloDeEndpoints<PagosEndpoints>();

        // Mensajería
        services.AgregarConsumidor<PagoDeSancionRechazadoV1, PagoDeSancionRechazadoConsumidor>(
            SancionesTopicos.PagoDeSancionRechazado);

        return services;
    }
}
