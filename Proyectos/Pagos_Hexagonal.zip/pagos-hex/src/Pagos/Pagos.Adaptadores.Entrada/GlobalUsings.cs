// Espacios de nombres del BuildingBlock que usan los adaptadores de entrada.
// Si en el repositorio tienen otro nombre, solo se ajusta este archivo.
global using Transito.BuildingBlocks.Application.Cqrs;
global using Transito.BuildingBlocks.Application.Integracion;
global using Transito.BuildingBlocks.Infrastructure.Http;
global using Transito.BuildingBlocks.Infrastructure.DependencyInjection;
global using Transito.BuildingBlocks.Api;
global using Transito.BuildingBlocks.Api.DependencyInjection;
