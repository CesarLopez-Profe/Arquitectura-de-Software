using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Pagos.Adaptadores.Entrada.DependencyInjection;
using Pagos.Adaptadores.Salida.DependencyInjection;
using Pagos.Nucleo.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Pagos.Host;

/// <summary>
/// Composition root de Pagos: contenedor propio, base de datos propia y validación del
/// contenedor al arrancar. Lo único que cambia frente a la versión Clean son las tres líneas
/// de registro: ahora se agrupan por LADO del hexágono (núcleo, salida, entrada) y no por capa.
/// </summary>
public static class MicroservicioPagos
{
    public const string Nombre = "pagos";

    public static IHost Crear(EntornoDeSimulacion entorno)
    {
        var constructor = Microsoft.Extensions.Hosting.Host.CreateEmptyApplicationBuilder(
            new HostApplicationBuilderSettings { ApplicationName = Nombre });

        constructor.Services
            .AgregarNucleoPagos()                                                               // núcleo
            .AgregarAdaptadoresDeSalidaPagos(entorno, new OpcionesDeMicroservicio { Nombre = Nombre }) // lo que Pagos conduce
            .AgregarAdaptadoresDeEntradaPagos();                                                // lo que conduce a Pagos

        // Mismo contenedor y mismas validaciones al arrancar que hoy.
        constructor.ConfigureContainer(new DefaultServiceProviderFactory(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        }));

        return constructor.Build();
    }
}
