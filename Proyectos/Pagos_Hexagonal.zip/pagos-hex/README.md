# Pagos hexagonal: código refactorizado

Refactor del microservicio **Pagos** de Clean Architecture a **arquitectura hexagonal** (puertos y adaptadores).
El dominio, las reglas y los casos de uso **no cambian de lógica**: se mueven de proyecto y de namespace.
`BuildingBlocks`, `Sanciones`, `Licencias` y `Pagos.Contracts` **no se tocan**.

## Qué contiene

```
src/Pagos/
├─ Pagos.Nucleo/                     ← el hexágono (antes Pagos.Domain + casos de uso de Pagos.Application)
│  ├─ Dominio/
│  │  ├─ Pagos/                      Pago, PagoId, NumeroRecibo, CorreoElectronico, ReferenciaObligacion,
│  │  │  │                           PagoMemento y los 4 enums
│  │  │  ├─ Estados/                 EstadoDePago + 4 estados (State, Singleton/Flyweight)
│  │  │  ├─ Eventos/                 PagoIniciado, PagoConfirmado, PagoRechazado, PagoReversado
│  │  │  └─ Reglas/                  las 6 reglas
│  │  ├─ Obligaciones/               ObligacionPorPagar
│  │  └─ Servicios/                  ServicioDeCobro
│  ├─ Aplicacion/                    manejadores, validadores, observadores y DTO
│  ├─ Puertos/
│  │  ├─ Entrada/                    PagarObligacionComando, ReversarPagoComando, ObtenerPagoConsulta
│  │  └─ Salida/                     IPagoRepository, IConsultaDeObligaciones, IGeneradorNumeroRecibo,
│  │                                 IPasarelaDePagos (+ SolicitudDeAutorizacion, ResultadoDeAutorizacion)
│  └─ DependencyInjection/           AgregarNucleoPagos()
├─ Pagos.Adaptadores.Entrada/        ← conducen a Pagos
│  ├─ Http/                          PagosEndpoints, PagarObligacionSolicitud
│  ├─ Mensajeria/                    PagoDeSancionRechazadoConsumidor
│  └─ DependencyInjection/           AgregarAdaptadoresDeEntradaPagos()
├─ Pagos.Adaptadores.Salida/         ← Pagos los conduce
│  ├─ Persistencia/                  RepositorioDePagos, GeneradorNumeroReciboDocumental
│  ├─ Sanciones/                     ConsultaDeObligacionesDeSanciones (capa anticorrupción)
│  ├─ Pasarela/                      PasarelaFakePayAdapter + ProveedorFicticio/ (FakePay SDK)
│  ├─ Eventos/                       PagoConfirmadoTraductor, PagoReversadoTraductor
│  └─ DependencyInjection/           AgregarAdaptadoresDeSalidaPagos()
└─ Pagos.Host/                       MicroservicioPagos.cs (composition root)
tests/Pagos.Nucleo.Tests/            las 18 pruebas de dominio, con dobles en memoria
```

## Dependencias

| Proyecto | Referencia a |
|---|---|
| Pagos.Nucleo | BuildingBlocks.Domain, BuildingBlocks.Application. **Ningún contrato.** |
| Pagos.Adaptadores.Entrada | Nucleo, Sanciones.Contracts, BuildingBlocks.Api |
| Pagos.Adaptadores.Salida | Nucleo, Pagos.Contracts, Sanciones.Contracts, BuildingBlocks.Infrastructure |
| Pagos.Host | Nucleo, Adaptadores.Entrada, Adaptadores.Salida |

## Cómo integrarlo al repositorio

1. Copie `src/Pagos/Pagos.Nucleo`, `Pagos.Adaptadores.Entrada`, `Pagos.Adaptadores.Salida` y `Pagos.Host` a `src/Pagos/`.
2. Quite de la solución `Pagos.Domain`, `Pagos.Application`, `Pagos.Infrastructure` y `Pagos.Api`, y agregue los cuatro nuevos.
   `Pagos.Contracts` se queda igual.
3. Reemplace `tests/Pagos.Domain.Tests` por `tests/Pagos.Nucleo.Tests`.
4. Donde se arrancaba `Pagos.Api.MicroservicioPagos`, use `Pagos.Host.MicroservicioPagos` y cambie la referencia de proyecto.
   Las pruebas de integración solo cambian ese `using`.
5. Compile y corra las pruebas. **Criterio de éxito:** las 18 de dominio y las de integración pasan sin modificarse.

## Qué revisar al integrar

No tuve el código fuente, solo los documentos `.md`. Todo lo documentado se respetó al pie de la letra.
Lo que los documentos no detallan lo supuse, y se ajusta en pocos sitios:

- **Espacios de nombres del BuildingBlock.** Cada proyecto tiene un `GlobalUsings.cs` con los `using` de BuildingBlocks.
  Si en el repositorio se llaman distinto, solo se corrige ese archivo.
- **Versión de .NET y paquetes.** Los `.csproj` usan `net8.0`. Si el repositorio usa otra versión o tiene
  `Directory.Build.props` / `Directory.Packages.props`, ajuste `TargetFramework` y copie las `PackageReference`
  de `Pagos.Api.csproj` y de `Pagos.Domain.Tests.csproj`.
- **Firmas no documentadas del BuildingBlock.**
  - `IClienteHttp.EnviarAsync(SolicitudHttp, ct)`, `SolicitudHttp.Get(host, ruta)` y `RespuestaHttp.CodigoDeEstado` / `.Cuerpo`
    (en `Salida/Sanciones/ConsultaDeObligacionesDeSanciones.cs`).
  - `ISerializador.Deserializar<T>(json)` (mismo archivo).
  - El constructor de `RepositorioDocumentalBase(baseDeDatos, unidadDeTrabajo, serializador)` con tipos
    `BaseDeDatosDocumental` y `UnidadDeTrabajoDocumental` (en `Salida/Persistencia/RepositorioDePagos.cs`).
  - `Resultados.Problema(402, titulo, detalle)` (en `Entrada/Http/PagosEndpoints.cs`).
  - El cuerpo de `MicroservicioPagos.Crear`: conserve el que tiene hoy `Pagos.Api/MicroservicioPagos.cs`
    (logging, arranque) y **cambie solo las tres líneas de registro**.
- **Campos de los contratos.** Los traductores suponen
  `PagoConfirmadoV1(EventoId, OcurrioEn, PagoId, NumeroRecibo, TipoObligacion, ObligacionId, Monto, Moneda, ReferenciaTransaccion)`
  y `PagoReversadoV1(..., Motivo)`. La capa anticorrupción lee de `ObligacionDeSancionV1` los campos `ValorAPagar`, `Moneda`,
  `AdmitePago` y `Descripcion`. El consumidor lee `PagoId` y `Motivo` de `PagoDeSancionRechazadoV1`.
  Si los nombres reales difieren, se corrigen en esos tres archivos. El núcleo no se toca.
- **Ciclo de vida de los traductores.** Se registran con `AddScoped`. Si `AgregarBloquesDeAplicacion` los registra con otro
  ciclo de vida, use el mismo.

## Qué cambió frente a la versión Clean

| Hoy (Clean) | Hexagonal | ¿Cambia el código? |
|---|---|---|
| Pagos.Domain: Pago, estados, eventos, reglas, ServicioDeCobro | Nucleo/Dominio | No, solo el namespace |
| Pagos.Domain: IPagoRepository, IConsultaDeObligaciones, IGeneradorNumeroRecibo | Nucleo/Puertos/Salida | No, solo el namespace |
| Pagos.Application/Puertos: IPasarelaDePagos y sus modelos | Nucleo/Puertos/Salida | No, solo el namespace |
| Pagos.Application: comandos y consulta | Nucleo/Puertos/Entrada | No, solo el namespace |
| Pagos.Application: manejadores, validadores, observadores, DTO | Nucleo/Aplicacion | No, solo el namespace |
| Pagos.Application/Integracion/Consumidores | Adaptadores.Entrada/Mensajeria | Namespace y referencia |
| Pagos.Application/Integracion/Traductores | Adaptadores.Salida/Eventos | Registro explícito |
| Pagos.Infrastructure: repositorio, ACL, pasarela | Adaptadores.Salida | No, solo el namespace |
| Pagos.Api: endpoints y solicitudes · MicroservicioPagos | Adaptadores.Entrada/Http · Host | Agrupar los registros |

La única decisión de diseño nueva: **los traductores salen del núcleo**. Así el núcleo deja de depender de
`Pagos.Contracts`. Como el registro por convención solo recorre el ensamblado del núcleo,
`AgregarAdaptadoresDeSalidaPagos` los registra a mano (2 líneas).

## Verificación hecha

Como no tenía el repositorio, compilé el código contra *stubs* de BuildingBlocks, Pagos.Contracts y Sanciones.Contracts.
Los stubs reproducen las firmas documentadas y no se entregan. El resultado:

- Compila sin errores ni advertencias (`-warnaserror`).
- Pasan las **18 pruebas de dominio**.
- Pasan 5 pruebas de humo de punta a punta: Host → HTTP → núcleo → adaptadores, con `ValidateOnBuild`.
  Cubren el pago aprobado (201 + `PagoConfirmadoV1` en la bandeja de salida + recibo por correo),
  el rechazo de la pasarela (402, el pago queda guardado y no se publica nada), los errores 400/404/422,
  la compensación por mensajería (reversa idempotente + `PagoReversadoV1`) y la idempotencia de FakePay.
