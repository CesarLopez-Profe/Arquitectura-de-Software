using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Tests.Dobles;

/// <summary>Doble del puerto IGeneradorNumeroRecibo: siempre el siguiente de una secuencia local.</summary>
public sealed class GeneradorDeReciboFijo : IGeneradorNumeroRecibo
{
    private long _siguiente = 1;

    public Task<NumeroRecibo> SiguienteAsync(int anio, CancellationToken cancellationToken) =>
        Task.FromResult(NumeroRecibo.Generar(anio, _siguiente++));
}
