using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Tests.Dobles;

/// <summary>Doble del puerto IPagoRepository.</summary>
public sealed class PagosEnMemoria : IPagoRepository
{
    private readonly Dictionary<PagoId, Pago> _pagos = new();

    public Task AgregarAsync(Pago pago, CancellationToken cancellationToken)
    {
        _pagos[pago.Id] = pago;
        return Task.CompletedTask;
    }

    public Task ActualizarAsync(Pago pago, CancellationToken cancellationToken) => AgregarAsync(pago, cancellationToken);

    public Task<Pago?> ObtenerAsync(PagoId id, CancellationToken cancellationToken) =>
        Task.FromResult(_pagos.GetValueOrDefault(id));

    public Task<bool> ExistePagoActivoParaAsync(ReferenciaObligacion obligacion, CancellationToken cancellationToken) =>
        Task.FromResult(_pagos.Values.Any(p => p.Obligacion == obligacion && p.EstaActivo));
}
