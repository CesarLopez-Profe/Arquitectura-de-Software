using Pagos.Nucleo.Dominio.Obligaciones;
using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Puertos.Salida;

namespace Pagos.Nucleo.Tests.Dobles;

/// <summary>Doble del puerto IConsultaDeObligaciones: reemplaza a la capa anticorrupción.</summary>
public sealed class ObligacionesFalsas : IConsultaDeObligaciones
{
    private readonly Dictionary<ReferenciaObligacion, ObligacionPorPagar> _obligaciones = new();

    public ObligacionesFalsas Con(ObligacionPorPagar obligacion)
    {
        _obligaciones[obligacion.Referencia] = obligacion;
        return this;
    }

    public Task<ObligacionPorPagar?> ObtenerAsync(
        ReferenciaObligacion referencia, DateTimeOffset fechaPago, CancellationToken cancellationToken) =>
        Task.FromResult(_obligaciones.GetValueOrDefault(referencia));
}
