using Pagos.Nucleo.Dominio.Obligaciones;
using Pagos.Nucleo.Dominio.Pagos;

namespace Pagos.Nucleo.Tests;

/// <summary>Datos de prueba compartidos.</summary>
internal static class Datos
{
    public static readonly DateTimeOffset Ahora = new(2026, 10, 5, 8, 0, 0, TimeSpan.FromHours(-5));

    public static ReferenciaObligacion Sancion(Guid? id = null) => new(TipoObligacion.Sancion, id ?? Guid.NewGuid());

    public static Dinero Pesos(decimal monto) => Dinero.De(monto, "COP");

    public static CorreoElectronico Correo => CorreoElectronico.De("Ana.Gomez@correo.co");

    public static ObligacionPorPagar Obligacion(ReferenciaObligacion referencia, decimal valor = 437_750m, bool admitePago = true) =>
        new(referencia, Pesos(valor), admitePago, "Comparendo C-2026-001");

    public static Pago PagoPendiente(decimal monto = 437_750m) => Pago.Iniciar(
        PagoId.Nuevo(), NumeroRecibo.Generar(2026, 1), Sancion(), Pesos(monto), MetodoPago.TarjetaCredito, Correo, Ahora);

    public static Pago PagoConfirmado()
    {
        var pago = PagoPendiente();
        pago.Confirmar("FP-5BDDFBCA34", Ahora);
        return pago;
    }
}
