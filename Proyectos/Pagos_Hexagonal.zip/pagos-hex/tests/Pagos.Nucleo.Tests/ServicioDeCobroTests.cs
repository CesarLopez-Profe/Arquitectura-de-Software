using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Pagos.Reglas;
using Pagos.Nucleo.Dominio.Servicios;
using Pagos.Nucleo.Tests.Dobles;

namespace Pagos.Nucleo.Tests;

/// <summary>
/// El servicio de dominio solo ve puertos de salida, así que se prueba con dobles en memoria:
/// ni HTTP, ni Sanciones, ni base de datos.
/// </summary>
public sealed class ServicioDeCobroTests
{
    private readonly ObligacionesFalsas _obligaciones = new();
    private readonly PagosEnMemoria _pagos = new();
    private readonly ServicioDeCobro _servicio;

    public ServicioDeCobroTests() =>
        _servicio = new ServicioDeCobro(_obligaciones, _pagos, new GeneradorDeReciboFijo());

    private Task<Pago> IniciarAsync(ReferenciaObligacion referencia, decimal monto) =>
        _servicio.IniciarPagoAsync(referencia, Datos.Pesos(monto), MetodoPago.TarjetaCredito, Datos.Correo, Datos.Ahora, CancellationToken.None);

    [Fact]
    public async Task Inicia_un_pago_pendiente_cuando_se_cumplen_todas_las_reglas()
    {
        var referencia = Datos.Sancion();
        _obligaciones.Con(Datos.Obligacion(referencia));

        var pago = await IniciarAsync(referencia, 437_750m);

        Assert.Equal(EstadoPago.Pendiente, pago.Estado);
        Assert.Equal("REC-2026-001", pago.Recibo.Valor);
    }

    [Fact]
    public async Task Rompe_ObligacionDebeExistir_si_la_obligacion_no_existe()
    {
        var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() => IniciarAsync(Datos.Sancion(), 437_750m));

        Assert.IsType<ObligacionDebeExistir>(ex.BrokenRule);
    }

    [Fact]
    public async Task Rompe_ObligacionDebeAdmitirPago_si_la_obligacion_no_lo_admite()
    {
        var referencia = Datos.Sancion();
        _obligaciones.Con(Datos.Obligacion(referencia, admitePago: false));

        var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() => IniciarAsync(referencia, 437_750m));

        Assert.IsType<ObligacionDebeAdmitirPago>(ex.BrokenRule);
    }

    [Fact]
    public async Task Rompe_MontoDebeCoincidirConLaObligacion_si_el_monto_es_distinto()
    {
        var referencia = Datos.Sancion();
        _obligaciones.Con(Datos.Obligacion(referencia, valor: 437_750m));

        var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() => IniciarAsync(referencia, 400_000m));

        Assert.IsType<MontoDebeCoincidirConLaObligacion>(ex.BrokenRule);
    }

    [Fact]
    public async Task Rompe_NoDebeExistirOtroPagoActivo_si_ya_hay_un_pago_pendiente()
    {
        var referencia = Datos.Sancion();
        _obligaciones.Con(Datos.Obligacion(referencia));
        await _pagos.AgregarAsync(await IniciarAsync(referencia, 437_750m), CancellationToken.None);

        var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() => IniciarAsync(referencia, 437_750m));

        Assert.IsType<NoDebeExistirOtroPagoActivo>(ex.BrokenRule);
    }

    [Fact]
    public async Task Permite_un_pago_nuevo_si_el_anterior_fue_rechazado()
    {
        var referencia = Datos.Sancion();
        _obligaciones.Con(Datos.Obligacion(referencia));
        var anterior = await IniciarAsync(referencia, 437_750m);
        anterior.Rechazar("Tarjeta rechazada", Datos.Ahora);
        await _pagos.AgregarAsync(anterior, CancellationToken.None);

        var nuevo = await IniciarAsync(referencia, 437_750m);

        Assert.Equal(EstadoPago.Pendiente, nuevo.Estado);
    }
}
