using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Pagos.Estados;

namespace Pagos.Nucleo.Tests;

public sealed class EstadoDePagoTests
{
    [Theory]
    [InlineData(EstadoPago.Pendiente, OperacionDePago.Confirmar, true)]
    [InlineData(EstadoPago.Pendiente, OperacionDePago.Rechazar, true)]
    [InlineData(EstadoPago.Pendiente, OperacionDePago.Reversar, false)]
    [InlineData(EstadoPago.Confirmado, OperacionDePago.Confirmar, false)]
    [InlineData(EstadoPago.Confirmado, OperacionDePago.Rechazar, false)]
    [InlineData(EstadoPago.Confirmado, OperacionDePago.Reversar, true)]
    [InlineData(EstadoPago.Rechazado, OperacionDePago.Confirmar, false)]
    [InlineData(EstadoPago.Rechazado, OperacionDePago.Rechazar, false)]
    [InlineData(EstadoPago.Rechazado, OperacionDePago.Reversar, false)]
    [InlineData(EstadoPago.Reversado, OperacionDePago.Confirmar, false)]
    [InlineData(EstadoPago.Reversado, OperacionDePago.Rechazar, false)]
    [InlineData(EstadoPago.Reversado, OperacionDePago.Reversar, false)]
    public void Tabla_completa_de_Permite(EstadoPago estado, OperacionDePago operacion, bool esperado) =>
        Assert.Equal(esperado, EstadoDePago.Desde(estado).Permite(operacion));

    [Fact]
    public void Cada_estado_es_una_instancia_unica()
    {
        Assert.Same(EstadoDePago.Pendiente, EstadoDePago.Desde(EstadoPago.Pendiente));
        Assert.Same(EstadoDePago.Confirmado, EstadoDePago.Desde(EstadoPago.Confirmado));
        Assert.Same(EstadoDePago.Rechazado, EstadoDePago.Desde(EstadoPago.Rechazado));
        Assert.Same(EstadoDePago.Reversado, EstadoDePago.Desde(EstadoPago.Reversado));
    }

    [Fact]
    public void Solo_pendiente_y_confirmado_estan_activos()
    {
        Assert.True(EstadoDePago.Pendiente.EstaActivo);
        Assert.True(EstadoDePago.Confirmado.EstaActivo);
        Assert.False(EstadoDePago.Rechazado.EstaActivo);
        Assert.False(EstadoDePago.Reversado.EstaActivo);
    }
}
