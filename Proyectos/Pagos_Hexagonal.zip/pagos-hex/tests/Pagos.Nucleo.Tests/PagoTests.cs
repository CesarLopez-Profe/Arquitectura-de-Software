using Pagos.Nucleo.Dominio.Pagos;
using Pagos.Nucleo.Dominio.Pagos.Eventos;
using Pagos.Nucleo.Dominio.Pagos.Reglas;

namespace Pagos.Nucleo.Tests;

public sealed class PagoTests
{
    [Fact]
    public void Iniciar_crea_un_pago_pendiente_y_emite_PagoIniciado()
    {
        var pago = Datos.PagoPendiente();

        Assert.Equal(EstadoPago.Pendiente, pago.Estado);
        Assert.IsType<PagoIniciado>(Assert.Single(pago.DomainEvents));
        Assert.Equal("ana.gomez@correo.co", pago.CorreoPagador.Valor);
    }

    [Fact]
    public void Confirmar_un_pago_pendiente_lo_deja_confirmado_y_emite_PagoConfirmado()
    {
        var pago = Datos.PagoPendiente();

        pago.Confirmar("FP-5BDDFBCA34", Datos.Ahora);

        Assert.Equal(EstadoPago.Confirmado, pago.Estado);
        Assert.Equal("FP-5BDDFBCA34", pago.ReferenciaTransaccion);
        Assert.IsType<PagoConfirmado>(pago.DomainEvents.Last());
    }

    [Fact]
    public void Rechazar_un_pago_pendiente_lo_deja_rechazado_e_inactivo()
    {
        var pago = Datos.PagoPendiente();

        pago.Rechazar("Tarjeta rechazada", Datos.Ahora);

        Assert.Equal(EstadoPago.Rechazado, pago.Estado);
        Assert.False(pago.EstaActivo);
        Assert.IsType<PagoRechazado>(pago.DomainEvents.Last());
    }

    [Fact]
    public void Reversar_un_pago_confirmado_lo_deja_reversado()
    {
        var pago = Datos.PagoConfirmado();

        pago.Reversar("La sanción fue anulada", Datos.Ahora);

        Assert.Equal(EstadoPago.Reversado, pago.Estado);
        Assert.IsType<PagoReversado>(pago.DomainEvents.Last());
    }

    [Fact]
    public void No_se_puede_reversar_un_pago_pendiente()
    {
        var pago = Datos.PagoPendiente();

        var ex = Assert.Throws<BusinessRuleViolationException>(() => pago.Reversar("motivo", Datos.Ahora));

        Assert.IsType<PagoDebePermitirLaOperacion>(ex.BrokenRule);
        Assert.Equal(EstadoPago.Pendiente, pago.Estado);
    }

    [Fact]
    public void No_se_puede_confirmar_un_pago_rechazado()
    {
        var pago = Datos.PagoPendiente();
        pago.Rechazar("Tarjeta rechazada", Datos.Ahora);

        var ex = Assert.Throws<BusinessRuleViolationException>(() => pago.Confirmar("FP-1", Datos.Ahora));

        Assert.IsType<PagoDebePermitirLaOperacion>(ex.BrokenRule);
    }

    [Fact]
    public void Si_un_setter_rechaza_el_dato_el_pago_sigue_pendiente()
    {
        var pago = Datos.PagoPendiente();
        var referenciaDemasiadoLarga = new string('X', 61);

        Assert.Throws<DomainException>(() => pago.Confirmar(referenciaDemasiadoLarga, Datos.Ahora));

        Assert.Equal(EstadoPago.Pendiente, pago.Estado);
    }

    [Fact]
    public void Un_monto_en_cero_rompe_la_regla_MontoDelPagoDebeSerPositivo()
    {
        var ex = Assert.Throws<BusinessRuleViolationException>(() => Datos.PagoPendiente(monto: 0m));

        Assert.IsType<MontoDelPagoDebeSerPositivo>(ex.BrokenRule);
    }

    [Fact]
    public void El_memento_conserva_el_estado_y_los_datos()
    {
        var original = Datos.PagoConfirmado();

        var restaurado = Pago.RestaurarDesde(original.CrearMemento());

        Assert.Equal(original.CrearMemento(), restaurado.CrearMemento());
        Assert.Equal(EstadoPago.Confirmado, restaurado.Estado);
        Assert.True(restaurado.Permite(OperacionDePago.Reversar));
        Assert.Empty(restaurado.DomainEvents);
    }
}
