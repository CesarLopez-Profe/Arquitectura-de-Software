global using Xunit;
global using Transito.BuildingBlocks.Domain;
