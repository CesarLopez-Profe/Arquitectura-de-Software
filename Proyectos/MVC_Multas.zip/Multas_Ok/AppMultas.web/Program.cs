using AppMultas.web.Servicios;
using Bib_multas.Aspectos;
using Bib_multas.Factories;
using Bib_multas.Eventos;
using Microsoft.Win32;
using System.Runtime.CompilerServices;
using System.IO;
using Bib_multas.Clases;

var builder = WebApplication.CreateBuilder(args); //varaible para instanciar la app web

// Add services to the container.
builder.Services.AddControllersWithViews();

// ============= REGISTRAR SERVICIOS DE ASPECTO (MENSAJER�A) =============
// IMPORTANTE: Registrar HttpContextAccessor para que el interceptor funcione
builder.Services.AddHttpContextAccessor();

// Registrar el interceptor de mensajer�a
builder.Services.AddScoped<Interceptor_Envio_Mensajes>();

// Registrar el factory para crear medios de mensajer�a con interceptor
builder.Services.AddScoped<MensajeriaFactory>();

//se registran los servicios como singleton=>patr�n arquit�ctonico 

builder.Services.AddSingleton<ConductorService>();
builder.Services.AddSingleton<VehiculoService>();
builder.Services.AddSingleton<MultaService>();

var app = builder.Build(); //Build() instancia esta app web y la asigna a app

//Datos precargados
var conductorService = app.Services.GetRequiredService<ConductorService>();

conductorService.Agregar(new Bib_multas.Clases.Conductor(
    Bib_multas.Clases.Conductor.tipos_id.CC, "123", "Carlos P�rez", 30, 3154442211,"cperez@gmail.com"));

//Invocar carga de conductores
conductorService.Cargar("C:\\Users\\000096175\\OneDrive - UPB\\Cursos Pregrado\\Paradigmas de Programaci�n\\2025\\Proyectos\\Multas_Ok\\AppMultas.web\\Archivos\\Conductores.txt");

conductorService.Agregar(new Bib_multas.Clases.Conductor(
    Bib_multas.Clases.Conductor.tipos_id.CE, "456", "Ana G�mez", 28, 3002582200, "Ana.gomez@upb.edu.co"));

var vehiculoService = app.Services.GetRequiredService<VehiculoService>();
vehiculoService.Agregar(new Bib_multas.Clases.Vehiculo(
    "ABC123", "Toyota", "Corolla", new DateTime(2020, 1, 1)));

vehiculoService.Agregar(new Bib_multas.Clases.Vehiculo(
    "XYZ789", "Mazda", "CX-5", new DateTime(2019, 6, 15)));

vehiculoService.Cargar("C:\\Users\\000096175\\OneDrive - UPB\\Cursos Pregrado\\Paradigmas de Programaci�n\\2025\\Proyectos\\Multas_Ok\\AppMultas.web\\Archivos\\Automoviles.txt");


//Invocar carga de automoviles



// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts(); //HSTS (HTTP Strict Transport Security), Obliga a usar navegaci�n segura
}

//app.UseHttpsRedirection();
app.UseStaticFiles(); //sirve para usar archivos est�ticos (como HTML, CSS, JS, im�genes) desde la carpeta wwwroot

app.UseRouting();  //Habilita el enrutamiento, es decir, la capacidad de ASP.NET Core para asociar URLs con controladores y acciones.

app.UseAuthorization(); //verifica si el usuario tiene permisos para acceder a ciertos recursos.

app.MapControllerRoute( //Se configura la ruta por defecto para MVC
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run(); //Levanta la App en el navegador


