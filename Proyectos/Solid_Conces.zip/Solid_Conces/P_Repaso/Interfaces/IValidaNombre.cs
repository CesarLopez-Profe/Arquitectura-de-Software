using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P_Repaso.Interfaces
{
    public interface IValidaNombre
    {
        bool ValidarNombre(string nombre);
        
    }
}