using System.Collections.Concurrent;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Canal que solo guarda lo enviado en memoria; pensado para pruebas automáticas.</summary>
public sealed class CanalDeNotificacionEnMemoria(
    CanalDeNotificacion tipo,
    ConcurrentQueue<(CanalDeNotificacion Canal, Notificacion Notificacion)> buzon) : ICanalDeNotificacion
{
    public CanalDeNotificacion Tipo => tipo;

    public Task EnviarAsync(Notificacion notificacion, CancellationToken cancellationToken)
    {
        buzon.Enqueue((tipo, notificacion));
        return Task.CompletedTask;
    }
}
