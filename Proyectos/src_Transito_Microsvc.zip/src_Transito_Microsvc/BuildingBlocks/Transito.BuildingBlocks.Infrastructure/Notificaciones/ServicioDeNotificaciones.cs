using Transito.BuildingBlocks.Application.Notificaciones;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>
/// Implementa el puerto de notificaciones. Pide los canales a la fábrica abstracta una sola vez
/// y envía cada notificación por los canales marcados en sus banderas.
/// No sabe si los canales son simulados, de prueba o reales (inversión de dependencias).
/// </summary>
public sealed class ServicioDeNotificaciones : IServicioDeNotificaciones
{
    private readonly IReadOnlyList<ICanalDeNotificacion> _canales;

    public ServicioDeNotificaciones(IFabricaDeCanalesDeNotificacion fabrica)
    {
        ArgumentNullException.ThrowIfNull(fabrica);
        _canales = [fabrica.CrearEmail(), fabrica.CrearSms(), fabrica.CrearPush()];
    }

    public async Task NotificarAsync(Notificacion notificacion, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notificacion);
        foreach (var canal in _canales.Where(c => notificacion.Canales.HasFlag(c.Tipo)))
            await canal.EnviarAsync(notificacion, cancellationToken);
    }
}
