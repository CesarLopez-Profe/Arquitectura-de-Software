using System.Collections.Concurrent;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Fábrica concreta alternativa: la familia de canales en memoria para pruebas.</summary>
public sealed class FabricaDeCanalesEnMemoria : IFabricaDeCanalesDeNotificacion
{
    private readonly ConcurrentQueue<(CanalDeNotificacion Canal, Notificacion Notificacion)> _buzon = new();

    public string Familia => "En memoria (pruebas)";

    public IReadOnlyCollection<(CanalDeNotificacion Canal, Notificacion Notificacion)> Enviadas => _buzon.ToArray();

    public ICanalDeNotificacion CrearEmail() => new CanalDeNotificacionEnMemoria(CanalDeNotificacion.Email, _buzon);

    public ICanalDeNotificacion CrearSms() => new CanalDeNotificacionEnMemoria(CanalDeNotificacion.Sms, _buzon);

    public ICanalDeNotificacion CrearPush() => new CanalDeNotificacionEnMemoria(CanalDeNotificacion.Push, _buzon);
}
