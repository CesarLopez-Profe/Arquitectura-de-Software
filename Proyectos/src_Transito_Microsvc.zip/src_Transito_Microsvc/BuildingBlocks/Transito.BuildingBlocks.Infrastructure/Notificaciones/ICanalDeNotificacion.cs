using Transito.BuildingBlocks.Application.Notificaciones;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Producto abstracto de la fábrica: un medio para avisar a una persona.</summary>
public interface ICanalDeNotificacion
{
    CanalDeNotificacion Tipo { get; }
    Task EnviarAsync(Notificacion notificacion, CancellationToken cancellationToken);
}
