using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>SMS simulado: respeta el límite de 160 caracteres de un mensaje de texto.</summary>
public sealed class CanalSmsSimulado(string carpeta, ISerializador serializador, ILogger logger)
    : CanalDeNotificacionSimuladoBase(carpeta, serializador, logger)
{
    public const int LongitudMaxima = 160;

    public override CanalDeNotificacion Tipo => CanalDeNotificacion.Sms;

    protected override string Adaptar(Notificacion notificacion)
    {
        var texto = $"TRANSITO: {notificacion.Mensaje}";
        return texto.Length <= LongitudMaxima ? texto : texto[..(LongitudMaxima - 1)] + "…";
    }
}
