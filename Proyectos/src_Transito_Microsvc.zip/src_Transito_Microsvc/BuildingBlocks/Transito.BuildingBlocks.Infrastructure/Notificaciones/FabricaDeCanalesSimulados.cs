using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Fábrica concreta: la familia de canales que escriben en consola y en archivos JSON.</summary>
public sealed class FabricaDeCanalesSimulados(string carpeta, ISerializador serializador, ILoggerFactory loggerFactory)
    : IFabricaDeCanalesDeNotificacion
{
    private readonly ILogger _logger = loggerFactory.CreateLogger("Notificaciones");

    public string Familia => "Simulados (consola + archivos JSON)";

    public ICanalDeNotificacion CrearEmail() => new CanalEmailSimulado(carpeta, serializador, _logger);

    public ICanalDeNotificacion CrearSms() => new CanalSmsSimulado(carpeta, serializador, _logger);

    public ICanalDeNotificacion CrearPush() => new CanalPushSimulado(carpeta, serializador, _logger);
}
