using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>
/// Template Method: el envío simulado siempre hace lo mismo (adaptar el texto al canal,
/// mostrarlo en consola y dejar el JSON en un buzón de archivos); cada canal concreto solo
/// define su tipo y cómo adapta el mensaje (<see cref="Adaptar"/>).
/// </summary>
public abstract class CanalDeNotificacionSimuladoBase(string carpeta, ISerializador serializador, ILogger logger)
    : ICanalDeNotificacion
{
    public abstract CanalDeNotificacion Tipo { get; }

    public async Task EnviarAsync(Notificacion notificacion, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notificacion);
        var texto = Adaptar(notificacion);

        logger.LogInformation("{Canal} → {Destinatario}: {Texto}", Tipo.ToString().ToUpperInvariant(),
            notificacion.Destinatario, texto);

        var destino = Path.Combine(carpeta, Tipo.ToString().ToLowerInvariant());
        Directory.CreateDirectory(destino);
        var registro = new { canal = Tipo.ToString(), notificacion.Destinatario, notificacion.Asunto, texto };
        await File.WriteAllTextAsync(
            Path.Combine(destino, $"{DateTime.UtcNow:yyyyMMdd-HHmmssfff}_{Guid.NewGuid():N}.json"),
            serializador.Serializar(registro),
            cancellationToken);
    }

    protected abstract string Adaptar(Notificacion notificacion);
}
