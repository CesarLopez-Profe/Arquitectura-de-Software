using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Notificación push simulada (app móvil): solo el asunto, como título corto.</summary>
public sealed class CanalPushSimulado(string carpeta, ISerializador serializador, ILogger logger)
    : CanalDeNotificacionSimuladoBase(carpeta, serializador, logger)
{
    public override CanalDeNotificacion Tipo => CanalDeNotificacion.Push;

    protected override string Adaptar(Notificacion notificacion) => notificacion.Asunto;
}
