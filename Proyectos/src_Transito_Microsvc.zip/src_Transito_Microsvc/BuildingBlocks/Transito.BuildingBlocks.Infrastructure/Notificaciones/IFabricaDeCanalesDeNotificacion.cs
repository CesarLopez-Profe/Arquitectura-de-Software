namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>
/// Patrón Abstract Factory (creacional): crea una FAMILIA completa de canales relacionados
/// (correo, SMS, push) que deben ser coherentes entre sí. Cambiar de familia (simulados en
/// archivos, en memoria para pruebas, proveedores reales) es cambiar una sola clase.
/// </summary>
public interface IFabricaDeCanalesDeNotificacion
{
    string Familia { get; }
    ICanalDeNotificacion CrearEmail();
    ICanalDeNotificacion CrearSms();
    ICanalDeNotificacion CrearPush();
}
