using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Notificaciones;

/// <summary>Correo simulado: asunto y cuerpo completos.</summary>
public sealed class CanalEmailSimulado(string carpeta, ISerializador serializador, ILogger logger)
    : CanalDeNotificacionSimuladoBase(carpeta, serializador, logger)
{
    public override CanalDeNotificacion Tipo => CanalDeNotificacion.Email;

    protected override string Adaptar(Notificacion notificacion) => $"«{notificacion.Asunto}» {notificacion.Mensaje}";
}
