using Transito.BuildingBlocks.Application.Tiempo;

namespace Transito.BuildingBlocks.Infrastructure.Tiempo;

/// <summary>
/// Reloj controlable para la simulación y las pruebas: permite "adelantar" días para probar
/// plazos de apelación, descuentos por pronto pago o vigencias sin esperar. Seguro entre hilos.
/// </summary>
public sealed class RelojSimulado : IClock
{
    private readonly Lock _cerrojo = new();
    private DateTimeOffset _ahora;

    public RelojSimulado(DateTimeOffset inicio) => Establecer(inicio);

    public DateTimeOffset Now
    {
        get
        {
            lock (_cerrojo) return _ahora;
        }
    }

    public void Establecer(DateTimeOffset momento)
    {
        if (momento == default)
            throw new ArgumentException("El reloj necesita una fecha válida.", nameof(momento));
        lock (_cerrojo) _ahora = momento;
    }

    public void Avanzar(TimeSpan intervalo)
    {
        if (intervalo < TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(intervalo), "El tiempo no retrocede.");
        lock (_cerrojo) _ahora = _ahora.Add(intervalo);
    }
}
