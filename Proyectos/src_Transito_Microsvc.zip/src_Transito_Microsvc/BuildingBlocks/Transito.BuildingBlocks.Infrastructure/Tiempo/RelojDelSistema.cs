using Transito.BuildingBlocks.Application.Tiempo;

namespace Transito.BuildingBlocks.Infrastructure.Tiempo;

/// <summary>Reloj real para producción.</summary>
public sealed class RelojDelSistema : IClock
{
    public DateTimeOffset Now => DateTimeOffset.Now;
}
