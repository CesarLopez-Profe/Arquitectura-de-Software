using System.Text.Json;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;

/// <summary>
/// Documento de la bandeja de salida (Transactional Outbox). Se guarda en la misma transacción
/// que el agregado y un proceso en segundo plano lo publica después.
/// El contenido se guarda como objeto JSON anidado (no como texto escapado) para que sea legible.
/// <c>Secuencia</c> conserva el orden en que se emitieron los eventos aunque ocurran en el mismo instante.
/// </summary>
public sealed record MensajeDeSalida(
    Guid Id,
    long Secuencia,
    string Topico,
    string Tipo,
    string Origen,
    Guid CorrelacionId,
    DateTimeOffset OcurrioEn,
    JsonElement Contenido,
    DateTimeOffset? PublicadoEn,
    int Intentos,
    string? UltimoError);
