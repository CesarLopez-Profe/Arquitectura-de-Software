namespace Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;

/// <summary>
/// Documento de la bandeja de entrada (Inbox / Idempotent Consumer): registra que un consumidor
/// ya procesó un mensaje. Si el broker lo entrega otra vez, se descarta.
/// </summary>
public sealed record MensajeProcesado(Guid MensajeId, string Consumidor, DateTimeOffset ProcesadoEn)
{
    public string ClaveDocumento => Clave(MensajeId, Consumidor);

    public static string Clave(Guid mensajeId, string consumidor) => $"{consumidor}:{mensajeId}";
}
