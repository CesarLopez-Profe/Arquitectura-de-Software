using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;

/// <summary>Consulta cuántos eventos siguen sin publicar (útil para monitoreo y para la demo).</summary>
public sealed class MonitorDeBandejaDeSalida(BaseDeDatosDocumental baseDeDatos, ISerializador serializador)
{
    public int Pendientes() =>
        baseDeDatos.Listar(Colecciones.BandejaDeSalida)
            .Count(d => serializador.Deserializar<MensajeDeSalida>(d.Json).PublicadoEn is null);
}
