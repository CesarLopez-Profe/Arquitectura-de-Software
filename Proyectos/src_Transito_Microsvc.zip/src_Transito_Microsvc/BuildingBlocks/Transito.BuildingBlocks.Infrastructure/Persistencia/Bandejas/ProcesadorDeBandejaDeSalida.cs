using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Tiempo;
using Transito.BuildingBlocks.Infrastructure.Mensajeria;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;

/// <summary>
/// Proceso en segundo plano (relay del Outbox): cada cierto intervalo toma los mensajes
/// pendientes de la bandeja de salida, los publica por todos los canales configurados y los marca
/// como publicados. Si un canal falla, el mensaje queda pendiente y se reintenta en la siguiente
/// vuelta (entrega "al menos una vez").
/// </summary>
public sealed class ProcesadorDeBandejaDeSalida(
    BaseDeDatosDocumental baseDeDatos,
    IPublicadorDeMensajes publicador,
    ISerializador serializador,
    IClock reloj,
    OpcionesDeMicroservicio opciones,
    ILogger<ProcesadorDeBandejaDeSalida> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var temporizador = new PeriodicTimer(opciones.IntervaloBandejaDeSalida);
        try
        {
            do
            {
                await ProcesarPendientesAsync(stoppingToken);
            }
            while (await temporizador.WaitForNextTickAsync(stoppingToken));
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Apagado normal del microservicio.
        }
    }

    public async Task<int> ProcesarPendientesAsync(CancellationToken cancellationToken)
    {
        var pendientes = baseDeDatos.Listar(Colecciones.BandejaDeSalida)
            .Select(d => (Documento: d, Mensaje: serializador.Deserializar<MensajeDeSalida>(d.Json)))
            .Where(x => x.Mensaje.PublicadoEn is null)
            .OrderBy(x => x.Mensaje.Secuencia)
            .ToList();

        foreach (var (documento, mensaje) in pendientes)
        {
            var envoltura = new ConstructorDeMensaje()
                .ConId(mensaje.Id)
                .DeTipo(mensaje.Tipo)
                .EnTopico(mensaje.Topico)
                .DesdeOrigen(mensaje.Origen)
                .ConCorrelacion(mensaje.CorrelacionId)
                .OcurridoEn(mensaje.OcurrioEn)
                .ConContenido(mensaje.Contenido)
                .ConEncabezado("intento-publicacion", (mensaje.Intentos + 1).ToString())
                .Construir();

            MensajeDeSalida actualizado;
            try
            {
                await publicador.PublicarAsync(envoltura, cancellationToken);
                actualizado = mensaje with { PublicadoEn = reloj.Now, Intentos = mensaje.Intentos + 1, UltimoError = null };
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning("Bandeja de salida: {Tipo} no se pudo publicar ({Error}); se reintentará",
                    mensaje.Tipo, ex.Message);
                actualizado = mensaje with { Intentos = mensaje.Intentos + 1, UltimoError = ex.Message };
            }

            baseDeDatos.Confirmar(new LoteDeEscritura().Actualizar(
                Colecciones.BandejaDeSalida, documento.Id, serializador.Serializar(actualizado), documento.Version));
        }

        return pendientes.Count;
    }
}
