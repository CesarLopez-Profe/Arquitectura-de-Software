using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Agregado que la unidad de trabajo vigila: guarda el JSON original para detectar cambios
/// (dirty checking) y la versión leída para la concurrencia optimista.
/// </summary>
internal sealed class EntradaRastreada(
    string coleccion,
    string id,
    IAggregateRoot agregado,
    Func<string> serializar,
    long version,
    string? jsonOriginal)
{
    public string Coleccion { get; } = coleccion;
    public string Id { get; } = id;
    public IAggregateRoot Agregado { get; } = agregado;
    public Func<string> Serializar { get; } = serializar;
    public long Version { get; private set; } = version;
    public string? JsonOriginal { get; private set; } = jsonOriginal;
    public bool EsNuevo => JsonOriginal is null;

    public void MarcarConfirmada(string json)
    {
        if (EsNuevo)
            Version = 1;
        else if (json != JsonOriginal)
            Version++;
        JsonOriginal = json;
    }
}
