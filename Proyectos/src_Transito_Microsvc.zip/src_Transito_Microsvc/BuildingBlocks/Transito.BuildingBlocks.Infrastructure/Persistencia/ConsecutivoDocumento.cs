namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>Documento JSON que guarda el último número entregado de una secuencia.</summary>
public sealed record ConsecutivoDocumento(string Clave, long Valor);
