namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Fila de la base de datos documental: el JSON tal como se guardó y su versión,
/// usada para la concurrencia optimista.
/// </summary>
public sealed record Documento(
    string Coleccion,
    string Id,
    long Version,
    string Json,
    DateTimeOffset ActualizadoEn);
