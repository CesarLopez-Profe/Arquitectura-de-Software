namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>Una escritura dentro de un lote. <c>VersionEsperada</c> = 0 significa "no debe existir".</summary>
public sealed record OperacionDeEscritura(
    TipoDeOperacion Tipo,
    string Coleccion,
    string Id,
    string? Json,
    long VersionEsperada);
