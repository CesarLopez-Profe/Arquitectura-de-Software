namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>Colecciones técnicas que existen en la base de datos de todo microservicio.</summary>
public static class Colecciones
{
    /// <summary>Outbox: eventos de integración pendientes de publicar.</summary>
    public const string BandejaDeSalida = "bandeja_salida";

    /// <summary>Inbox: mensajes ya consumidos, para descartar duplicados.</summary>
    public const string BandejaDeEntrada = "bandeja_entrada";

    /// <summary>Secuencias para números de negocio (comparendos, recibos, licencias).</summary>
    public const string Consecutivos = "consecutivos";
}
