using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Base de datos documental SIMULADA (al estilo MongoDB / Cosmos DB). Cada microservicio tiene la
/// suya: nadie comparte tablas. Solo recibe y entrega texto JSON, organizado por colecciones.
/// <list type="bullet">
/// <item>Transacciones atómicas por lote (<see cref="Confirmar"/>).</item>
/// <item>Concurrencia optimista por número de versión.</item>
/// <item>Opcionalmente refleja cada documento en disco para poder inspeccionarlo.</item>
/// </list>
/// </summary>
public sealed class BaseDeDatosDocumental
{
    private readonly ConcurrentDictionary<string, ConcurrentDictionary<string, Documento>> _colecciones =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly Lock _cerrojo = new();
    private readonly OpcionesDeBaseDeDatos _opciones;
    private readonly IClock _reloj;
    private readonly ILogger<BaseDeDatosDocumental> _logger;

    public BaseDeDatosDocumental(OpcionesDeBaseDeDatos opciones, IClock reloj, ILogger<BaseDeDatosDocumental> logger)
    {
        _opciones = opciones ?? throw new ArgumentNullException(nameof(opciones));
        _reloj = reloj ?? throw new ArgumentNullException(nameof(reloj));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public string Nombre => _opciones.Nombre;

    public string? CarpetaEnDisco => _opciones.CarpetaEnDisco;

    public Documento? Obtener(string coleccion, string id) =>
        Coleccion(coleccion).TryGetValue(id, out var documento) ? documento : null;

    public IReadOnlyList<Documento> Listar(string coleccion) =>
        Coleccion(coleccion).Values.OrderBy(d => d.ActualizadoEn).ThenBy(d => d.Id).ToList();

    public IReadOnlyDictionary<string, int> ContarPorColeccion() =>
        _colecciones.ToDictionary(c => c.Key, c => c.Value.Count);

    /// <summary>Aplica todas las operaciones o ninguna. Lanza conflicto si alguna versión no coincide.</summary>
    public void Confirmar(LoteDeEscritura lote)
    {
        ArgumentNullException.ThrowIfNull(lote);
        if (lote.EstaVacio)
            return;

        lock (_cerrojo)
        {
            ValidarVersiones(lote);

            var ahora = _reloj.Now;
            foreach (var operacion in lote.Operaciones)
                Aplicar(operacion, ahora);
        }

        // Las escrituras puramente técnicas (marcar publicado, consecutivos) se registran en Debug
        // para que la consola muestre solo las transacciones de negocio.
        _logger.Log(EsSoloTecnico(lote) ? LogLevel.Debug : LogLevel.Information,
            "BD[{Nombre}] transacción confirmada: {Resumen}",
            Nombre, string.Join(", ", lote.Operaciones.Select(Describir)));
    }

    private static bool EsSoloTecnico(LoteDeEscritura lote) =>
        lote.Operaciones.All(o =>
            o.Coleccion == Colecciones.Consecutivos
            || (o.Coleccion == Colecciones.BandejaDeSalida && o.Tipo == TipoDeOperacion.Actualizar));

    private void ValidarVersiones(LoteDeEscritura lote)
    {
        var claves = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var operacion in lote.Operaciones)
        {
            if (!claves.Add($"{operacion.Coleccion}/{operacion.Id}"))
                throw new ConflictoDeConcurrenciaException(
                    $"El lote modifica dos veces {operacion.Coleccion}/{operacion.Id}.");

            var actual = Obtener(operacion.Coleccion, operacion.Id);
            switch (operacion.Tipo)
            {
                case TipoDeOperacion.Insertar when actual is not null:
                    throw new ConflictoDeConcurrenciaException(
                        $"Ya existe el documento {operacion.Coleccion}/{operacion.Id}.");
                case TipoDeOperacion.Actualizar or TipoDeOperacion.Eliminar
                    when actual is null || actual.Version != operacion.VersionEsperada:
                    throw new ConflictoDeConcurrenciaException(
                        $"El documento {operacion.Coleccion}/{operacion.Id} cambió: se esperaba la versión " +
                        $"{operacion.VersionEsperada} y existe la {actual?.Version.ToString() ?? "ninguna"}.");
            }
        }
    }

    private void Aplicar(OperacionDeEscritura operacion, DateTimeOffset ahora)
    {
        var coleccion = Coleccion(operacion.Coleccion);
        if (operacion.Tipo == TipoDeOperacion.Eliminar)
        {
            coleccion.TryRemove(operacion.Id, out _);
            EliminarDeDisco(operacion);
            return;
        }

        var version = operacion.Tipo == TipoDeOperacion.Insertar ? 1 : operacion.VersionEsperada + 1;
        coleccion[operacion.Id] = new Documento(operacion.Coleccion, operacion.Id, version, operacion.Json!, ahora);
        EscribirEnDisco(operacion);
    }

    private ConcurrentDictionary<string, Documento> Coleccion(string nombre)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(nombre);
        return _colecciones.GetOrAdd(nombre, _ => new ConcurrentDictionary<string, Documento>(StringComparer.OrdinalIgnoreCase));
    }

    private void EscribirEnDisco(OperacionDeEscritura operacion)
    {
        var ruta = RutaEnDisco(operacion);
        if (ruta is null) return;
        Directory.CreateDirectory(Path.GetDirectoryName(ruta)!);
        File.WriteAllText(ruta, operacion.Json);
    }

    private void EliminarDeDisco(OperacionDeEscritura operacion)
    {
        var ruta = RutaEnDisco(operacion);
        if (ruta is not null && File.Exists(ruta))
            File.Delete(ruta);
    }

    private string? RutaEnDisco(OperacionDeEscritura operacion)
    {
        if (CarpetaEnDisco is null) return null;
        var nombreArchivo = string.Concat(operacion.Id.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        return Path.Combine(CarpetaEnDisco, operacion.Coleccion, nombreArchivo + ".json");
    }

    private static string Describir(OperacionDeEscritura operacion)
    {
        var verbo = operacion.Tipo switch
        {
            TipoDeOperacion.Insertar => "INSERT",
            TipoDeOperacion.Actualizar => "UPDATE",
            _ => "DELETE"
        };
        var id = operacion.Id.Length > 13 ? operacion.Id[..8] + "…" : operacion.Id;
        var tamano = operacion.Json is null ? "" : $" ({operacion.Json.Length} B JSON)";
        return $"{verbo} {operacion.Coleccion}/{id}{tamano}";
    }
}
