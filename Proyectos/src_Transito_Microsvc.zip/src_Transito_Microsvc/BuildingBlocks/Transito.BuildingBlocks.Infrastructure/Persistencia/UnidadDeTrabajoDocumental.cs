using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Correlacion;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Integracion;
using Transito.BuildingBlocks.Application.Persistencia;
using Transito.BuildingBlocks.Application.Tiempo;
using Transito.BuildingBlocks.Domain;
using Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Patrones Unit of Work + Identity Map + Transactional Outbox.
/// <para>
/// Al confirmar, en UNA sola transacción de la base de datos se guardan: los agregados que
/// cambiaron (como JSON), los eventos de integración traducidos (bandeja de salida) y los
/// mensajes consumidos (bandeja de entrada). Así nunca queda un cambio guardado sin su evento,
/// ni un evento publicado sin su cambio. Después de confirmar se notifican los eventos de dominio
/// a los observadores locales (notificaciones).
/// </para>
/// Se registra con alcance (scoped): una por petición HTTP o por mensaje consumido.
/// <para>
/// El despachador de eventos se resuelve en el momento de despachar (no en el constructor) porque
/// los observadores pueden depender de repositorios, que a su vez dependen de esta unidad de
/// trabajo: inyectarlo directamente crearía un ciclo. Así, además, los observadores comparten el
/// mismo alcance y ven los mismos agregados (mapa de identidad).
/// </para>
/// </summary>
public sealed class UnidadDeTrabajoDocumental(
    BaseDeDatosDocumental baseDeDatos,
    ISerializador serializador,
    IEnumerable<ITraductorDeEventoDeDominio> traductores,
    IServiceProvider servicios,
    IContextoDeCorrelacion correlacion,
    IClock reloj,
    OpcionesDeMicroservicio opciones,
    ILogger<UnidadDeTrabajoDocumental> logger) : IUnidadDeTrabajo
{
    private static long _secuenciaGlobal = DateTime.UtcNow.Ticks;

    private readonly Dictionary<(string Coleccion, string Id), EntradaRastreada> _rastreados = [];
    private readonly List<MensajeProcesado> _mensajesConsumidos = [];
    private readonly List<ITraductorDeEventoDeDominio> _traductores = traductores.ToList();

    public object? BuscarRastreado(string coleccion, string id) =>
        _rastreados.TryGetValue((coleccion, id), out var entrada) ? entrada.Agregado : null;

    public bool EstaRastreado(string coleccion, string id) => _rastreados.ContainsKey((coleccion, id));

    public void RastrearNuevo(string coleccion, string id, IAggregateRoot agregado, Func<string> serializar)
    {
        if (!_rastreados.TryAdd((coleccion, id), new EntradaRastreada(coleccion, id, agregado, serializar, 0, null)))
            throw new InvalidOperationException($"El agregado {coleccion}/{id} ya está en la unidad de trabajo.");
    }

    public void RastrearExistente(
        string coleccion, string id, IAggregateRoot agregado, long version, string jsonOriginal, Func<string> serializar) =>
        _rastreados.TryAdd((coleccion, id), new EntradaRastreada(coleccion, id, agregado, serializar, version, jsonOriginal));

    public bool MensajeYaProcesado(Guid mensajeId, string consumidor) =>
        baseDeDatos.Obtener(Colecciones.BandejaDeEntrada, MensajeProcesado.Clave(mensajeId, consumidor)) is not null;

    public void RegistrarMensajeProcesado(Guid mensajeId, string consumidor) =>
        _mensajesConsumidos.Add(new MensajeProcesado(mensajeId, consumidor, reloj.Now));

    public async Task ConfirmarAsync(CancellationToken cancellationToken = default)
    {
        var eventos = _rastreados.Values.SelectMany(e => e.Agregado.DomainEvents).ToList();
        var lote = new LoteDeEscritura();
        var jsonPorEntrada = new Dictionary<EntradaRastreada, string>();

        foreach (var entrada in _rastreados.Values)
        {
            var json = entrada.Serializar();
            jsonPorEntrada[entrada] = json;
            if (entrada.EsNuevo)
                lote.Insertar(entrada.Coleccion, entrada.Id, json);
            else if (json != entrada.JsonOriginal)
                lote.Actualizar(entrada.Coleccion, entrada.Id, json, entrada.Version);
        }

        foreach (var mensaje in eventos.SelectMany(TraducirAMensajesDeSalida))
            lote.Insertar(Colecciones.BandejaDeSalida, mensaje.Id.ToString(), serializador.Serializar(mensaje));

        foreach (var consumido in _mensajesConsumidos)
            lote.Insertar(Colecciones.BandejaDeEntrada, consumido.ClaveDocumento, serializador.Serializar(consumido));

        if (lote.EstaVacio)
            return;

        baseDeDatos.Confirmar(lote);

        foreach (var (entrada, json) in jsonPorEntrada)
        {
            entrada.MarcarConfirmada(json);
            entrada.Agregado.ClearDomainEvents();
        }
        _mensajesConsumidos.Clear();

        if (eventos.Count > 0)
            await servicios.GetRequiredService<IDespachadorDeEventosDeDominio>().DespacharAsync(eventos, cancellationToken);
    }

    private IEnumerable<MensajeDeSalida> TraducirAMensajesDeSalida(IDomainEvent evento)
    {
        foreach (var traductor in _traductores.Where(t => t.TipoDeEvento == evento.GetType()))
        {
            var integracion = traductor.Traducir(evento);
            var tipoContrato = integracion.Contenido.GetType();
            logger.LogDebug("Evento {Evento} traducido a {Contrato}", evento.GetType().Name, tipoContrato.Name);

            yield return new MensajeDeSalida(
                integracion.Id,
                Interlocked.Increment(ref _secuenciaGlobal),
                integracion.Topico,
                tipoContrato.Name,
                opciones.Nombre,
                correlacion.CorrelacionId,
                integracion.OcurrioEn,
                serializador.ConvertirAElemento(integracion.Contenido, tipoContrato),
                PublicadoEn: null,
                Intentos: 0,
                UltimoError: null);
        }
    }
}
