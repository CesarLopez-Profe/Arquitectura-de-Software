namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

public enum TipoDeOperacion
{
    Insertar = 1,
    Actualizar = 2,
    Eliminar = 3
}
