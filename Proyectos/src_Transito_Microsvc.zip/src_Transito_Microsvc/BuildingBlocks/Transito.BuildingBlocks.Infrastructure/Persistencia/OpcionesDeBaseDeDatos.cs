namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>Configuración de la base de datos simulada, con validación en los setters.</summary>
public sealed class OpcionesDeBaseDeDatos
{
    private string? _nombre;
    private string? _carpetaEnDisco;

    public string Nombre
    {
        get => _nombre ?? throw new InvalidOperationException("La base de datos no tiene nombre configurado.");
        set
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(value);
            _nombre = value.Trim().ToLowerInvariant();
        }
    }

    /// <summary>Si se indica, cada documento confirmado también se escribe como archivo .json.</summary>
    public string? CarpetaEnDisco
    {
        get => _carpetaEnDisco;
        set => _carpetaEnDisco = string.IsNullOrWhiteSpace(value) ? null : Path.GetFullPath(value);
    }
}
