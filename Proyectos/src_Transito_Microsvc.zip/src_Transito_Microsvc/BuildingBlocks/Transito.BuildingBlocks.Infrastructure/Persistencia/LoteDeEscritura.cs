using System.Text.Json;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Conjunto de escrituras que la base de datos aplica de forma atómica (todas o ninguna).
/// La base de datos SOLO acepta texto JSON válido: cada escritura se valida al agregarse.
/// </summary>
public sealed class LoteDeEscritura
{
    private readonly List<OperacionDeEscritura> _operaciones = [];

    public IReadOnlyList<OperacionDeEscritura> Operaciones => _operaciones.AsReadOnly();

    public bool EstaVacio => _operaciones.Count == 0;

    public LoteDeEscritura Insertar(string coleccion, string id, string json) =>
        Agregar(new OperacionDeEscritura(TipoDeOperacion.Insertar, Validar(coleccion), Validar(id), ValidarJson(json), 0));

    public LoteDeEscritura Actualizar(string coleccion, string id, string json, long versionEsperada) =>
        Agregar(new OperacionDeEscritura(
            TipoDeOperacion.Actualizar, Validar(coleccion), Validar(id), ValidarJson(json), ValidarVersion(versionEsperada)));

    public LoteDeEscritura Eliminar(string coleccion, string id, long versionEsperada) =>
        Agregar(new OperacionDeEscritura(
            TipoDeOperacion.Eliminar, Validar(coleccion), Validar(id), null, ValidarVersion(versionEsperada)));

    private LoteDeEscritura Agregar(OperacionDeEscritura operacion)
    {
        _operaciones.Add(operacion);
        return this;
    }

    private static string Validar(string valor)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(valor);
        return valor;
    }

    private static long ValidarVersion(long version) =>
        version > 0 ? version : throw new ArgumentOutOfRangeException(nameof(version), "La versión esperada debe ser positiva.");

    private static string ValidarJson(string json)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(json);
        try
        {
            using var _ = JsonDocument.Parse(json);
            return json;
        }
        catch (JsonException ex)
        {
            throw new ArgumentException($"La base de datos solo acepta JSON válido: {ex.Message}", nameof(json));
        }
    }
}
