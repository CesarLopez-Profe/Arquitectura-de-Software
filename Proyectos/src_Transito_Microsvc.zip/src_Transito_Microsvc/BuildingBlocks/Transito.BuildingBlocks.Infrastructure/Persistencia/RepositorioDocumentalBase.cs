using Transito.BuildingBlocks.Domain;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Patrones Repository + Template Method + Data Mapper.
/// <para>
/// El algoritmo de persistencia es común a todos los agregados: pedir el memento, serializarlo a
/// JSON, guardarlo en la colección; al leer, deserializar el JSON y restaurar el agregado. Cada
/// repositorio concreto solo completa los pasos variables (nombre de colección, clave) y sus
/// consultas propias. Gracias a <see cref="IOriginador{TSelf,TMemento}"/> la restauración
/// usa un método estático abstracto del agregado, sin reflexión ni setters públicos.
/// </para>
/// </summary>
public abstract class RepositorioDocumentalBase<TAgregado, TId, TMemento>(
    BaseDeDatosDocumental baseDeDatos,
    UnidadDeTrabajoDocumental unidadDeTrabajo,
    ISerializador serializador)
    where TAgregado : AggregateRoot<TId>, IOriginador<TAgregado, TMemento>
    where TId : notnull
    where TMemento : class
{
    protected abstract string Coleccion { get; }

    protected abstract string ClaveDe(TId id);

    public Task AgregarAsync(TAgregado agregado, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(agregado);
        unidadDeTrabajo.RastrearNuevo(Coleccion, ClaveDe(agregado.Id), agregado, () => Serializar(agregado));
        return Task.CompletedTask;
    }

    /// <summary>
    /// El agregado ya quedó rastreado al leerlo: la unidad de trabajo detecta sus cambios al confirmar.
    /// Este método solo verifica que se esté actualizando algo leído en la misma unidad de trabajo.
    /// </summary>
    public Task ActualizarAsync(TAgregado agregado, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(agregado);
        if (!unidadDeTrabajo.EstaRastreado(Coleccion, ClaveDe(agregado.Id)))
            throw new InvalidOperationException(
                $"Solo se actualizan agregados leídos en la misma unidad de trabajo ({Coleccion}).");
        return Task.CompletedTask;
    }

    protected Task<TAgregado?> ObtenerPorIdAsync(TId id, CancellationToken cancellationToken)
    {
        var clave = ClaveDe(id);
        if (unidadDeTrabajo.BuscarRastreado(Coleccion, clave) is TAgregado rastreado)
            return Task.FromResult<TAgregado?>(rastreado);

        var documento = baseDeDatos.Obtener(Coleccion, clave);
        return Task.FromResult(documento is null ? null : Materializar(documento, null));
    }

    /// <summary>
    /// Consulta simple sobre la colección: deserializa cada documento a memento y aplica el filtro.
    /// Una base documental real usaría índices; para la simulación basta un recorrido.
    /// </summary>
    protected Task<IReadOnlyList<TAgregado>> BuscarAsync(Func<TMemento, bool> filtro, CancellationToken cancellationToken)
    {
        var resultado = new List<TAgregado>();
        foreach (var documento in baseDeDatos.Listar(Coleccion))
        {
            if (unidadDeTrabajo.BuscarRastreado(Coleccion, documento.Id) is TAgregado rastreado)
            {
                if (filtro(rastreado.CrearMemento()))
                    resultado.Add(rastreado);
                continue;
            }

            var memento = serializador.Deserializar<TMemento>(documento.Json);
            if (filtro(memento))
                resultado.Add(Materializar(documento, memento));
        }
        return Task.FromResult<IReadOnlyList<TAgregado>>(resultado);
    }

    private TAgregado Materializar(Documento documento, TMemento? memento)
    {
        memento ??= serializador.Deserializar<TMemento>(documento.Json);
        var agregado = TAgregado.RestaurarDesde(memento);
        unidadDeTrabajo.RastrearExistente(
            Coleccion, documento.Id, agregado, documento.Version, documento.Json, () => Serializar(agregado));
        return agregado;
    }

    private string Serializar(TAgregado agregado) => serializador.Serializar(agregado.CrearMemento());
}
