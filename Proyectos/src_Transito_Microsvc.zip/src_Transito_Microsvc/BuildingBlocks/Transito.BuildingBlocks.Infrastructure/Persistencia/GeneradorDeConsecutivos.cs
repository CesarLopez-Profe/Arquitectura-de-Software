using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Persistencia;

/// <summary>
/// Secuencia al estilo de un SEQUENCE de base de datos: entrega números crecientes y se confirma
/// por fuera de la unidad de trabajo, así que pueden quedar huecos si un caso de uso falla
/// (igual que en una base de datos real). Usa concurrencia optimista con reintentos.
/// </summary>
public sealed class GeneradorDeConsecutivos(BaseDeDatosDocumental baseDeDatos, ISerializador serializador)
{
    private const int MaximoIntentos = 5;

    public long Siguiente(string clave)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(clave);

        for (var intento = 1; ; intento++)
        {
            var documento = baseDeDatos.Obtener(Colecciones.Consecutivos, clave);
            var actual = documento is null ? 0 : serializador.Deserializar<ConsecutivoDocumento>(documento.Json).Valor;
            var siguiente = new ConsecutivoDocumento(clave, actual + 1);
            var json = serializador.Serializar(siguiente);

            var lote = documento is null
                ? new LoteDeEscritura().Insertar(Colecciones.Consecutivos, clave, json)
                : new LoteDeEscritura().Actualizar(Colecciones.Consecutivos, clave, json, documento.Version);
            try
            {
                baseDeDatos.Confirmar(lote);
                return siguiente.Valor;
            }
            catch (ConflictoDeConcurrenciaException) when (intento < MaximoIntentos)
            {
                // Otro hilo tomó el número: se vuelve a leer y se intenta de nuevo.
            }
        }
    }
}
