using System.Text.Json;

namespace Transito.BuildingBlocks.Infrastructure.Serializacion;

/// <summary>
/// Patrón Strategy: el formato de serialización es intercambiable. Toda la infraestructura
/// (base de datos, mensajes, HTTP, archivos) depende de esta abstracción y no de System.Text.Json.
/// </summary>
public interface ISerializador
{
    string Serializar<T>(T valor, bool indentado = true);

    string Serializar(object valor, Type tipo, bool indentado = true);

    T Deserializar<T>(string json);

    JsonElement ConvertirAElemento(object valor, Type tipo);

    T Deserializar<T>(JsonElement elemento);
}
