using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Transito.BuildingBlocks.Infrastructure.Serializacion;

/// <summary>
/// Patrón Singleton (creacional). Microsoft recomienda reutilizar JsonSerializerOptions porque
/// guarda en caché los metadatos de cada tipo; crear opciones nuevas en cada llamada es costoso.
/// <para>
/// Constructor privado + <see cref="Lazy{T}"/> garantizan una sola instancia, creada de forma
/// perezosa y segura entre hilos. En el contenedor de dependencias se registra esa misma instancia.
/// </para>
/// </summary>
public sealed class SerializadorJson : ISerializador
{
    private static readonly Lazy<SerializadorJson> Unica =
        new(() => new SerializadorJson(), LazyThreadSafetyMode.ExecutionAndPublication);

    private readonly JsonSerializerOptions _indentado;
    private readonly JsonSerializerOptions _compacto;

    private SerializadorJson()
    {
        _indentado = CrearOpciones(indentado: true);
        _compacto = CrearOpciones(indentado: false);
    }

    public static SerializadorJson Instancia => Unica.Value;

    public string Serializar<T>(T valor, bool indentado = true) =>
        JsonSerializer.Serialize(valor, Opciones(indentado));

    public string Serializar(object valor, Type tipo, bool indentado = true) =>
        JsonSerializer.Serialize(valor, tipo, Opciones(indentado));

    public T Deserializar<T>(string json)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(json);
        return JsonSerializer.Deserialize<T>(json, _compacto)
               ?? throw new JsonException($"El JSON no representa un {typeof(T).Name}.");
    }

    public JsonElement ConvertirAElemento(object valor, Type tipo) =>
        JsonSerializer.SerializeToElement(valor, tipo, _compacto);

    public T Deserializar<T>(JsonElement elemento) =>
        elemento.Deserialize<T>(_compacto)
        ?? throw new JsonException($"El JSON no representa un {typeof(T).Name}.");

    private JsonSerializerOptions Opciones(bool indentado) => indentado ? _indentado : _compacto;

    private static JsonSerializerOptions CrearOpciones(bool indentado) => new(JsonSerializerDefaults.Web)
    {
        WriteIndented = indentado,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping, // conserva tildes legibles en los archivos
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Converters = { new JsonStringEnumConverter() }
    };
}
