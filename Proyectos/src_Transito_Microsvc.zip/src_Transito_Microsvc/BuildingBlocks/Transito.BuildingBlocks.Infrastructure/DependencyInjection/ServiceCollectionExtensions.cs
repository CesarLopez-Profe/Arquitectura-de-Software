using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Integracion;
using Transito.BuildingBlocks.Application.Notificaciones;
using Transito.BuildingBlocks.Application.Persistencia;
using Transito.BuildingBlocks.Application.Tiempo;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Mensajeria;
using Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;
using Transito.BuildingBlocks.Infrastructure.Mensajeria.Consumo;
using Transito.BuildingBlocks.Infrastructure.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra la infraestructura común de un microservicio: su propia base de datos, la unidad de
    /// trabajo, las bandejas de salida/entrada, el cliente HTTP y las notificaciones. Los elementos
    /// compartidos (broker, red, reloj) se toman del entorno.
    /// </summary>
    public static IServiceCollection AgregarBloquesDeInfraestructura(
        this IServiceCollection services,
        EntornoDeSimulacion entorno,
        OpcionesDeMicroservicio opciones)
    {
        ArgumentNullException.ThrowIfNull(entorno);
        ArgumentNullException.ThrowIfNull(opciones);

        // Plataforma compartida
        services.AddSingleton(entorno);
        services.AddSingleton(opciones);
        services.AddSingleton(entorno.Broker);
        services.AddSingleton(entorno.Red);
        services.AddSingleton<IClock>(entorno.Clock);
        services.AddSingleton(entorno.Serializador);
        services.AddSingleton(entorno.FabricaDeNotificaciones);

        // Persistencia propia del microservicio (base de datos por servicio)
        services.AddSingleton(new OpcionesDeBaseDeDatos
        {
            Nombre = opciones.Nombre,
            CarpetaEnDisco = Path.Combine(entorno.CarpetaRaiz, "bd", opciones.Nombre)
        });
        services.AddSingleton<BaseDeDatosDocumental>();
        services.AddSingleton<GeneradorDeConsecutivos>();
        services.AddScoped<UnidadDeTrabajoDocumental>();
        services.AddScoped<IUnidadDeTrabajo>(sp => sp.GetRequiredService<UnidadDeTrabajoDocumental>());

        // Mensajería: bandeja de salida y consumo
        services.AddSingleton<MonitorDeBandejaDeSalida>();
        services.AddHostedService<ProcesadorDeBandejaDeSalida>();
        services.AddHostedService<ServicioDeSuscripciones>();

        // HTTP saliente: proxy remoto decorado con reintentos
        services.AddScoped<ClienteHttpSimulado>();
        services.AddScoped<IClienteHttp>(sp => new ClienteHttpConReintentos(
            sp.GetRequiredService<ClienteHttpSimulado>(), 3, TimeSpan.FromMilliseconds(50),
            sp.GetRequiredService<ILoggerFactory>().CreateLogger("Http")));

        // Notificaciones a personas
        services.AddSingleton<IServicioDeNotificaciones, ServicioDeNotificaciones>();

        return services;
    }

    /// <summary>Configura, con el Builder de canales, por dónde salen los eventos de este microservicio.</summary>
    public static IServiceCollection AgregarCanalesDeSalida(
        this IServiceCollection services,
        Action<ConstructorDeCanales> configurar)
    {
        ArgumentNullException.ThrowIfNull(configurar);
        services.AddSingleton<IPublicadorDeMensajes>(sp =>
        {
            var constructor = new ConstructorDeCanales(
                sp.GetRequiredService<EntornoDeSimulacion>(),
                sp.GetRequiredService<OpcionesDeMicroservicio>().Nombre,
                sp.GetRequiredService<ILoggerFactory>());
            configurar(constructor);
            return constructor.Construir();
        });
        return services;
    }

    /// <summary>Declara que el microservicio consume un tópico con el manejador indicado.</summary>
    public static IServiceCollection AgregarConsumidor<TMensaje, TManejador>(this IServiceCollection services, string topico)
        where TManejador : class, IManejadorDeEventoDeIntegracion<TMensaje>
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(topico);
        var nombre = typeof(TManejador).Name;

        services.AddScoped<IManejadorDeEventoDeIntegracion<TMensaje>, TManejador>();
        services.AddSingleton(new RegistroDeConsumidor(
            topico,
            nombre,
            typeof(TMensaje),
            (raiz, mensaje, intento, ct) =>
                ProcesadorDeMensajeEntrante<TMensaje>.ProcesarAsync(raiz, nombre, mensaje, intento, ct)));
        return services;
    }
}
