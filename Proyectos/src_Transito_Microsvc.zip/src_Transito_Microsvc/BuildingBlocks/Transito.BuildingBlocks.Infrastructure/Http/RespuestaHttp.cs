namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>Respuesta HTTP simulada: código de estado, cuerpo JSON (texto) y encabezados.</summary>
public sealed record RespuestaHttp
{
    public RespuestaHttp(int codigo, string? cuerpo, IReadOnlyDictionary<string, string>? encabezados = null)
    {
        if (codigo is < 100 or > 599)
            throw new ArgumentOutOfRangeException(nameof(codigo), "Código HTTP inválido.");
        Codigo = codigo;
        Cuerpo = cuerpo;
        Encabezados = encabezados ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    }

    public int Codigo { get; }
    public string? Cuerpo { get; }
    public IReadOnlyDictionary<string, string> Encabezados { get; }
    public bool EsExitosa => Codigo is >= 200 and < 300;

    public RespuestaHttp ConEncabezado(string nombre, string valor)
    {
        var copia = new Dictionary<string, string>(Encabezados, StringComparer.OrdinalIgnoreCase) { [nombre] = valor };
        return new RespuestaHttp(Codigo, Cuerpo, copia);
    }
}
