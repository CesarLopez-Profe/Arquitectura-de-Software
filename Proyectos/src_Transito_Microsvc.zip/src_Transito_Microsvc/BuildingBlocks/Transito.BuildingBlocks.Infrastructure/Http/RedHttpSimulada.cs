using System.Collections.Concurrent;

namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>
/// Red HTTP SIMULADA: un directorio de "hosts" (sanciones, pagos, licencias, runt, policia) y
/// sus manejadores. Agrega latencia artificial y responde 503 si el host no está disponible,
/// como ocurriría con un servicio caído.
/// </summary>
public sealed class RedHttpSimulada
{
    private readonly ConcurrentDictionary<string, ManejadorHttp> _hosts = new(StringComparer.OrdinalIgnoreCase);
    private TimeSpan _latencia = TimeSpan.FromMilliseconds(2);

    /// <summary>Latencia de red simulada (0 a 2 segundos).</summary>
    public TimeSpan Latencia
    {
        get => _latencia;
        set => _latencia = value >= TimeSpan.Zero && value <= TimeSpan.FromSeconds(2)
            ? value
            : throw new ArgumentOutOfRangeException(nameof(Latencia), "Debe estar entre 0 y 2 segundos.");
    }

    public IReadOnlyCollection<string> Hosts => _hosts.Keys.ToList();

    public void RegistrarHost(string host, ManejadorHttp manejador)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(host);
        ArgumentNullException.ThrowIfNull(manejador);
        _hosts[host] = manejador;
    }

    public void RetirarHost(string host) => _hosts.TryRemove(host, out _);

    public async Task<RespuestaHttp> EnviarAsync(string host, SolicitudHttp solicitud, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(solicitud);
        if (Latencia > TimeSpan.Zero)
            await Task.Delay(Latencia, cancellationToken);

        return _hosts.TryGetValue(host, out var manejador)
            ? await manejador(solicitud, cancellationToken)
            : new RespuestaHttp(503, $$"""{"title":"Host '{{host}}' no disponible"}""");
    }
}
