using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Correlacion;

namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>
/// Patrón Proxy (proxy remoto): el adaptador que lo usa cree hablar con un cliente HTTP local,
/// pero cada llamada cruza la red simulada hacia otro microservicio. El proxy además agrega el
/// encabezado de correlación y registra la llamada.
/// </summary>
public sealed class ClienteHttpSimulado(
    RedHttpSimulada red,
    IContextoDeCorrelacion correlacion,
    ILogger<ClienteHttpSimulado> logger) : IClienteHttp
{
    public async Task<RespuestaHttp> EnviarAsync(string host, SolicitudHttp solicitud, CancellationToken cancellationToken)
    {
        var conCorrelacion = solicitud.ConEncabezado(EncabezadosHttp.Correlacion, correlacion.CorrelacionId.ToString());
        var cronometro = Stopwatch.StartNew();
        var respuesta = await red.EnviarAsync(host, conCorrelacion, cancellationToken);
        logger.LogInformation("HTTP saliente {Metodo} http://{Host}{Ruta} ← {Codigo} ({Ms} ms)",
            solicitud.Metodo, host, solicitud.Ruta, respuesta.Codigo, cronometro.ElapsedMilliseconds);
        return respuesta;
    }
}
