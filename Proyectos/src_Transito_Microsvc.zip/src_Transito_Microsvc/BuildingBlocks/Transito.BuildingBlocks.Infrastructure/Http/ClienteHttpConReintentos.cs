using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>
/// Patrón Decorator (resiliencia): reintenta las respuestas 5xx con espera creciente. El
/// adaptador que llama no cambia; solo cambia cómo se compone el cliente en el contenedor.
/// </summary>
public sealed class ClienteHttpConReintentos(IClienteHttp interno, int intentos, TimeSpan espera, ILogger logger)
    : IClienteHttp
{
    public async Task<RespuestaHttp> EnviarAsync(string host, SolicitudHttp solicitud, CancellationToken cancellationToken)
    {
        for (var intento = 1; ; intento++)
        {
            var respuesta = await interno.EnviarAsync(host, solicitud, cancellationToken);
            if (respuesta.Codigo < 500 || intento >= intentos)
                return respuesta;

            logger.LogWarning("HTTP {Host}{Ruta} respondió {Codigo}; reintento {Intento} de {Total}",
                host, solicitud.Ruta, respuesta.Codigo, intento + 1, intentos);
            await Task.Delay(espera * intento, cancellationToken);
        }
    }
}
