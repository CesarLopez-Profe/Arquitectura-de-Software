namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>Cliente HTTP que usan los adaptadores de infraestructura para llamar a otros servicios.</summary>
public interface IClienteHttp
{
    Task<RespuestaHttp> EnviarAsync(string host, SolicitudHttp solicitud, CancellationToken cancellationToken);
}
