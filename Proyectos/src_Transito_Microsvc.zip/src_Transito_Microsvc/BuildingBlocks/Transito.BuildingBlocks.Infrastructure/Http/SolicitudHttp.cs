namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>
/// Petición HTTP simulada. El cuerpo viaja como TEXTO JSON, igual que por la red real:
/// entre microservicios nunca se pasan objetos en memoria.
/// </summary>
public sealed record SolicitudHttp
{
    private SolicitudHttp(string metodo, string ruta, string? cuerpo, IReadOnlyDictionary<string, string> encabezados)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(metodo);
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        if (!ruta.StartsWith('/'))
            throw new ArgumentException("La ruta debe empezar por '/'.", nameof(ruta));

        Metodo = metodo.ToUpperInvariant();
        Ruta = ruta;
        Cuerpo = cuerpo;
        Encabezados = encabezados;
    }

    public string Metodo { get; }
    public string Ruta { get; }
    public string? Cuerpo { get; }
    public IReadOnlyDictionary<string, string> Encabezados { get; }

    public static SolicitudHttp Get(string ruta) => new("GET", ruta, null, Vacios());

    public static SolicitudHttp Post(string ruta, string cuerpoJson) =>
        new("POST", ruta, cuerpoJson, new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [EncabezadosHttp.TipoDeContenido] = "application/json"
        });

    public SolicitudHttp ConEncabezado(string nombre, string valor)
    {
        var copia = new Dictionary<string, string>(Encabezados, StringComparer.OrdinalIgnoreCase) { [nombre] = valor };
        return new SolicitudHttp(Metodo, Ruta, Cuerpo, copia);
    }

    public string? Encabezado(string nombre) => Encabezados.TryGetValue(nombre, out var valor) ? valor : null;

    private static Dictionary<string, string> Vacios() => new(StringComparer.OrdinalIgnoreCase);
}
