namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>Lo que un "servidor" registra en la red simulada para atender peticiones.</summary>
public delegate Task<RespuestaHttp> ManejadorHttp(SolicitudHttp solicitud, CancellationToken cancellationToken);
