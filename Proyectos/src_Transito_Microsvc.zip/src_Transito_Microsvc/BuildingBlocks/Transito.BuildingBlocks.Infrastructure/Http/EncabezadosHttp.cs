namespace Transito.BuildingBlocks.Infrastructure.Http;

/// <summary>Nombres de encabezados usados entre microservicios.</summary>
public static class EncabezadosHttp
{
    public const string Correlacion = "X-Correlation-Id";
    public const string TipoDeContenido = "Content-Type";
    public const string Ubicacion = "Location";
}
