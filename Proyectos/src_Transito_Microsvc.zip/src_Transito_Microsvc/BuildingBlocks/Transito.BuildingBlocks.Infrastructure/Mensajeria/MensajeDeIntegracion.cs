using System.Text.Json;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria;

/// <summary>
/// Envoltura (envelope) con la que viaja un evento de integración por cualquier canal.
/// Separa los metadatos de transporte (tópico, origen, correlación, encabezados) del contrato,
/// que va como JSON en <see cref="Contenido"/>. Se construye con <see cref="ConstructorDeMensaje"/>.
/// </summary>
public sealed record MensajeDeIntegracion(
    Guid Id,
    string Tipo,
    string Topico,
    string Origen,
    Guid CorrelacionId,
    DateTimeOffset OcurrioEn,
    JsonElement Contenido,
    IReadOnlyDictionary<string, string> Encabezados);
