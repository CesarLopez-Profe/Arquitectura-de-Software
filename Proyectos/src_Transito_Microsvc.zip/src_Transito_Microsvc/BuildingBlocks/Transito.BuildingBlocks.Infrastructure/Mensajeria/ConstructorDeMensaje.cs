using System.Text.Json;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria;

/// <summary>
/// Patrón Builder (creacional): el mensaje tiene muchos campos, varios obligatorios y otros
/// opcionales (encabezados). El constructor fluido evita un constructor de ocho parámetros y
/// valida todo en un solo punto, <see cref="Construir"/>, antes de entregar el objeto.
/// </summary>
public sealed class ConstructorDeMensaje
{
    private readonly Dictionary<string, string> _encabezados = new(StringComparer.OrdinalIgnoreCase);
    private Guid _id = Guid.NewGuid();
    private string? _tipo;
    private string? _topico;
    private string? _origen;
    private Guid _correlacionId;
    private DateTimeOffset _ocurrioEn;
    private JsonElement? _contenido;

    public ConstructorDeMensaje ConId(Guid id)
    {
        _id = id;
        return this;
    }

    public ConstructorDeMensaje DeTipo(string tipo)
    {
        _tipo = tipo;
        return this;
    }

    public ConstructorDeMensaje EnTopico(string topico)
    {
        _topico = topico;
        return this;
    }

    public ConstructorDeMensaje DesdeOrigen(string origen)
    {
        _origen = origen;
        return this;
    }

    public ConstructorDeMensaje ConCorrelacion(Guid correlacionId)
    {
        _correlacionId = correlacionId;
        return this;
    }

    public ConstructorDeMensaje OcurridoEn(DateTimeOffset fecha)
    {
        _ocurrioEn = fecha;
        return this;
    }

    public ConstructorDeMensaje ConContenido(JsonElement contenido)
    {
        _contenido = contenido;
        return this;
    }

    public ConstructorDeMensaje ConEncabezado(string nombre, string valor)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(nombre);
        _encabezados[nombre] = valor ?? string.Empty;
        return this;
    }

    public ConstructorDeMensaje ConEncabezados(IReadOnlyDictionary<string, string> encabezados)
    {
        foreach (var (nombre, valor) in encabezados)
            ConEncabezado(nombre, valor);
        return this;
    }

    public MensajeDeIntegracion Construir()
    {
        if (_id == Guid.Empty) throw new InvalidOperationException("El mensaje necesita un Id.");
        if (string.IsNullOrWhiteSpace(_tipo)) throw new InvalidOperationException("El mensaje necesita un tipo.");
        if (string.IsNullOrWhiteSpace(_topico)) throw new InvalidOperationException("El mensaje necesita un tópico.");
        if (string.IsNullOrWhiteSpace(_origen)) throw new InvalidOperationException("El mensaje necesita un origen.");
        if (_correlacionId == Guid.Empty) throw new InvalidOperationException("El mensaje necesita correlación.");
        if (_ocurrioEn == default) throw new InvalidOperationException("El mensaje necesita fecha de ocurrencia.");
        if (_contenido is null) throw new InvalidOperationException("El mensaje necesita contenido.");

        return new MensajeDeIntegracion(
            _id, _tipo, _topico, _origen, _correlacionId, _ocurrioEn, _contenido.Value,
            new Dictionary<string, string>(_encabezados, StringComparer.OrdinalIgnoreCase));
    }

    /// <summary>Atajo para crear un constructor a partir de un mensaje existente (reentregas).</summary>
    public static ConstructorDeMensaje DesdeExistente(MensajeDeIntegracion mensaje) =>
        new ConstructorDeMensaje()
            .ConId(mensaje.Id)
            .DeTipo(mensaje.Tipo)
            .EnTopico(mensaje.Topico)
            .DesdeOrigen(mensaje.Origen)
            .ConCorrelacion(mensaje.CorrelacionId)
            .OcurridoEn(mensaje.OcurrioEn)
            .ConContenido(mensaje.Contenido)
            .ConEncabezados(mensaje.Encabezados);
}
