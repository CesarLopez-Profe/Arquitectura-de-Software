using System.Threading.Channels;
using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>
/// Cola propia de un suscriptor (como una cola ligada a un exchange en RabbitMQ). Usa
/// System.Threading.Channels para entregar en segundo plano y en orden. Cada entrega se reintenta
/// con espera exponencial; al agotar los intentos el mensaje pasa a la cola de mensajes muertos.
/// Se puede pausar para simular que el microservicio consumidor está caído.
/// </summary>
internal sealed class Suscripcion : IDisposable
{
    private readonly Channel<MensajeDeIntegracion> _cola =
        Channel.CreateUnbounded<MensajeDeIntegracion>(new UnboundedChannelOptions { SingleReader = true });
    private readonly CancellationTokenSource _cancelacion = new();
    private readonly ManejadorDeEntrega _manejador;
    private readonly OpcionesDeBroker _opciones;
    private readonly Action<MensajeMuerto> _alMorir;
    private readonly ILogger _logger;
    private TaskCompletionSource _compuerta = NuevaCompuerta(abierta: true);
    private int _pendientes;

    public Suscripcion(
        string patron,
        string suscriptor,
        ManejadorDeEntrega manejador,
        OpcionesDeBroker opciones,
        Action<MensajeMuerto> alMorir,
        ILogger logger)
    {
        Patron = patron;
        Suscriptor = suscriptor;
        _manejador = manejador;
        _opciones = opciones;
        _alMorir = alMorir;
        _logger = logger;
        _ = Task.Run(BucleDeEntregaAsync);
    }

    public string Patron { get; }
    public string Suscriptor { get; }
    public bool Pausada => !_compuerta.Task.IsCompleted;
    public int Pendientes => Volatile.Read(ref _pendientes);

    public void Encolar(MensajeDeIntegracion mensaje)
    {
        Interlocked.Increment(ref _pendientes);
        if (!_cola.Writer.TryWrite(mensaje))
            Interlocked.Decrement(ref _pendientes);
    }

    public void Pausar()
    {
        if (!Pausada)
            _compuerta = NuevaCompuerta(abierta: false);
    }

    public void Reanudar() => _compuerta.TrySetResult();

    public void Dispose()
    {
        _cola.Writer.TryComplete();
        _cancelacion.Cancel();
        _compuerta.TrySetResult();
        _cancelacion.Dispose();
    }

    private async Task BucleDeEntregaAsync()
    {
        var token = _cancelacion.Token;
        try
        {
            await foreach (var mensaje in _cola.Reader.ReadAllAsync(token))
            {
                await _compuerta.Task.WaitAsync(token);
                try
                {
                    await EntregarConReintentosAsync(mensaje, token);
                }
                finally
                {
                    Interlocked.Decrement(ref _pendientes);
                }
            }
        }
        catch (OperationCanceledException)
        {
            // La suscripción se cerró.
        }
    }

    private async Task EntregarConReintentosAsync(MensajeDeIntegracion mensaje, CancellationToken token)
    {
        for (var intento = 1; ; intento++)
        {
            try
            {
                await _manejador(mensaje, intento, token);
                return;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                if (intento >= _opciones.MaximoIntentos)
                {
                    _logger.LogError("{Suscriptor} agotó {Intentos} intentos con {Tipo}: {Error} → cola de mensajes muertos",
                        Suscriptor, intento, mensaje.Tipo, ex.Message);
                    _alMorir(new MensajeMuerto(mensaje, Suscriptor, ex.Message, intento));
                    return;
                }

                var espera = _opciones.EsperaInicial * Math.Pow(2, intento - 1);
                _logger.LogWarning("{Suscriptor} falló con {Tipo} (intento {Intento}): {Error} → reintento en {Espera} ms",
                    Suscriptor, mensaje.Tipo, intento, ex.Message, (int)espera.TotalMilliseconds);
                await Task.Delay(espera, token);
            }
        }
    }

    private static TaskCompletionSource NuevaCompuerta(bool abierta)
    {
        var compuerta = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        if (abierta)
            compuerta.SetResult();
        return compuerta;
    }
}
