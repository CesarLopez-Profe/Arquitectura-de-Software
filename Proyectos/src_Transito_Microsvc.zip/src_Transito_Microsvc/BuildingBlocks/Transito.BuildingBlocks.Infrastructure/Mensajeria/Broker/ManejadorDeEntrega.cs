namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>Función que el suscriptor ejecuta por cada entrega (recibe el número de intento).</summary>
public delegate Task ManejadorDeEntrega(MensajeDeIntegracion mensaje, int intento, CancellationToken cancellationToken);
