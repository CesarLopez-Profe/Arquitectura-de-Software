namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>Mensaje que agotó sus reintentos (dead letter). Queda para revisión manual.</summary>
public sealed record MensajeMuerto(MensajeDeIntegracion Mensaje, string Suscriptor, string Error, int Intentos);
