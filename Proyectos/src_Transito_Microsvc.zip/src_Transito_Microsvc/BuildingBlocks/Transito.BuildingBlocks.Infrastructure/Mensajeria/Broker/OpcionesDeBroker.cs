namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>Política de reintentos del broker, con validación en los setters.</summary>
public sealed class OpcionesDeBroker
{
    private int _maximoIntentos = 3;
    private TimeSpan _esperaInicial = TimeSpan.FromMilliseconds(40);

    /// <summary>Entregas antes de enviar el mensaje a la cola de mensajes muertos (1 a 10).</summary>
    public int MaximoIntentos
    {
        get => _maximoIntentos;
        set => _maximoIntentos = value is >= 1 and <= 10
            ? value
            : throw new ArgumentOutOfRangeException(nameof(MaximoIntentos), "Debe estar entre 1 y 10.");
    }

    /// <summary>Espera antes del primer reintento; se duplica en cada intento (backoff exponencial).</summary>
    public TimeSpan EsperaInicial
    {
        get => _esperaInicial;
        set => _esperaInicial = value >= TimeSpan.Zero && value <= TimeSpan.FromSeconds(10)
            ? value
            : throw new ArgumentOutOfRangeException(nameof(EsperaInicial), "Debe estar entre 0 y 10 segundos.");
    }
}
