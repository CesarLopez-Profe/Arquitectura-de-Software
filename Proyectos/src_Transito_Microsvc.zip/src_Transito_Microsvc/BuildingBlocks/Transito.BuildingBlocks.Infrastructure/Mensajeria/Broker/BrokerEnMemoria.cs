using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>
/// Broker de mensajes SIMULADO (hace el papel de RabbitMQ / Azure Service Bus). Es el único
/// componente compartido entre microservicios, igual que en producción lo sería el bus.
/// <list type="bullet">
/// <item>Publicación/suscripción por tópicos con comodines (patrón Observer distribuido).</item>
/// <item>Una cola por suscriptor; entrega asíncrona, en orden y "al menos una vez".</item>
/// <item>Reintentos con espera exponencial y cola de mensajes muertos.</item>
/// <item>Pausar/reanudar suscriptores y reentregar mensajes, para demostrar resiliencia e idempotencia.</item>
/// </list>
/// </summary>
public sealed class BrokerEnMemoria(OpcionesDeBroker opciones, ILogger<BrokerEnMemoria> logger) : IDisposable
{
    private readonly ConcurrentDictionary<Guid, Suscripcion> _suscripciones = new();
    private readonly ConcurrentQueue<MensajeDeIntegracion> _historial = new();
    private readonly ConcurrentQueue<MensajeMuerto> _mensajesMuertos = new();

    public IReadOnlyCollection<MensajeDeIntegracion> Historial => _historial.ToArray();

    public IReadOnlyCollection<MensajeMuerto> MensajesMuertos => _mensajesMuertos.ToArray();

    /// <summary>Mensajes en cola o en proceso, sin contar los de suscriptores pausados.</summary>
    public int PendientesActivos => _suscripciones.Values.Where(s => !s.Pausada).Sum(s => s.Pendientes);

    public IDisposable Suscribir(string patronTopico, string suscriptor, ManejadorDeEntrega manejador)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(patronTopico);
        ArgumentException.ThrowIfNullOrWhiteSpace(suscriptor);
        ArgumentNullException.ThrowIfNull(manejador);

        var id = Guid.NewGuid();
        var suscripcion = new Suscripcion(
            patronTopico, suscriptor, manejador, opciones, _mensajesMuertos.Enqueue, logger);
        _suscripciones[id] = suscripcion;
        return new CancelacionDeSuscripcion(() =>
        {
            if (_suscripciones.TryRemove(id, out var eliminada))
                eliminada.Dispose();
        });
    }

    public Task PublicarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(mensaje);
        _historial.Enqueue(mensaje);

        var destinos = _suscripciones.Values.Where(s => PatronDeTopico.Coincide(s.Patron, mensaje.Topico)).ToList();
        foreach (var destino in destinos)
            destino.Encolar(mensaje);

        logger.LogInformation("{Tipo} [{Topico}] → {Destinos}",
            mensaje.Tipo, mensaje.Topico,
            destinos.Count == 0 ? "(sin suscriptores)" : string.Join(", ", destinos.Select(d => d.Suscriptor)));
        return Task.CompletedTask;
    }

    /// <summary>Vuelve a entregar un mensaje ya publicado (simula una entrega duplicada).</summary>
    public async Task<bool> ReentregarAsync(Guid mensajeId, CancellationToken cancellationToken = default)
    {
        var original = _historial.FirstOrDefault(m => m.Id == mensajeId);
        if (original is null)
            return false;

        logger.LogWarning("Reentrega simulada de {Tipo} {Id}", original.Tipo, original.Id);
        var duplicado = ConstructorDeMensaje.DesdeExistente(original).ConEncabezado("reentrega", "true").Construir();
        await PublicarAsync(duplicado, cancellationToken);
        return true;
    }

    /// <summary>Simula la caída de un microservicio: sus mensajes se acumulan en la cola.</summary>
    public void Pausar(string prefijoSuscriptor)
    {
        foreach (var s in DelSuscriptor(prefijoSuscriptor)) s.Pausar();
        logger.LogWarning("Suscriptores '{Prefijo}*' PAUSADOS (el servicio no consume)", prefijoSuscriptor);
    }

    public void Reanudar(string prefijoSuscriptor)
    {
        foreach (var s in DelSuscriptor(prefijoSuscriptor)) s.Reanudar();
        logger.LogInformation("Suscriptores '{Prefijo}*' reanudados", prefijoSuscriptor);
    }

    public int PendientesDe(string prefijoSuscriptor) => DelSuscriptor(prefijoSuscriptor).Sum(s => s.Pendientes);

    public void Dispose()
    {
        foreach (var suscripcion in _suscripciones.Values)
            suscripcion.Dispose();
        _suscripciones.Clear();
    }

    private IEnumerable<Suscripcion> DelSuscriptor(string prefijo) =>
        _suscripciones.Values.Where(s => s.Suscriptor.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase));
}
