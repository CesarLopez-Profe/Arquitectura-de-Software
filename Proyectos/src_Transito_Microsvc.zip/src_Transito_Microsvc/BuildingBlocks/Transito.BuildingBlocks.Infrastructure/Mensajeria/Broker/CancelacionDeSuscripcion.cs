namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

/// <summary>Devuelve el broker al suscribirse; al desecharlo se cancela la suscripción (una sola vez).</summary>
internal sealed class CancelacionDeSuscripcion(Action cancelar) : IDisposable
{
    private Action? _cancelar = cancelar;

    public void Dispose() => Interlocked.Exchange(ref _cancelar, null)?.Invoke();
}
