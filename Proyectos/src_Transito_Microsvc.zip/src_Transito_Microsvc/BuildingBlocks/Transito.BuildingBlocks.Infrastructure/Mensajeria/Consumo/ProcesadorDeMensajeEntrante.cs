using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Correlacion;
using Transito.BuildingBlocks.Application.Integracion;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Consumo;

/// <summary>
/// Pasos fijos para consumir un mensaje (Idempotent Consumer):
/// <list type="number">
/// <item>Abrir un alcance de dependencias propio (como una petición HTTP).</item>
/// <item>Propagar el identificador de correlación del mensaje.</item>
/// <item>Descartar el mensaje si la bandeja de entrada dice que ya se procesó.</item>
/// <item>Deserializar el contrato y llamar al manejador de integración.</item>
/// <item>Confirmar: los cambios y el registro en la bandeja de entrada van en la misma transacción.</item>
/// </list>
/// Si algo falla, nada se confirma y el broker reintenta.
/// </summary>
public static class ProcesadorDeMensajeEntrante<TMensaje>
{
    public static async Task ProcesarAsync(
        IServiceProvider raiz,
        string consumidor,
        MensajeDeIntegracion mensaje,
        int intento,
        CancellationToken cancellationToken)
    {
        await using var alcance = raiz.CreateAsyncScope();
        var servicios = alcance.ServiceProvider;
        var logger = servicios.GetRequiredService<ILoggerFactory>().CreateLogger("Consumo");

        servicios.GetRequiredService<IContextoDeCorrelacion>().Establecer(mensaje.CorrelacionId);
        var unidadDeTrabajo = servicios.GetRequiredService<UnidadDeTrabajoDocumental>();

        if (unidadDeTrabajo.MensajeYaProcesado(mensaje.Id, consumidor))
        {
            logger.LogWarning("Duplicado ignorado: {Tipo} {Id} ya fue procesado por {Consumidor} (bandeja de entrada)",
                mensaje.Tipo, mensaje.Id.ToString()[..8], consumidor);
            return;
        }

        var contenido = servicios.GetRequiredService<ISerializador>().Deserializar<TMensaje>(mensaje.Contenido);
        logger.LogInformation("Recibido {Tipo} desde {Origen} (intento {Intento}) → {Consumidor}",
            mensaje.Tipo, mensaje.Origen, intento, consumidor);

        unidadDeTrabajo.RegistrarMensajeProcesado(mensaje.Id, consumidor);
        var manejador = servicios.GetRequiredService<IManejadorDeEventoDeIntegracion<TMensaje>>();
        await manejador.ManejarAsync(
            contenido,
            new ContextoDeMensaje(mensaje.Id, mensaje.Topico, mensaje.Origen, mensaje.CorrelacionId, intento),
            cancellationToken);

        await unidadDeTrabajo.ConfirmarAsync(cancellationToken);
    }
}
