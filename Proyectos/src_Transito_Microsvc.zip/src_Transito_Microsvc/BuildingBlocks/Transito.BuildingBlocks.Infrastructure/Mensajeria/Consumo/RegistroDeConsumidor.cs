namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Consumo;

/// <summary>
/// Declara que un microservicio consume un tópico. La función de procesamiento ya conoce el
/// tipo del contrato (se cerró el genérico al registrarlo), así que no hace falta reflexión.
/// </summary>
public sealed record RegistroDeConsumidor(
    string Topico,
    string Nombre,
    Type TipoDeMensaje,
    Func<IServiceProvider, MensajeDeIntegracion, int, CancellationToken, Task> Procesar);
