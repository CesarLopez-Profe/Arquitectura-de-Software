using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Consumo;

/// <summary>
/// Servicio alojado: al arrancar el microservicio suscribe en el broker todos los consumidores
/// registrados; al detenerse, cancela las suscripciones.
/// </summary>
public sealed class ServicioDeSuscripciones(
    IServiceProvider raiz,
    BrokerEnMemoria broker,
    IEnumerable<RegistroDeConsumidor> registros,
    OpcionesDeMicroservicio opciones,
    ILogger<ServicioDeSuscripciones> logger) : IHostedService
{
    private readonly List<IDisposable> _suscripciones = [];

    public Task StartAsync(CancellationToken cancellationToken)
    {
        foreach (var registro in registros)
        {
            var suscriptor = $"{opciones.Nombre}/{registro.Nombre}";
            _suscripciones.Add(broker.Suscribir(
                registro.Topico,
                suscriptor,
                (mensaje, intento, ct) => registro.Procesar(raiz, mensaje, intento, ct)));
            logger.LogDebug("Suscrito a {Topico} como {Suscriptor}", registro.Topico, suscriptor);
        }
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        foreach (var suscripcion in _suscripciones)
            suscripcion.Dispose();
        _suscripciones.Clear();
        return Task.CompletedTask;
    }
}
