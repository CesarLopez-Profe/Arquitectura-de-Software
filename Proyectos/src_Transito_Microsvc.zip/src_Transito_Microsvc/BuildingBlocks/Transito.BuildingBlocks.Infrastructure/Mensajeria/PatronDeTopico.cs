namespace Transito.BuildingBlocks.Infrastructure.Mensajeria;

/// <summary>
/// Coincidencia de tópicos al estilo de un "topic exchange":
/// <c>*</c> = todos; <c>sanciones.*</c> = todo lo que empiece por "sanciones."; otro valor = exacto.
/// </summary>
public static class PatronDeTopico
{
    public static bool Coincide(string patron, string topico)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(patron);
        ArgumentException.ThrowIfNullOrWhiteSpace(topico);

        if (patron == "*")
            return true;
        if (patron.EndsWith(".*", StringComparison.Ordinal))
            return topico.StartsWith(patron[..^1], StringComparison.OrdinalIgnoreCase);
        return string.Equals(patron, topico, StringComparison.OrdinalIgnoreCase);
    }
}
