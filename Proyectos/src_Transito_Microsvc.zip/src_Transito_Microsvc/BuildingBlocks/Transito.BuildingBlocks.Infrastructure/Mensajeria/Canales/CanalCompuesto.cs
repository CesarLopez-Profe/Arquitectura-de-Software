using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Patrón Composite (estructural): un grupo de canales que se usa como si fuera uno solo.
/// El procesador de la bandeja de salida publica UNA vez y el compuesto reparte el mensaje
/// por todos los canales hijos. Si alguno falla, se intenta con los demás y al final se
/// informa el error para que el mensaje se reintente.
/// </summary>
public sealed class CanalCompuesto : ICanalDeMensajeria, IPublicadorDeMensajes
{
    private readonly IReadOnlyList<ICanalDeMensajeria> _canales;
    private readonly ILogger _logger;

    public CanalCompuesto(string nombre, IEnumerable<ICanalDeMensajeria> canales, ILogger logger)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(nombre);
        _canales = canales?.ToList() ?? throw new ArgumentNullException(nameof(canales));
        if (_canales.Count == 0)
            throw new ArgumentException("El canal compuesto necesita al menos un canal.", nameof(canales));
        Nombre = nombre;
        _logger = logger;
    }

    public string Nombre { get; }

    public IReadOnlyList<string> NombresDeCanales => _canales.Select(c => c.Nombre).ToList();

    public async Task PublicarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken) =>
        await EnviarAsync(mensaje, cancellationToken);

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        var entregados = new List<string>();
        var errores = new List<Exception>();

        foreach (var canal in _canales)
        {
            try
            {
                if (await canal.EnviarAsync(mensaje, cancellationToken))
                    entregados.Add(canal.Nombre);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                errores.Add(ex);
            }
        }

        _logger.LogInformation("Publicado {Tipo} por {Cantidad} canales: {Canales}",
            mensaje.Tipo, entregados.Count, string.Join(" | ", entregados));

        if (errores.Count > 0)
            throw new AggregateException($"Fallaron {errores.Count} canal(es) al publicar {mensaje.Tipo}.", errores);

        return entregados.Count > 0;
    }
}
