using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Canal webhook: envía el mensaje por HTTP POST (simulado) a un sistema externo suscrito,
/// por ejemplo el RUNT o la Policía de Tránsito. Una respuesta no exitosa cuenta como falla.
/// </summary>
public sealed class CanalWebhook(RedHttpSimulada red, string host, string ruta, ISerializador serializador)
    : ICanalDeMensajeria
{
    public string Nombre => $"webhook:{host}";

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        var solicitud = SolicitudHttp.Post(ruta, serializador.Serializar(mensaje, indentado: false))
            .ConEncabezado(EncabezadosHttp.Correlacion, mensaje.CorrelacionId.ToString())
            .ConEncabezado("X-Mensaje-Id", mensaje.Id.ToString())
            .ConEncabezado("X-Topico", mensaje.Topico);

        var respuesta = await red.EnviarAsync(host, solicitud, cancellationToken);
        if (!respuesta.EsExitosa)
            throw new InvalidOperationException($"El webhook {host}{ruta} respondió {respuesta.Codigo}.");
        return true;
    }
}
