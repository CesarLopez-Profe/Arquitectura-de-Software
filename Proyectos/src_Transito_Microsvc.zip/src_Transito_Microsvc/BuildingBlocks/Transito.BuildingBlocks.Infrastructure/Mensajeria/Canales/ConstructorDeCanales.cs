using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales.Decoradores;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Patrón Builder (creacional): arma paso a paso el árbol de canales de salida de un
/// microservicio. Cada canal agregado se envuelve automáticamente con los decoradores de
/// reintentos y registro, y con el filtro de tópico si se indica uno.
/// <code>
/// new ConstructorDeCanales(entorno, "licencias", loggerFactory)
///     .ConBusDeEventos()
///     .ConBitacoraDeAuditoria()
///     .ConWebhook("runt", "/webhooks/licencias", "licencias.*")
///     .Construir();
/// </code>
/// </summary>
public sealed class ConstructorDeCanales
{
    private static readonly TimeSpan EsperaEntreReintentos = TimeSpan.FromMilliseconds(30);
    private const int IntentosPorCanal = 3;

    private readonly List<ICanalDeMensajeria> _canales = [];
    private readonly EntornoDeSimulacion _entorno;
    private readonly string _servicio;
    private readonly ILogger _logger;

    public ConstructorDeCanales(EntornoDeSimulacion entorno, string servicio, ILoggerFactory loggerFactory)
    {
        _entorno = entorno ?? throw new ArgumentNullException(nameof(entorno));
        ArgumentException.ThrowIfNullOrWhiteSpace(servicio);
        _servicio = servicio;
        _logger = loggerFactory.CreateLogger("Canales");
    }

    public ConstructorDeCanales ConBusDeEventos() =>
        Agregar(new CanalBusDeEventos(_entorno.Broker), "*");

    public ConstructorDeCanales ConBitacoraDeAuditoria() =>
        Agregar(new CanalBitacoraDeAuditoria(
            Path.Combine(_entorno.CarpetaRaiz, "auditoria", "eventos.jsonl"), _entorno.Serializador), "*");

    public ConstructorDeCanales ConBuzonDeArchivos(string patronTopico = "*") =>
        Agregar(new CanalBuzonDeArchivos(
            Path.Combine(_entorno.CarpetaRaiz, "buzon-archivos", _servicio), _entorno.Serializador), patronTopico);

    public ConstructorDeCanales ConWebhook(string host, string ruta, string patronTopico) =>
        Agregar(new CanalWebhook(_entorno.Red, host, ruta, _entorno.Serializador), patronTopico);

    public ConstructorDeCanales Con(ICanalDeMensajeria canal, string patronTopico = "*") => Agregar(canal, patronTopico);

    public CanalCompuesto Construir() => new($"salida-{_servicio}", _canales, _logger);

    private ConstructorDeCanales Agregar(ICanalDeMensajeria canal, string patronTopico)
    {
        ArgumentNullException.ThrowIfNull(canal);
        ICanalDeMensajeria decorado = new CanalConReintentos(canal, IntentosPorCanal, EsperaEntreReintentos, _logger);
        decorado = new CanalConRegistro(decorado, _logger);
        if (patronTopico != "*")
            decorado = new CanalFiltradoPorTopico(decorado, patronTopico);
        _canales.Add(decorado);
        return this;
    }
}
