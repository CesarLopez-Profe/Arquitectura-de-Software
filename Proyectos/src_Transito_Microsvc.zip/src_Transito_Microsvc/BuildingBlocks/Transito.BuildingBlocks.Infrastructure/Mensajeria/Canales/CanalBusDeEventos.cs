using Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Patrón Adapter: adapta el <see cref="BrokerEnMemoria"/> a la interfaz común de canales.
/// Es el canal por el que se enteran los OTROS microservicios.
/// </summary>
public sealed class CanalBusDeEventos(BrokerEnMemoria broker) : ICanalDeMensajeria
{
    public string Nombre => "bus";

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        await broker.PublicarAsync(mensaje, cancellationToken);
        return true;
    }
}
