using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Canal de auditoría: agrega cada mensaje como una línea JSON (formato JSON Lines) a un archivo
/// de solo-anexar. Es una bitácora inmutable de todo lo que ocurrió en el sistema.
/// El cerrojo es estático porque varios microservicios escriben en el mismo archivo.
/// </summary>
public sealed class CanalBitacoraDeAuditoria(string rutaArchivo, ISerializador serializador) : ICanalDeMensajeria
{
    private static readonly SemaphoreSlim Cerrojo = new(1, 1);

    public string Nombre => "auditoria";

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        var linea = serializador.Serializar(mensaje, indentado: false) + Environment.NewLine;
        await Cerrojo.WaitAsync(cancellationToken);
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(rutaArchivo)!);
            await File.AppendAllTextAsync(rutaArchivo, linea, cancellationToken);
        }
        finally
        {
            Cerrojo.Release();
        }
        return true;
    }
}
