namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Un medio por el que sale un evento de integración: el bus interno, un archivo, una bitácora,
/// un webhook... Es el "componente" común del Composite y de los Decoradores.
/// </summary>
public interface ICanalDeMensajeria
{
    string Nombre { get; }

    /// <summary>Devuelve <c>false</c> si el canal no aplica a este mensaje (por ejemplo, por filtro de tópico).</summary>
    Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken);
}
