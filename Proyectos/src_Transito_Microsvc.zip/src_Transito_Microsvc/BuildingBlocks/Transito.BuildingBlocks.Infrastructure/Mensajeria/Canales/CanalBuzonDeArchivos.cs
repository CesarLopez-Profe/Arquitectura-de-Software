using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales;

/// <summary>
/// Canal de intercambio por archivos (como una carpeta SFTP compartida con un sistema heredado):
/// escribe cada mensaje como un archivo .json dentro de una carpeta por tópico.
/// </summary>
public sealed class CanalBuzonDeArchivos(string carpetaRaiz, ISerializador serializador) : ICanalDeMensajeria
{
    public string Nombre => "buzon-archivos";

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        var carpeta = Path.Combine(carpetaRaiz, mensaje.Topico);
        Directory.CreateDirectory(carpeta);
        var archivo = Path.Combine(carpeta, $"{mensaje.OcurrioEn:yyyyMMdd-HHmmss}_{mensaje.Id:N}.json");
        await File.WriteAllTextAsync(archivo, serializador.Serializar(mensaje), cancellationToken);
        return true;
    }
}
