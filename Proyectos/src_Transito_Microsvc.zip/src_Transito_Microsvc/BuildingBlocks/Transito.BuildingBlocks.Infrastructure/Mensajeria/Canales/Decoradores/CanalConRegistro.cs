using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales.Decoradores;

/// <summary>Patrón Decorator: registra duración y resultado de cada envío del canal decorado.</summary>
public sealed class CanalConRegistro(ICanalDeMensajeria interno, ILogger logger) : ICanalDeMensajeria
{
    public string Nombre => interno.Nombre;

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        var cronometro = Stopwatch.StartNew();
        try
        {
            var enviado = await interno.EnviarAsync(mensaje, cancellationToken);
            logger.LogDebug("Canal {Canal}: {Tipo} {Resultado} en {Ms} ms",
                Nombre, mensaje.Tipo, enviado ? "enviado" : "omitido", cronometro.ElapsedMilliseconds);
            return enviado;
        }
        catch (Exception ex)
        {
            logger.LogWarning("Canal {Canal}: {Tipo} falló definitivamente: {Error}", Nombre, mensaje.Tipo, ex.Message);
            throw;
        }
    }
}
