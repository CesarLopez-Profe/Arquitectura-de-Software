namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales.Decoradores;

/// <summary>
/// Patrón Decorator: el canal decorado solo recibe los mensajes cuyo tópico coincide con el
/// patrón. Así un webhook del RUNT recibe "licencias.*" sin que el webhook sepa filtrar.
/// </summary>
public sealed class CanalFiltradoPorTopico(ICanalDeMensajeria interno, string patronTopico) : ICanalDeMensajeria
{
    public string Nombre => interno.Nombre;

    public Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken) =>
        PatronDeTopico.Coincide(patronTopico, mensaje.Topico)
            ? interno.EnviarAsync(mensaje, cancellationToken)
            : Task.FromResult(false);
}
