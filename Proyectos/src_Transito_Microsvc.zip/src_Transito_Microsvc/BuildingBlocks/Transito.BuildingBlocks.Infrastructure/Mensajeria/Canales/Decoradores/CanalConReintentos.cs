using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Mensajeria.Canales.Decoradores;

/// <summary>
/// Patrón Decorator: agrega reintentos a CUALQUIER canal sin modificarlo. El canal decorado
/// no sabe que lo están reintentando; el que lo usa tampoco sabe que hay un decorador.
/// </summary>
public sealed class CanalConReintentos(ICanalDeMensajeria interno, int intentos, TimeSpan espera, ILogger logger)
    : ICanalDeMensajeria
{
    public string Nombre => interno.Nombre;

    public async Task<bool> EnviarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken)
    {
        for (var intento = 1; ; intento++)
        {
            try
            {
                return await interno.EnviarAsync(mensaje, cancellationToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException && intento < intentos)
            {
                logger.LogWarning("Canal {Canal}: intento {Intento} falló ({Error}); reintentando", Nombre, intento, ex.Message);
                await Task.Delay(espera * intento, cancellationToken);
            }
        }
    }
}
