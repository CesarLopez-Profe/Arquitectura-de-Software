namespace Transito.BuildingBlocks.Infrastructure.Mensajeria;

/// <summary>Lo que necesita el procesador de la bandeja de salida: "publica este mensaje".</summary>
public interface IPublicadorDeMensajes
{
    Task PublicarAsync(MensajeDeIntegracion mensaje, CancellationToken cancellationToken);
}
