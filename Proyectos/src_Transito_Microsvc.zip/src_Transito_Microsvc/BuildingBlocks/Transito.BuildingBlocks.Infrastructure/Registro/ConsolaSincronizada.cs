namespace Transito.BuildingBlocks.Infrastructure.Registro;

/// <summary>
/// Escritura en consola segura entre hilos: varios microservicios escriben a la vez y sin este
/// cerrojo los colores y las líneas se mezclarían.
/// </summary>
public static class ConsolaSincronizada
{
    private static readonly Lock Cerrojo = new();

    public static void EscribirLinea(params (string Texto, ConsoleColor? Color)[] segmentos)
    {
        lock (Cerrojo)
        {
            foreach (var (texto, color) in segmentos)
            {
                if (color is { } c) Console.ForegroundColor = c;
                Console.Write(texto);
                Console.ResetColor();
            }
            Console.WriteLine();
        }
    }
}
