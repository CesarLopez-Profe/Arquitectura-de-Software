using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Registro;

/// <summary>Proveedor de registro para Microsoft.Extensions.Logging que crea loggers compactos.</summary>
public sealed class ProveedorDeConsolaCompacta(string prefijo, ConsoleColor color, LogLevel minimo = LogLevel.Information)
    : ILoggerProvider
{
    public ILogger CreateLogger(string categoryName) =>
        new RegistradorDeConsolaCompacta(prefijo, color, minimo, categoryName);

    public void Dispose()
    {
    }
}
