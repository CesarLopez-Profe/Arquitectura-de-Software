using Microsoft.Extensions.Logging;

namespace Transito.BuildingBlocks.Infrastructure.Registro;

/// <summary>
/// Logger de una línea con el nombre del microservicio como prefijo de color, para que en la
/// consola se vea claramente qué servicio hizo qué.
/// </summary>
internal sealed class RegistradorDeConsolaCompacta(string prefijo, ConsoleColor color, LogLevel minimo, string categoria)
    : ILogger
{
    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

    public bool IsEnabled(LogLevel logLevel)
    {
        var umbral = categoria.StartsWith("Microsoft", StringComparison.Ordinal) ? LogLevel.Warning : minimo;
        return logLevel != LogLevel.None && logLevel >= umbral;
    }

    public void Log<TState>(
        LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        if (!IsEnabled(logLevel))
            return;

        var mensaje = formatter(state, exception);
        if (exception is not null)
            mensaje += $" | {exception.GetType().Name}: {exception.Message}";

        ConsoleColor? colorMensaje = logLevel switch
        {
            >= LogLevel.Error => ConsoleColor.Red,
            LogLevel.Warning => ConsoleColor.DarkYellow,
            LogLevel.Debug or LogLevel.Trace => ConsoleColor.DarkGray,
            _ => null
        };

        ConsolaSincronizada.EscribirLinea(
            ($"  [{prefijo,-10}] ", color),
            (mensaje, colorMensaje));
    }
}
