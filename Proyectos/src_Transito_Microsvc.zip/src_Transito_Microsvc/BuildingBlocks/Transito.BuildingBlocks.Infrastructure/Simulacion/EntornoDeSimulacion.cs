using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Transito.BuildingBlocks.Application.Tiempo;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Mensajeria.Broker;
using Transito.BuildingBlocks.Infrastructure.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Tiempo;

namespace Transito.BuildingBlocks.Infrastructure.Simulacion;

/// <summary>
/// Lo que en producción sería la "plataforma" que comparten los microservicios: el broker de
/// mensajes, la red, el reloj y la carpeta donde se reflejan bases de datos y buzones.
/// Cada microservicio recibe este entorno, pero conserva su propio contenedor, su propia base
/// de datos y sus propios procesos en segundo plano.
/// </summary>
public sealed class EntornoDeSimulacion : IDisposable
{
    private EntornoDeSimulacion(
        string carpetaRaiz,
        RelojSimulado reloj,
        BrokerEnMemoria broker,
        RedHttpSimulada red,
        IFabricaDeCanalesDeNotificacion fabricaDeNotificaciones)
    {
        CarpetaRaiz = carpetaRaiz;
        Reloj = reloj;
        Broker = broker;
        Red = red;
        FabricaDeNotificaciones = fabricaDeNotificaciones;
    }

    public string CarpetaRaiz { get; }
    public RelojSimulado Reloj { get; }
    public IClock Clock => Reloj;
    public BrokerEnMemoria Broker { get; }
    public RedHttpSimulada Red { get; }
    public ISerializador Serializador => SerializadorJson.Instancia;
    public IFabricaDeCanalesDeNotificacion FabricaDeNotificaciones { get; }

    /// <summary>
    /// Método fábrica (creacional): concentra en un solo lugar cómo se arma la plataforma.
    /// Borra la carpeta de una ejecución anterior para que cada corrida empiece limpia.
    /// </summary>
    public static EntornoDeSimulacion Crear(
        string carpetaRaiz,
        DateTimeOffset inicio,
        ILoggerFactory? loggerFactory = null,
        Func<string, IFabricaDeCanalesDeNotificacion>? crearFabricaDeNotificaciones = null,
        OpcionesDeBroker? opcionesDeBroker = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(carpetaRaiz);
        var carpeta = PrepararCarpeta(Path.GetFullPath(carpetaRaiz));

        loggerFactory ??= NullLoggerFactory.Instance;
        var broker = new BrokerEnMemoria(opcionesDeBroker ?? new OpcionesDeBroker(), loggerFactory.CreateLogger<BrokerEnMemoria>());
        var carpetaDeNotificaciones = Path.Combine(carpeta, "notificaciones");
        var fabrica = crearFabricaDeNotificaciones?.Invoke(carpetaDeNotificaciones)
                      ?? new FabricaDeCanalesSimulados(carpetaDeNotificaciones, SerializadorJson.Instancia, loggerFactory);

        return new EntornoDeSimulacion(carpeta, new RelojSimulado(inicio), broker, new RedHttpSimulada(), fabrica);
    }

    public void Dispose() => Broker.Dispose();

    /// <summary>
    /// Intenta borrar la ejecución anterior. Si la carpeta está bloqueada (por ejemplo, OneDrive la
    /// está sincronizando), usa una subcarpeta nueva para no detener la simulación.
    /// </summary>
    private static string PrepararCarpeta(string carpeta)
    {
        for (var intento = 1; intento <= 3 && Directory.Exists(carpeta); intento++)
        {
            try
            {
                Directory.Delete(carpeta, recursive: true);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                Thread.Sleep(300 * intento);
            }
        }

        if (Directory.Exists(carpeta) && Directory.EnumerateFileSystemEntries(carpeta).Any())
            carpeta = Path.Combine(carpeta, $"ejecucion-{DateTime.Now:yyyyMMdd-HHmmss}");

        Directory.CreateDirectory(carpeta);
        return carpeta;
    }
}
