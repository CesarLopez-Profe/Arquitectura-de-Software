using System.Text.RegularExpressions;

namespace Transito.BuildingBlocks.Infrastructure.Simulacion;

/// <summary>
/// Identidad y parámetros de un microservicio. El nombre se usa como host en la red simulada,
/// como origen de los mensajes y como nombre de su base de datos. Setters con validación.
/// </summary>
public sealed partial class OpcionesDeMicroservicio
{
    private string? _nombre;
    private TimeSpan _intervaloBandejaDeSalida = TimeSpan.FromMilliseconds(100);

    /// <summary>Solo minúsculas, números y guiones (es un nombre de host).</summary>
    public string Nombre
    {
        get => _nombre ?? throw new InvalidOperationException("El microservicio no tiene nombre configurado.");
        set
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(value);
            var limpio = value.Trim().ToLowerInvariant();
            if (!FormatoDeHost().IsMatch(limpio))
                throw new ArgumentException("El nombre solo admite minúsculas, números y guiones.", nameof(Nombre));
            _nombre = limpio;
        }
    }

    /// <summary>Cada cuánto se revisa la bandeja de salida (entre 20 ms y 10 s).</summary>
    public TimeSpan IntervaloBandejaDeSalida
    {
        get => _intervaloBandejaDeSalida;
        set => _intervaloBandejaDeSalida = value >= TimeSpan.FromMilliseconds(20) && value <= TimeSpan.FromSeconds(10)
            ? value
            : throw new ArgumentOutOfRangeException(nameof(IntervaloBandejaDeSalida), "Debe estar entre 20 ms y 10 s.");
    }

    [GeneratedRegex("^[a-z0-9-]{2,30}$")]
    private static partial Regex FormatoDeHost();
}
