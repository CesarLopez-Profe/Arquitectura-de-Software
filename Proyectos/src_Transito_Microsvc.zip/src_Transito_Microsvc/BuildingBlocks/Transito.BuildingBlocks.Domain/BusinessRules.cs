namespace Transito.BuildingBlocks.Domain;

/// <summary>Punto único para verificar reglas: si la regla está rota, lanza la excepción.</summary>
public static class BusinessRules
{
    public static void Check(IBusinessRule rule)
    {
        ArgumentNullException.ThrowIfNull(rule);
        if (rule.IsBroken())
            throw new BusinessRuleViolationException(rule);
    }
}
