namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Una operación del dominio incumplió una regla de negocio con nombre propio.
/// Conserva la regla para que las capas externas puedan informar cuál fue.
/// </summary>
public sealed class BusinessRuleViolationException(IBusinessRule brokenRule)
    : DomainException(brokenRule.Message)
{
    public IBusinessRule BrokenRule { get; } = brokenRule;
}
