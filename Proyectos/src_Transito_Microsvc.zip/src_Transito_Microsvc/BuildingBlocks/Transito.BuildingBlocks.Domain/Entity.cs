namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Objeto con identidad: dos entidades son iguales si tienen el mismo tipo e Id,
/// aunque el resto de sus datos difiera.
/// </summary>
public abstract class Entity<TId> where TId : notnull
{
    private TId _id = default!;
    private bool _tieneId;

    protected Entity(TId id) => Id = id;

    /// <summary>
    /// Getter: falla si la entidad nunca recibió identidad.
    /// Setter: rechaza el valor por defecto (por ejemplo, un Id construido con <c>default</c>).
    /// </summary>
    public TId Id
    {
        get => _tieneId
            ? _id
            : throw new InvalidOperationException($"{GetType().Name} no tiene identidad asignada.");
        protected set
        {
            if (value is null || EqualityComparer<TId>.Default.Equals(value, default!))
                throw new DomainException($"La identidad de {GetType().Name} es obligatoria.");
            _id = value;
            _tieneId = true;
        }
    }

    protected static void CheckRule(IBusinessRule rule) => BusinessRules.Check(rule);

    public override bool Equals(object? obj) =>
        obj is Entity<TId> other
        && GetType() == other.GetType()
        && _tieneId && other._tieneId
        && EqualityComparer<TId>.Default.Equals(_id, other._id);

    public override int GetHashCode() => HashCode.Combine(GetType(), _id);
}
