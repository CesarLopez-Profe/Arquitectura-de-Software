namespace Transito.BuildingBlocks.Domain.Especificaciones;

/// <summary>Nodo compuesto: invierte el resultado de otra especificación.</summary>
internal sealed class EspecificacionNo<T>(Especificacion<T> interna) : Especificacion<T>
{
    public override bool EsSatisfechaPor(T candidato) => !interna.EsSatisfechaPor(candidato);
}
