namespace Transito.BuildingBlocks.Domain.Especificaciones;

/// <summary>Nodo compuesto: se cumple si se cumple al menos una de las especificaciones.</summary>
internal sealed class EspecificacionO<T>(Especificacion<T> izquierda, Especificacion<T> derecha)
    : Especificacion<T>
{
    public override bool EsSatisfechaPor(T candidato) =>
        izquierda.EsSatisfechaPor(candidato) || derecha.EsSatisfechaPor(candidato);
}
