namespace Transito.BuildingBlocks.Domain.Especificaciones;

/// <summary>Nodo compuesto: se cumple si se cumplen ambas especificaciones.</summary>
internal sealed class EspecificacionY<T>(Especificacion<T> izquierda, Especificacion<T> derecha)
    : Especificacion<T>
{
    public override bool EsSatisfechaPor(T candidato) =>
        izquierda.EsSatisfechaPor(candidato) && derecha.EsSatisfechaPor(candidato);
}
