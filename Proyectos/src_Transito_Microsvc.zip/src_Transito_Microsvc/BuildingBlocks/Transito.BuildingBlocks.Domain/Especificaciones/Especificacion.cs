namespace Transito.BuildingBlocks.Domain.Especificaciones;

/// <summary>
/// Patrón Specification (Evans/Fowler) implementado con Composite: cada especificación es un
/// predicado de negocio con nombre propio, y se combinan con Y / O / No para formar otras más
/// complejas sin modificar las existentes (abierto/cerrado).
/// </summary>
public abstract class Especificacion<T>
{
    public abstract bool EsSatisfechaPor(T candidato);

    public Especificacion<T> Y(Especificacion<T> otra) => new EspecificacionY<T>(this, otra);

    public Especificacion<T> O(Especificacion<T> otra) => new EspecificacionO<T>(this, otra);

    public Especificacion<T> No() => new EspecificacionNo<T>(this);
}
