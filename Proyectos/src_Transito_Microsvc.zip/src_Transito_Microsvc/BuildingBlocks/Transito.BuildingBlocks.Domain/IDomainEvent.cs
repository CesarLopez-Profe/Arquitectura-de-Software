namespace Transito.BuildingBlocks.Domain;

/// <summary>Hecho relevante para el negocio que ya ocurrió dentro de un contexto delimitado.</summary>
public interface IDomainEvent
{
    Guid EventoId { get; }
    DateTimeOffset OcurrioEn { get; }
}
