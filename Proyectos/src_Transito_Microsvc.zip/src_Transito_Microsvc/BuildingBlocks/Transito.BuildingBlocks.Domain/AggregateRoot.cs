namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Raíz de agregado: única puerta de entrada para modificar el agregado,
/// garante de sus invariantes y emisora de sus eventos de dominio.
/// </summary>
public abstract class AggregateRoot<TId> : Entity<TId>, IAggregateRoot where TId : notnull
{
    private readonly List<IDomainEvent> _domainEvents = [];

    protected AggregateRoot(TId id) : base(id) { }

    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    protected void Raise(IDomainEvent domainEvent) =>
        _domainEvents.Add(domainEvent ?? throw new ArgumentNullException(nameof(domainEvent)));

    public void ClearDomainEvents() => _domainEvents.Clear();
}
