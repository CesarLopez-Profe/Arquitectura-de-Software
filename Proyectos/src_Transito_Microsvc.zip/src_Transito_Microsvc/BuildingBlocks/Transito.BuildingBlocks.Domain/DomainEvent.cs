namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Base de los eventos de dominio. Es un record porque un hecho pasado es inmutable
/// y se compara por sus datos.
/// </summary>
public abstract record DomainEvent(DateTimeOffset OcurrioEn) : IDomainEvent
{
    public Guid EventoId { get; init; } = Guid.NewGuid();
}
