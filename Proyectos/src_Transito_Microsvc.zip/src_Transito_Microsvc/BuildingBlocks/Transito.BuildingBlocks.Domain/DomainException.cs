namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Invariante violada al construir o modificar un objeto del dominio
/// (por ejemplo, un value object con formato inválido o un setter que recibe un dato prohibido).
/// </summary>
public class DomainException(string message) : Exception(message);
