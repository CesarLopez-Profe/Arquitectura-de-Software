namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Vista no genérica de una raíz de agregado. Permite a la infraestructura recoger los eventos
/// de cualquier agregado sin conocer el tipo de su identificador.
/// </summary>
public interface IAggregateRoot
{
    IReadOnlyCollection<IDomainEvent> DomainEvents { get; }
    void ClearDomainEvents();
}
