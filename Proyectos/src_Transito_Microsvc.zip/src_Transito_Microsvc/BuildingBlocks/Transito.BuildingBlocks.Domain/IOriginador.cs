namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Patrón Memento (comportamiento). El agregado (originador) sabe producir una instantánea
/// de su estado con tipos primitivos y reconstruirse a partir de ella, sin exponer setters
/// públicos. La infraestructura serializa la instantánea a JSON sin conocer las reglas internas.
/// </summary>
/// <typeparam name="TSelf">El propio agregado (permite el método estático abstracto).</typeparam>
/// <typeparam name="TMemento">Instantánea serializable del estado.</typeparam>
public interface IOriginador<TSelf, TMemento> where TSelf : IOriginador<TSelf, TMemento>
{
    TMemento CrearMemento();

    /// <summary>
    /// Reconstruye el agregado. No emite eventos: el hecho ya ocurrió cuando se guardó.
    /// Los setters vuelven a validar cada dato, así que un documento corrupto no entra al modelo.
    /// </summary>
    static abstract TSelf RestaurarDesde(TMemento memento);
}
