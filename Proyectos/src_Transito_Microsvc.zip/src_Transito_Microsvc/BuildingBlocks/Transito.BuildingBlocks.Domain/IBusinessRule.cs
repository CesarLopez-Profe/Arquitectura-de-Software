namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Regla de negocio explícita. Cada regla es una clase con nombre propio para que el
/// lenguaje ubicuo quede visible en el código y cada regla se pruebe por separado.
/// </summary>
public interface IBusinessRule
{
    bool IsBroken();
    string Message { get; }
}
