namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Value object monetario. Es el único concepto de negocio del shared kernel
/// porque su significado es idéntico en todos los contextos.
/// Inmutable: las operaciones devuelven un Dinero nuevo.
/// </summary>
public sealed record Dinero : IComparable<Dinero>
{
    public const string MonedaPorDefecto = "COP";

    private readonly decimal _monto;
    private readonly string? _moneda;

    private Dinero() { }

    /// <summary>Setter: no admite negativos y redondea a dos decimales.</summary>
    public decimal Monto
    {
        get => _monto;
        private init => _monto = decimal.Round(
            Guard.NoNegativo(value, nameof(Monto)), 2, MidpointRounding.AwayFromZero);
    }

    /// <summary>Setter: exige un código ISO 4217 de tres letras. Getter: exige que exista.</summary>
    public string Moneda
    {
        get => Guard.Inicializado(_moneda, nameof(Moneda));
        private init
        {
            var codigo = Guard.Texto(value, nameof(Moneda), 3).ToUpperInvariant();
            if (codigo.Length != 3 || !codigo.All(char.IsAsciiLetter))
                throw new DomainException("La moneda debe ser un código ISO 4217 de tres letras.");
            _moneda = codigo;
        }
    }

    public bool EsCero => Monto == 0;

    /// <summary>Método fábrica: única forma de crear Dinero (siempre válido).</summary>
    public static Dinero De(decimal monto, string moneda = MonedaPorDefecto) =>
        new() { Monto = monto, Moneda = moneda };

    public static Dinero Cero(string moneda = MonedaPorDefecto) => De(0, moneda);

    public Dinero Sumar(Dinero otro)
    {
        ValidarMismaMoneda(otro);
        return De(Monto + otro.Monto, Moneda);
    }

    public Dinero Restar(Dinero otro)
    {
        ValidarMismaMoneda(otro);
        return De(Monto - otro.Monto, Moneda);
    }

    public Dinero AplicarDescuento(decimal porcentaje)
    {
        if (porcentaje is < 0 or > 100)
            throw new DomainException("El porcentaje de descuento debe estar entre 0 y 100.");

        return De(Monto * (100 - porcentaje) / 100, Moneda);
    }

    public int CompareTo(Dinero? otro)
    {
        if (otro is null) return 1;
        ValidarMismaMoneda(otro);
        return Monto.CompareTo(otro.Monto);
    }

    public static bool operator >(Dinero a, Dinero b) => a.CompareTo(b) > 0;
    public static bool operator <(Dinero a, Dinero b) => a.CompareTo(b) < 0;
    public static bool operator >=(Dinero a, Dinero b) => a.CompareTo(b) >= 0;
    public static bool operator <=(Dinero a, Dinero b) => a.CompareTo(b) <= 0;

    public override string ToString() => $"{Monto:N2} {Moneda}";

    private void ValidarMismaMoneda(Dinero otro)
    {
        ArgumentNullException.ThrowIfNull(otro);
        if (Moneda != otro.Moneda)
            throw new DomainException($"No se pueden operar {Moneda} y {otro.Moneda}.");
    }
}
