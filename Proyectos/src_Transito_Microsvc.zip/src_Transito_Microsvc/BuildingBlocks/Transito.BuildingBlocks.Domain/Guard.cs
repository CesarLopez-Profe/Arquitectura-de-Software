namespace Transito.BuildingBlocks.Domain;

/// <summary>
/// Cláusulas de guarda usadas en los setters y getters del dominio.
/// <para>
/// Setters: lanzan <see cref="DomainException"/> porque el dato que llega es inválido para el negocio.
/// Getters: lanzan <see cref="InvalidOperationException"/> porque leer una propiedad que nunca se
/// asignó es un error de programación (el objeto no debió existir en ese estado).
/// </para>
/// Centralizar estas validaciones evita repetir el mismo <c>if</c> en cada propiedad (DRY)
/// y unifica los mensajes de error.
/// </summary>
public static class Guard
{
    public const int LongitudMaximaPorDefecto = 250;

    // ---------- Validaciones para setters ----------

    public static T NoNulo<T>(T? valor, string campo) where T : class =>
        valor ?? throw new DomainException($"El campo '{campo}' es obligatorio.");

    public static T NoPorDefecto<T>(T valor, string campo) where T : struct =>
        EqualityComparer<T>.Default.Equals(valor, default)
            ? throw new DomainException($"El campo '{campo}' es obligatorio.")
            : valor;

    /// <summary>Texto obligatorio: no vacío, sin espacios sobrantes y con longitud máxima.</summary>
    public static string Texto(string? valor, string campo, int longitudMaxima = LongitudMaximaPorDefecto)
    {
        if (string.IsNullOrWhiteSpace(valor))
            throw new DomainException($"El campo '{campo}' es obligatorio.");

        var limpio = valor.Trim();
        if (limpio.Length > longitudMaxima)
            throw new DomainException($"El campo '{campo}' admite máximo {longitudMaxima} caracteres.");
        return limpio;
    }

    /// <summary>Texto opcional: vacío se normaliza a null; si trae contenido, se valida su longitud.</summary>
    public static string? TextoOpcional(string? valor, string campo, int longitudMaxima = LongitudMaximaPorDefecto) =>
        string.IsNullOrWhiteSpace(valor) ? null : Texto(valor, campo, longitudMaxima);

    public static Guid NoVacio(Guid valor, string campo) =>
        valor == Guid.Empty ? throw new DomainException($"El campo '{campo}' es obligatorio.") : valor;

    public static int EnRango(int valor, int minimo, int maximo, string campo) =>
        valor < minimo || valor > maximo
            ? throw new DomainException($"El campo '{campo}' debe estar entre {minimo} y {maximo}.")
            : valor;

    public static int Positivo(int valor, string campo) =>
        valor <= 0 ? throw new DomainException($"El campo '{campo}' debe ser mayor que cero.") : valor;

    public static decimal NoNegativo(decimal valor, string campo) =>
        valor < 0 ? throw new DomainException($"El campo '{campo}' no puede ser negativo.") : valor;

    public static TEnum Definido<TEnum>(TEnum valor, string campo) where TEnum : struct, Enum =>
        Enum.IsDefined(valor) ? valor : throw new DomainException($"El valor '{valor}' no es válido para '{campo}'.");

    public static DateTimeOffset FechaValida(DateTimeOffset valor, string campo) =>
        valor == default ? throw new DomainException($"El campo '{campo}' debe tener una fecha válida.") : valor;

    public static DateOnly FechaValida(DateOnly valor, string campo) =>
        valor == default ? throw new DomainException($"El campo '{campo}' debe tener una fecha válida.") : valor;

    // ---------- Validaciones para getters ----------

    /// <summary>Getter de referencia: falla si el campo de respaldo nunca se asignó.</summary>
    public static T Inicializado<T>(T? valor, string campo) where T : class =>
        valor ?? throw new InvalidOperationException(
            $"La propiedad '{campo}' se leyó antes de ser inicializada; el objeto está incompleto.");

    /// <summary>Getter de valor: falla si el campo de respaldo conserva su valor por defecto.</summary>
    public static T Asignado<T>(T valor, string campo) where T : struct =>
        EqualityComparer<T>.Default.Equals(valor, default)
            ? throw new InvalidOperationException(
                $"La propiedad '{campo}' se leyó antes de ser asignada; el objeto está incompleto.")
            : valor;
}
