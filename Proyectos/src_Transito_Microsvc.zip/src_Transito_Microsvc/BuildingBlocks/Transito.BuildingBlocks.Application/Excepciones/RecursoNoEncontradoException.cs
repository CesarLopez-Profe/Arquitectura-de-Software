namespace Transito.BuildingBlocks.Application.Excepciones;

/// <summary>El recurso solicitado no existe. La API la traduce a HTTP 404.</summary>
public sealed class RecursoNoEncontradoException(string recurso, object clave)
    : Exception($"No existe {recurso} '{clave}'.")
{
    public string Recurso { get; } = recurso;
}
