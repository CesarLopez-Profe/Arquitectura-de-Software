namespace Transito.BuildingBlocks.Application.Excepciones;

/// <summary>
/// Otro proceso modificó el mismo documento entre la lectura y la escritura (concurrencia
/// optimista). La API la traduce a HTTP 409 y el bus de mensajes reintenta.
/// </summary>
public sealed class ConflictoDeConcurrenciaException(string mensaje) : Exception(mensaje);
