using Transito.BuildingBlocks.Application.Validacion;

namespace Transito.BuildingBlocks.Application.Excepciones;

/// <summary>La solicitud no tiene la forma esperada. La API la traduce a HTTP 400.</summary>
public sealed class ValidacionException(IReadOnlyList<ErrorDeValidacion> errores)
    : Exception("La solicitud tiene datos inválidos.")
{
    public IReadOnlyList<ErrorDeValidacion> Errores { get; } = errores;
}
