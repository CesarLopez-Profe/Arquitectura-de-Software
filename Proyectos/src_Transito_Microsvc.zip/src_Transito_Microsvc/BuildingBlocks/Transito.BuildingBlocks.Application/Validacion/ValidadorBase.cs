namespace Transito.BuildingBlocks.Application.Validacion;

/// <summary>
/// Patrón Template Method: el algoritmo (crear colector → aplicar reglas → devolver errores)
/// está fijo aquí; cada validador concreto solo completa el paso <see cref="DefinirReglas"/>.
/// </summary>
public abstract class ValidadorBase<T> : IValidador<T>
{
    public IReadOnlyList<ErrorDeValidacion> Validar(T instancia)
    {
        ArgumentNullException.ThrowIfNull(instancia);
        var colector = new ColectorDeErrores();
        DefinirReglas(instancia, colector);
        return colector.Errores;
    }

    protected abstract void DefinirReglas(T instancia, ColectorDeErrores errores);
}
