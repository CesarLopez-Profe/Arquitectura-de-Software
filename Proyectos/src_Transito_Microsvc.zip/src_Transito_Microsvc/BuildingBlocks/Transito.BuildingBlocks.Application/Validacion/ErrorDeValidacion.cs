namespace Transito.BuildingBlocks.Application.Validacion;

/// <summary>Un campo de la solicitud y el motivo por el que es inválido.</summary>
public sealed record ErrorDeValidacion(string Campo, string Mensaje);
