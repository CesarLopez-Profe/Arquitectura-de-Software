namespace Transito.BuildingBlocks.Application.Validacion;

/// <summary>
/// Interfaz fluida para declarar reglas de entrada. Acumula todos los errores en lugar de
/// detenerse en el primero, para que el cliente pueda corregirlos de una sola vez.
/// </summary>
public sealed class ColectorDeErrores
{
    private readonly List<ErrorDeValidacion> _errores = [];

    public IReadOnlyList<ErrorDeValidacion> Errores => _errores.AsReadOnly();

    public ColectorDeErrores Requerido(string? valor, string campo, int longitudMaxima = 250)
    {
        if (string.IsNullOrWhiteSpace(valor))
            return Agregar(campo, "Es obligatorio.");
        if (valor.Trim().Length > longitudMaxima)
            return Agregar(campo, $"Admite máximo {longitudMaxima} caracteres.");
        return this;
    }

    public ColectorDeErrores NoVacio(Guid valor, string campo) =>
        valor == Guid.Empty ? Agregar(campo, "Es obligatorio.") : this;

    public ColectorDeErrores Positivo(decimal valor, string campo) =>
        valor <= 0 ? Agregar(campo, "Debe ser mayor que cero.") : this;

    public ColectorDeErrores EnRango(int valor, int minimo, int maximo, string campo) =>
        valor < minimo || valor > maximo ? Agregar(campo, $"Debe estar entre {minimo} y {maximo}.") : this;

    public ColectorDeErrores EnumValido<TEnum>(string? valor, string campo) where TEnum : struct, Enum
    {
        var valido = Enum.TryParse<TEnum>(valor, ignoreCase: true, out var resultado)
                     && Enum.IsDefined(resultado)
                     && !int.TryParse(valor, out _);
        return valido
            ? this
            : Agregar(campo, $"Valores permitidos: {string.Join(", ", Enum.GetNames<TEnum>())}.");
    }

    public ColectorDeErrores Cumple(bool condicion, string campo, string mensaje) =>
        condicion ? this : Agregar(campo, mensaje);

    private ColectorDeErrores Agregar(string campo, string mensaje)
    {
        _errores.Add(new ErrorDeValidacion(campo, mensaje));
        return this;
    }
}
