namespace Transito.BuildingBlocks.Application.Validacion;

/// <summary>Valida la forma de una solicitud. Puede haber varios validadores por solicitud.</summary>
public interface IValidador<in T>
{
    IReadOnlyList<ErrorDeValidacion> Validar(T instancia);
}
