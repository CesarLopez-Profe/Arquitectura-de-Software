namespace Transito.BuildingBlocks.Application.Notificaciones;

/// <summary>Puerto de salida hacia las personas (correo, SMS, push). Se implementa en infraestructura.</summary>
public interface IServicioDeNotificaciones
{
    Task NotificarAsync(Notificacion notificacion, CancellationToken cancellationToken);
}
