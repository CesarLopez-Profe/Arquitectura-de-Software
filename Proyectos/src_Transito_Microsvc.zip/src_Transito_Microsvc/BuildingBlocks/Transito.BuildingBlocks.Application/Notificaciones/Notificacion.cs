namespace Transito.BuildingBlocks.Application.Notificaciones;

/// <summary>Mensaje para una persona (no para otro sistema). Se valida al construirse.</summary>
public sealed record Notificacion
{
    public Notificacion(string destinatario, string asunto, string mensaje, CanalDeNotificacion canales)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinatario);
        ArgumentException.ThrowIfNullOrWhiteSpace(asunto);
        ArgumentException.ThrowIfNullOrWhiteSpace(mensaje);
        if (canales == CanalDeNotificacion.Ninguno)
            throw new ArgumentException("La notificación debe indicar al menos un canal.", nameof(canales));

        Destinatario = destinatario.Trim();
        Asunto = asunto.Trim();
        Mensaje = mensaje.Trim();
        Canales = canales;
    }

    public string Destinatario { get; }
    public string Asunto { get; }
    public string Mensaje { get; }
    public CanalDeNotificacion Canales { get; }
}
