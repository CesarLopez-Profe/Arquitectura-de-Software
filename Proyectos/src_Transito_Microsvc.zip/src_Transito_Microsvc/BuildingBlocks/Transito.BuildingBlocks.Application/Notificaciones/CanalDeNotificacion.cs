namespace Transito.BuildingBlocks.Application.Notificaciones;

/// <summary>Canales por los que se avisa a una persona. Es [Flags]: se pueden combinar.</summary>
[Flags]
public enum CanalDeNotificacion
{
    Ninguno = 0,
    Email = 1,
    Sms = 2,
    Push = 4
}
