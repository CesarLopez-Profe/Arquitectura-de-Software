namespace Transito.BuildingBlocks.Application.Tiempo;

/// <summary>
/// Puerto hacia la hora actual. El dominio no lo usa: la capa de aplicación consulta la hora
/// y la pasa como parámetro (<c>ahora</c>), lo que mantiene el núcleo determinista y fácil de probar.
/// </summary>
public interface IClock
{
    DateTimeOffset Now { get; }
}
