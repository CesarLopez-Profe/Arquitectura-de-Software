namespace Transito.BuildingBlocks.Application.Correlacion;

/// <summary>
/// Se registra con alcance (scoped): una instancia por petición o por mensaje consumido.
/// Getter: si nadie lo estableció, genera uno nuevo (la operación empieza aquí).
/// Setter (Establecer): rechaza identificadores vacíos.
/// </summary>
public sealed class ContextoDeCorrelacion : IContextoDeCorrelacion
{
    private Guid _correlacionId;

    public Guid CorrelacionId
    {
        get
        {
            if (_correlacionId == Guid.Empty)
                _correlacionId = Guid.NewGuid();
            return _correlacionId;
        }
    }

    public void Establecer(Guid correlacionId)
    {
        if (correlacionId == Guid.Empty)
            throw new ArgumentException("El identificador de correlación no puede ser vacío.", nameof(correlacionId));
        _correlacionId = correlacionId;
    }
}
