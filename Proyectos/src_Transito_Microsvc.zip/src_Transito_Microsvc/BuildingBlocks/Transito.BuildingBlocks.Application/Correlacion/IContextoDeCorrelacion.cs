namespace Transito.BuildingBlocks.Application.Correlacion;

/// <summary>
/// Identificador que sigue a una operación de negocio a través de todos los microservicios
/// (petición HTTP → evento → consumidor → nuevo evento). Facilita la trazabilidad distribuida.
/// </summary>
public interface IContextoDeCorrelacion
{
    Guid CorrelacionId { get; }
    void Establecer(Guid correlacionId);
}
