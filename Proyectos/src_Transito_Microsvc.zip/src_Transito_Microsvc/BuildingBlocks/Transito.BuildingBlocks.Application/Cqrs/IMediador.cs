namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Patrón Mediator: quien envía una solicitud (API, consumidor de mensajes) no conoce al
/// manejador que la atiende. Así la capa de presentación depende de una sola abstracción.
/// </summary>
public interface IMediador
{
    Task<TRespuesta> EnviarAsync<TRespuesta>(
        ISolicitud<TRespuesta> solicitud,
        CancellationToken cancellationToken = default);
}
