namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>CQRS: pregunta que no modifica el estado. Nunca abre transacción.</summary>
public interface IConsulta<TRespuesta> : ISolicitud<TRespuesta>;
