namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>Especialización semántica: el manejador atiende un comando.</summary>
public interface IManejadorDeComando<in TComando, TRespuesta> : IManejadorDeSolicitud<TComando, TRespuesta>
    where TComando : IComando<TRespuesta>;
