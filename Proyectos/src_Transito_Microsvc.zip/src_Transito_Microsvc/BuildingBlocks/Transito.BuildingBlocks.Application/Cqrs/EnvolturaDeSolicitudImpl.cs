using Microsoft.Extensions.DependencyInjection;

namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Arma la cadena de responsabilidad: cada comportamiento recibe el "siguiente paso" y decide
/// qué hacer antes y después de él. El último eslabón es el manejador del caso de uso.
/// </summary>
internal sealed class EnvolturaDeSolicitudImpl<TSolicitud, TRespuesta> : EnvolturaDeSolicitud<TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    public override Task<TRespuesta> ManejarAsync(
        ISolicitud<TRespuesta> solicitud,
        IServiceProvider servicios,
        CancellationToken cancellationToken)
    {
        var concreta = (TSolicitud)solicitud;
        var manejador = servicios.GetRequiredService<IManejadorDeSolicitud<TSolicitud, TRespuesta>>();

        SiguientePaso<TRespuesta> siguiente = () => manejador.ManejarAsync(concreta, cancellationToken);

        // Se recorren al revés para que el primer comportamiento registrado sea el más externo.
        foreach (var comportamiento in servicios
                     .GetServices<IComportamientoDePipeline<TSolicitud, TRespuesta>>()
                     .Reverse())
        {
            var pasoActual = siguiente;
            siguiente = () => comportamiento.ManejarAsync(concreta, pasoActual, cancellationToken);
        }

        return siguiente();
    }
}
