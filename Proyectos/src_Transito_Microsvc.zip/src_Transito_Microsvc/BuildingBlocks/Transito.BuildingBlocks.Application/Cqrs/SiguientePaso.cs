namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>Invoca el siguiente eslabón de la cadena de comportamientos.</summary>
public delegate Task<TRespuesta> SiguientePaso<TRespuesta>();
