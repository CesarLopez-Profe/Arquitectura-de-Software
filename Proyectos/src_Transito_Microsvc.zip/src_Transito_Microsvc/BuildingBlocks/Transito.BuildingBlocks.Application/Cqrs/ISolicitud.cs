namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Marcador común de comandos y consultas. El parámetro genérico permite que el mediador
/// infiera el tipo de respuesta en tiempo de compilación.
/// </summary>
public interface ISolicitud<TRespuesta>;
