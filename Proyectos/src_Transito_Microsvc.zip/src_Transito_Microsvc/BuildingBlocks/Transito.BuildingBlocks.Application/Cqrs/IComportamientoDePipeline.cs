namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Patrón Chain of Responsibility: un eslabón transversal (registro, validación, transacción)
/// que envuelve a todos los casos de uso sin que estos lo sepan. Agregar un comportamiento nuevo
/// no obliga a modificar ningún manejador (abierto/cerrado).
/// </summary>
public interface IComportamientoDePipeline<in TSolicitud, TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    Task<TRespuesta> ManejarAsync(
        TSolicitud solicitud,
        SiguientePaso<TRespuesta> siguiente,
        CancellationToken cancellationToken);
}
