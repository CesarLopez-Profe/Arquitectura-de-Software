namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>Especialización semántica: el manejador atiende una consulta.</summary>
public interface IManejadorDeConsulta<in TConsulta, TRespuesta> : IManejadorDeSolicitud<TConsulta, TRespuesta>
    where TConsulta : IConsulta<TRespuesta>;
