namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>Caso de uso: atiende exactamente un tipo de solicitud (responsabilidad única).</summary>
public interface IManejadorDeSolicitud<in TSolicitud, TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    Task<TRespuesta> ManejarAsync(TSolicitud solicitud, CancellationToken cancellationToken);
}
