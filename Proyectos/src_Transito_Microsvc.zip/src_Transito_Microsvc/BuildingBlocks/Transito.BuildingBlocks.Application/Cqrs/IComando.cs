namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Patrón Command + CQRS: intención de cambiar el estado del sistema.
/// Los comandos se confirman en una unidad de trabajo (ver TransaccionComportamiento).
/// </summary>
public interface IComando<TRespuesta> : ISolicitud<TRespuesta>;
