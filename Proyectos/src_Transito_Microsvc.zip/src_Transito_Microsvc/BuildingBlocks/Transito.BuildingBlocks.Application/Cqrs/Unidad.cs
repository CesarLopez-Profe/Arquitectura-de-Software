namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>Respuesta "vacía" para comandos que no devuelven datos (equivalente a void).</summary>
public readonly record struct Unidad
{
    public static readonly Unidad Valor = new();
}
