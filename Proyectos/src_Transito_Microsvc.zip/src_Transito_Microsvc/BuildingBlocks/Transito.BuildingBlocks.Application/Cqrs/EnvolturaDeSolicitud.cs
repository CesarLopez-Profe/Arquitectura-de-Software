namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Puente entre la llamada genérica del mediador (que solo conoce TRespuesta) y el manejador
/// concreto (que necesita también el tipo exacto de la solicitud).
/// </summary>
internal abstract class EnvolturaDeSolicitud<TRespuesta>
{
    public abstract Task<TRespuesta> ManejarAsync(
        ISolicitud<TRespuesta> solicitud,
        IServiceProvider servicios,
        CancellationToken cancellationToken);
}
