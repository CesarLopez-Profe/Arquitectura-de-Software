using System.Collections.Concurrent;

namespace Transito.BuildingBlocks.Application.Cqrs;

/// <summary>
/// Implementación del mediador. Resuelve el manejador y la cadena de comportamientos desde el
/// contenedor del alcance (scope) actual. La envoltura genérica por tipo de solicitud se crea una
/// sola vez y se reutiliza, de modo que la reflexión solo se paga en la primera llamada.
/// </summary>
public sealed class Mediador(IServiceProvider servicios) : IMediador
{
    private static readonly ConcurrentDictionary<Type, object> Envolturas = new();

    public Task<TRespuesta> EnviarAsync<TRespuesta>(
        ISolicitud<TRespuesta> solicitud,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(solicitud);

        var envoltura = (EnvolturaDeSolicitud<TRespuesta>)Envolturas.GetOrAdd(
            solicitud.GetType(),
            tipo => Activator.CreateInstance(
                typeof(EnvolturaDeSolicitudImpl<,>).MakeGenericType(tipo, typeof(TRespuesta)))!);

        return envoltura.ManejarAsync(solicitud, servicios, cancellationToken);
    }
}
