using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.Integracion;

/// <summary>
/// Template Method: arma el <see cref="EventoDeIntegracion"/> conservando el Id y la fecha del
/// evento de dominio; cada traductor concreto solo define el tópico y el contrato.
/// </summary>
public abstract class TraductorDeEventoDeDominio<TEvento> : ITraductorDeEventoDeDominio
    where TEvento : IDomainEvent
{
    public Type TipoDeEvento => typeof(TEvento);

    protected abstract string Topico { get; }

    public EventoDeIntegracion Traducir(IDomainEvent evento) =>
        evento is TEvento tipado
            ? new EventoDeIntegracion(tipado.EventoId, Topico, CrearContrato(tipado), tipado.OcurrioEn)
            : throw new ArgumentException(
                $"{GetType().Name} no traduce eventos {evento.GetType().Name}.", nameof(evento));

    protected abstract object CrearContrato(TEvento evento);
}
