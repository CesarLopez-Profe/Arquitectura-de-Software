namespace Transito.BuildingBlocks.Application.Integracion;

/// <summary>Metadatos de la entrega de un mensaje: quién lo envió, por qué tópico y en qué intento.</summary>
public sealed record ContextoDeMensaje(
    Guid MensajeId,
    string Topico,
    string Origen,
    Guid CorrelacionId,
    int Intento);
