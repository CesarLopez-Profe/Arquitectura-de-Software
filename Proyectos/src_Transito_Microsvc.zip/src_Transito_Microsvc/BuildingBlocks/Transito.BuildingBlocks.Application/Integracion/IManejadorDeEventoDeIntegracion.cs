namespace Transito.BuildingBlocks.Application.Integracion;

/// <summary>
/// Consumidor de un evento publicado por OTRO microservicio. Recibe el contrato (record *V1),
/// lo traduce al lenguaje propio y normalmente envía un comando por el mediador.
/// </summary>
public interface IManejadorDeEventoDeIntegracion<in TMensaje>
{
    Task ManejarAsync(TMensaje mensaje, ContextoDeMensaje contexto, CancellationToken cancellationToken);
}
