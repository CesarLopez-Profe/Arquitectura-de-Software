namespace Transito.BuildingBlocks.Application.Integracion;

/// <summary>
/// Resultado de traducir un evento de dominio al lenguaje publicado: el tópico donde se
/// publicará y el contrato (record *V1 de un proyecto Contracts). Se guarda en la bandeja de salida.
/// </summary>
public sealed record EventoDeIntegracion
{
    public EventoDeIntegracion(Guid id, string topico, object contenido, DateTimeOffset ocurrioEn)
    {
        if (id == Guid.Empty)
            throw new ArgumentException("El evento de integración necesita un identificador.", nameof(id));
        ArgumentException.ThrowIfNullOrWhiteSpace(topico);

        Id = id;
        Topico = topico;
        Contenido = contenido ?? throw new ArgumentNullException(nameof(contenido));
        OcurrioEn = ocurrioEn;
    }

    /// <summary>Mismo Id del evento de dominio: permite rastrear y detectar duplicados.</summary>
    public Guid Id { get; }
    public string Topico { get; }
    public object Contenido { get; }
    public DateTimeOffset OcurrioEn { get; }
}
