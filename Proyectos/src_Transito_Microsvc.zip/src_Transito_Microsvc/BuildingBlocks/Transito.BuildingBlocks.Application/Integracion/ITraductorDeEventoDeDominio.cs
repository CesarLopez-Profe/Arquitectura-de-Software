using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.Integracion;

/// <summary>
/// Patrón Strategy + abierto/cerrado: cada evento de dominio que se publica fuera del
/// microservicio tiene su propio traductor. Publicar un evento nuevo = agregar una clase,
/// sin tocar la unidad de trabajo ni otros traductores.
/// </summary>
public interface ITraductorDeEventoDeDominio
{
    Type TipoDeEvento { get; }
    EventoDeIntegracion Traducir(IDomainEvent evento);
}
