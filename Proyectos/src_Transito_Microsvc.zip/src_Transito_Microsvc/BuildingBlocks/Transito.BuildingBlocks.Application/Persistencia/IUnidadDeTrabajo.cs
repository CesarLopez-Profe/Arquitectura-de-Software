namespace Transito.BuildingBlocks.Application.Persistencia;

/// <summary>
/// Patrón Unit of Work: agrupa todos los cambios de un caso de uso y los confirma de forma
/// atómica. Llamarlo cuando no hay cambios pendientes no hace nada.
/// </summary>
public interface IUnidadDeTrabajo
{
    Task ConfirmarAsync(CancellationToken cancellationToken = default);
}
