using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Validacion;

namespace Transito.BuildingBlocks.Application.Comportamientos;

/// <summary>
/// Valida la forma de la solicitud (campos obligatorios, formatos, rangos) antes de llegar al
/// dominio. Las reglas de negocio siguen viviendo en el dominio; aquí solo se filtra la entrada.
/// </summary>
public sealed class ValidacionComportamiento<TSolicitud, TRespuesta>(IEnumerable<IValidador<TSolicitud>> validadores)
    : IComportamientoDePipeline<TSolicitud, TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    public Task<TRespuesta> ManejarAsync(
        TSolicitud solicitud,
        SiguientePaso<TRespuesta> siguiente,
        CancellationToken cancellationToken)
    {
        var errores = validadores.SelectMany(v => v.Validar(solicitud)).ToList();
        if (errores.Count > 0)
            throw new ValidacionException(errores);

        return siguiente();
    }
}
