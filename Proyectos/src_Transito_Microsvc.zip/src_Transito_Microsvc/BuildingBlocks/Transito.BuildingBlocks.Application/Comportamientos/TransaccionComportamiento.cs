using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Persistencia;

namespace Transito.BuildingBlocks.Application.Comportamientos;

/// <summary>
/// Eslabón más interno: si la solicitud es un comando y el manejador terminó sin errores,
/// confirma la unidad de trabajo (agregados + bandeja de salida en una sola transacción).
/// Las consultas pasan de largo. Así ningún manejador tiene que acordarse de "guardar".
/// </summary>
public sealed class TransaccionComportamiento<TSolicitud, TRespuesta>(IUnidadDeTrabajo unidadDeTrabajo)
    : IComportamientoDePipeline<TSolicitud, TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    public async Task<TRespuesta> ManejarAsync(
        TSolicitud solicitud,
        SiguientePaso<TRespuesta> siguiente,
        CancellationToken cancellationToken)
    {
        if (solicitud is not IComando<TRespuesta>)
            return await siguiente();

        var respuesta = await siguiente();
        await unidadDeTrabajo.ConfirmarAsync(cancellationToken);
        return respuesta;
    }
}
