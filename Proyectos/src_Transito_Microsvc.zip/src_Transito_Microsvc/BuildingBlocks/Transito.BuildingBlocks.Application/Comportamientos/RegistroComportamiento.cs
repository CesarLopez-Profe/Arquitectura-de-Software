using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Transito.BuildingBlocks.Application.Comportamientos;

/// <summary>Eslabón más externo: mide y registra cada caso de uso y su resultado.</summary>
public sealed class RegistroComportamiento<TSolicitud, TRespuesta>(
    ILogger<RegistroComportamiento<TSolicitud, TRespuesta>> logger)
    : IComportamientoDePipeline<TSolicitud, TRespuesta>
    where TSolicitud : ISolicitud<TRespuesta>
{
    public async Task<TRespuesta> ManejarAsync(
        TSolicitud solicitud,
        SiguientePaso<TRespuesta> siguiente,
        CancellationToken cancellationToken)
    {
        var tipo = solicitud is IComando<TRespuesta> ? "Comando" : "Consulta";
        var nombre = typeof(TSolicitud).Name;
        var cronometro = Stopwatch.StartNew();
        try
        {
            var respuesta = await siguiente();
            logger.LogDebug("{Tipo} {Nombre} completado en {Ms} ms", tipo, nombre, cronometro.ElapsedMilliseconds);
            return respuesta;
        }
        catch (Exception ex)
        {
            logger.LogWarning("{Tipo} {Nombre} rechazado: {Motivo}", tipo, nombre, ex.Message);
            throw;
        }
    }
}
