using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.EventosDeDominio;

/// <summary>Notifica los eventos de dominio a todos sus observadores dentro del microservicio.</summary>
public interface IDespachadorDeEventosDeDominio
{
    Task DespacharAsync(IReadOnlyCollection<IDomainEvent> eventos, CancellationToken cancellationToken);
}
