using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.EventosDeDominio;

/// <summary>
/// Sujeto del patrón Observer. Se ejecuta DESPUÉS de confirmar la transacción, para efectos
/// secundarios (notificaciones). Si un observador falla, se registra y los demás continúan:
/// un correo que no sale no debe deshacer una sanción ya registrada.
/// </summary>
public sealed class DespachadorDeEventosDeDominio(
    IEnumerable<IManejadorDeEventoDeDominio> manejadores,
    ILogger<DespachadorDeEventosDeDominio> logger) : IDespachadorDeEventosDeDominio
{
    public async Task DespacharAsync(IReadOnlyCollection<IDomainEvent> eventos, CancellationToken cancellationToken)
    {
        foreach (var evento in eventos)
        {
            foreach (var manejador in manejadores.Where(m => m.TipoDeEvento.IsInstanceOfType(evento)))
            {
                try
                {
                    await manejador.ManejarAsync(evento, cancellationToken);
                }
                catch (Exception ex)
                {
                    logger.LogError("El observador {Manejador} falló con {Evento}: {Error}",
                        manejador.GetType().Name, evento.GetType().Name, ex.Message);
                }
            }
        }
    }
}
