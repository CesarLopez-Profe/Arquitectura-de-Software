using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.EventosDeDominio;

/// <summary>
/// Template Method: resuelve el filtrado y la conversión de tipo una sola vez; cada manejador
/// concreto solo implementa <see cref="AlOcurrirAsync"/> con el evento ya tipado.
/// </summary>
public abstract class ManejadorDeEventoDeDominio<TEvento> : IManejadorDeEventoDeDominio
    where TEvento : IDomainEvent
{
    public Type TipoDeEvento => typeof(TEvento);

    public Task ManejarAsync(IDomainEvent evento, CancellationToken cancellationToken) =>
        evento is TEvento tipado ? AlOcurrirAsync(tipado, cancellationToken) : Task.CompletedTask;

    protected abstract Task AlOcurrirAsync(TEvento evento, CancellationToken cancellationToken);
}
