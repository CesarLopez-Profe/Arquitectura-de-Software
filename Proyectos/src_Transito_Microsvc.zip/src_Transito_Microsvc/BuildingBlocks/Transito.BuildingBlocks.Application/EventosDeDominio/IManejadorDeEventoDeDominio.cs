using Transito.BuildingBlocks.Domain;

namespace Transito.BuildingBlocks.Application.EventosDeDominio;

/// <summary>
/// Observador (patrón Observer) de un evento de dominio dentro del mismo microservicio.
/// La versión no genérica permite al despachador tratar a todos los manejadores por igual.
/// </summary>
public interface IManejadorDeEventoDeDominio
{
    Type TipoDeEvento { get; }
    Task ManejarAsync(IDomainEvent evento, CancellationToken cancellationToken);
}
