using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using Transito.BuildingBlocks.Application.Comportamientos;
using Transito.BuildingBlocks.Application.Correlacion;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Integracion;
using Transito.BuildingBlocks.Application.Validacion;

namespace Transito.BuildingBlocks.Application.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra el mediador, la cadena de comportamientos y, por convención, todos los
    /// manejadores, validadores, observadores y traductores del ensamblado de aplicación.
    /// Agregar un caso de uso nuevo no exige tocar este registro (abierto/cerrado).
    /// </summary>
    public static IServiceCollection AgregarBloquesDeAplicacion(this IServiceCollection services, Assembly ensamblado)
    {
        ArgumentNullException.ThrowIfNull(ensamblado);

        services.AddScoped<IMediador, Mediador>();
        services.AddScoped<IContextoDeCorrelacion, ContextoDeCorrelacion>();
        services.AddScoped<IDespachadorDeEventosDeDominio, DespachadorDeEventosDeDominio>();

        // Cadena de responsabilidad: el orden de registro es el orden de ejecución (de afuera hacia adentro).
        services.AddScoped(typeof(IComportamientoDePipeline<,>), typeof(RegistroComportamiento<,>));
        services.AddScoped(typeof(IComportamientoDePipeline<,>), typeof(ValidacionComportamiento<,>));
        services.AddScoped(typeof(IComportamientoDePipeline<,>), typeof(TransaccionComportamiento<,>));

        var tiposConcretos = ensamblado.GetTypes()
            .Where(t => t is { IsClass: true, IsAbstract: false, IsGenericTypeDefinition: false })
            .ToList();

        foreach (var tipo in tiposConcretos)
        {
            RegistrarInterfacesGenericas(services, tipo, typeof(IManejadorDeSolicitud<,>));
            RegistrarInterfacesGenericas(services, tipo, typeof(IValidador<>));

            if (typeof(IManejadorDeEventoDeDominio).IsAssignableFrom(tipo))
                services.AddScoped(typeof(IManejadorDeEventoDeDominio), tipo);

            if (typeof(ITraductorDeEventoDeDominio).IsAssignableFrom(tipo))
                services.AddSingleton(typeof(ITraductorDeEventoDeDominio), tipo);
        }

        return services;
    }

    private static void RegistrarInterfacesGenericas(IServiceCollection services, Type tipo, Type definicion)
    {
        foreach (var interfaz in tipo.GetInterfaces()
                     .Where(i => i.IsGenericType && i.GetGenericTypeDefinition() == definicion))
        {
            services.AddScoped(interfaz, tipo);
        }
    }
}
