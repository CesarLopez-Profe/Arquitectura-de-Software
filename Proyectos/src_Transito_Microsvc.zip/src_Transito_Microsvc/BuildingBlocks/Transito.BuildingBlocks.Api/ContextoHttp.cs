using System.Globalization;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Validacion;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Todo lo que un endpoint necesita de la petición: parámetros de ruta y de consulta, el cuerpo
/// deserializado y los servicios del alcance actual (incluido el mediador).
/// </summary>
public sealed class ContextoHttp
{
    private IReadOnlyDictionary<string, string> _parametrosDeRuta = new Dictionary<string, string>();

    public ContextoHttp(SolicitudHttp solicitud, IServiceProvider servicios, ISerializador serializador)
    {
        Solicitud = solicitud ?? throw new ArgumentNullException(nameof(solicitud));
        Servicios = servicios ?? throw new ArgumentNullException(nameof(servicios));
        Serializador = serializador ?? throw new ArgumentNullException(nameof(serializador));

        var partes = solicitud.Ruta.Split('?', 2);
        RutaSinConsulta = partes[0].TrimEnd('/') is { Length: > 0 } ruta ? ruta : "/";
        ParametrosDeConsulta = partes.Length > 1 ? LeerConsulta(partes[1]) : new Dictionary<string, string>();
    }

    public SolicitudHttp Solicitud { get; }
    public IServiceProvider Servicios { get; }
    public ISerializador Serializador { get; }
    public string RutaSinConsulta { get; }
    public IReadOnlyDictionary<string, string> ParametrosDeConsulta { get; }

    public IMediador Mediador => Servicios.GetRequiredService<IMediador>();

    internal void EstablecerParametrosDeRuta(IReadOnlyDictionary<string, string> parametros) =>
        _parametrosDeRuta = parametros;

    public string Parametro(string nombre) =>
        _parametrosDeRuta.TryGetValue(nombre, out var valor)
            ? valor
            : throw new InvalidOperationException($"La ruta no define el parámetro '{nombre}'.");

    public Guid ParametroGuid(string nombre) =>
        Guid.TryParse(Parametro(nombre), out var guid)
            ? guid
            : throw Invalido(nombre, "Debe ser un identificador GUID válido.");

    public string? Consulta(string nombre) =>
        ParametrosDeConsulta.TryGetValue(nombre, out var valor) ? valor : null;

    public DateTimeOffset? ConsultaFecha(string nombre)
    {
        var texto = Consulta(nombre);
        if (texto is null) return null;
        return DateTimeOffset.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.None, out var fecha)
            ? fecha
            : throw Invalido(nombre, "Debe ser una fecha ISO 8601.");
    }

    /// <summary>Deserializa el cuerpo JSON. Un cuerpo ausente o mal formado se informa como 400.</summary>
    public T LeerCuerpo<T>()
    {
        if (string.IsNullOrWhiteSpace(Solicitud.Cuerpo))
            throw Invalido("cuerpo", "La petición debe incluir un cuerpo JSON.");
        try
        {
            return Serializador.Deserializar<T>(Solicitud.Cuerpo);
        }
        catch (JsonException ex)
        {
            throw Invalido("cuerpo", $"JSON inválido: {ex.Message}");
        }
    }

    private static ValidacionException Invalido(string campo, string mensaje) =>
        new([new ErrorDeValidacion(campo, mensaje)]);

    private static Dictionary<string, string> LeerConsulta(string consulta) =>
        consulta.Split('&', StringSplitOptions.RemoveEmptyEntries)
            .Select(par => par.Split('=', 2))
            .ToDictionary(
                par => Uri.UnescapeDataString(par[0]),
                par => par.Length > 1 ? Uri.UnescapeDataString(par[1]) : string.Empty,
                StringComparer.OrdinalIgnoreCase);
}
