using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Servidor HTTP simulado del microservicio (hace el papel de Kestrel). Al arrancar se registra
/// en la red con el nombre del servicio; cada petición recibe su propio alcance de dependencias
/// y atraviesa la cadena de middlewares hasta el enrutador.
/// </summary>
public sealed class ServidorApi(
    IServiceProvider raiz,
    RedHttpSimulada red,
    EnrutadorHttp enrutador,
    IEnumerable<IMiddlewareHttp> middlewares,
    ISerializador serializador,
    OpcionesDeMicroservicio opciones,
    ILogger<ServidorApi> logger) : IHostedService
{
    private readonly IReadOnlyList<IMiddlewareHttp> _middlewares = middlewares.ToList();

    public Task StartAsync(CancellationToken cancellationToken)
    {
        red.RegistrarHost(opciones.Nombre, AtenderAsync);
        logger.LogInformation("API escuchando en http://{Host} con {Rutas} rutas", opciones.Nombre, enrutador.Rutas.Count);
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        red.RetirarHost(opciones.Nombre);
        return Task.CompletedTask;
    }

    private async Task<RespuestaHttp> AtenderAsync(SolicitudHttp solicitud, CancellationToken cancellationToken)
    {
        await using var alcance = raiz.CreateAsyncScope();
        var contexto = new ContextoHttp(solicitud, alcance.ServiceProvider, serializador);

        Func<Task<RespuestaHttp>> siguiente = () => enrutador.DespacharAsync(contexto, cancellationToken);
        foreach (var middleware in _middlewares.Reverse())
        {
            var pasoActual = siguiente;
            siguiente = () => middleware.InvocarAsync(contexto, pasoActual, cancellationToken);
        }

        return await siguiente();
    }
}
