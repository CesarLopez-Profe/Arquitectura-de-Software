namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Cada microservicio agrupa sus endpoints en uno o más módulos. Agregar un módulo no exige
/// tocar el servidor (abierto/cerrado): el servidor recorre todos los módulos registrados.
/// </summary>
public interface IModuloDeEndpoints
{
    void Mapear(EnrutadorHttp enrutador);
}
