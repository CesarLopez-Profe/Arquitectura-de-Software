using System.Text.Json.Serialization;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Cuerpo de error estándar "Problem Details for HTTP APIs" (RFC 9457). Los nombres JSON
/// siguen la norma (type, title, status, detail) más dos extensiones: errores y regla.
/// </summary>
public sealed record DetallesDelProblema(
    [property: JsonPropertyName("type")] string Tipo,
    [property: JsonPropertyName("title")] string Titulo,
    [property: JsonPropertyName("status")] int Estado,
    [property: JsonPropertyName("detail")] string? Detalle = null,
    [property: JsonPropertyName("errores")] IReadOnlyDictionary<string, string[]>? Errores = null,
    [property: JsonPropertyName("regla")] string? Regla = null);
