using Microsoft.Extensions.DependencyInjection;
using Transito.BuildingBlocks.Application.Correlacion;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api.Middlewares;

/// <summary>
/// Primer eslabón: toma el X-Correlation-Id de la petición (o genera uno) y lo deja en el
/// contexto del alcance, para que viaje en los eventos y en las llamadas HTTP salientes.
/// </summary>
public sealed class CorrelacionMiddleware : IMiddlewareHttp
{
    public async Task<RespuestaHttp> InvocarAsync(
        ContextoHttp contexto,
        Func<Task<RespuestaHttp>> siguiente,
        CancellationToken cancellationToken)
    {
        var correlacion = contexto.Servicios.GetRequiredService<IContextoDeCorrelacion>();
        if (Guid.TryParse(contexto.Solicitud.Encabezado(EncabezadosHttp.Correlacion), out var recibido)
            && recibido != Guid.Empty)
        {
            correlacion.Establecer(recibido);
        }

        var respuesta = await siguiente();
        return respuesta.ConEncabezado(EncabezadosHttp.Correlacion, correlacion.CorrelacionId.ToString());
    }
}
