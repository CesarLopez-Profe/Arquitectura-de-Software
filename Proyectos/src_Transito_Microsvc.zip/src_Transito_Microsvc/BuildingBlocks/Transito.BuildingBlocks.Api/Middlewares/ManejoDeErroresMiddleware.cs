using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Domain;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api.Middlewares;

/// <summary>
/// Traduce las excepciones de las capas internas a respuestas HTTP con ProblemDetails. Así ni el
/// dominio ni la aplicación saben nada de códigos HTTP (separación de responsabilidades).
/// <list type="table">
/// <item><term>400</term><description>ValidacionException y DomainException (dato inválido).</description></item>
/// <item><term>404</term><description>RecursoNoEncontradoException.</description></item>
/// <item><term>409</term><description>ConflictoDeConcurrenciaException.</description></item>
/// <item><term>422</term><description>BusinessRuleViolationException (regla de negocio incumplida).</description></item>
/// <item><term>500</term><description>Cualquier otra excepción.</description></item>
/// </list>
/// </summary>
public sealed class ManejoDeErroresMiddleware(ILogger<ManejoDeErroresMiddleware> logger) : IMiddlewareHttp
{
    public async Task<RespuestaHttp> InvocarAsync(
        ContextoHttp contexto,
        Func<Task<RespuestaHttp>> siguiente,
        CancellationToken cancellationToken)
    {
        try
        {
            return await siguiente();
        }
        catch (ValidacionException ex)
        {
            var errores = ex.Errores
                .GroupBy(e => e.Campo)
                .ToDictionary(g => g.Key, g => g.Select(e => e.Mensaje).ToArray());
            return Resultados.Problema(400, "Solicitud inválida", ex.Message, errores);
        }
        catch (RecursoNoEncontradoException ex)
        {
            return Resultados.Problema(404, "Recurso no encontrado", ex.Message);
        }
        catch (BusinessRuleViolationException ex)
        {
            return Resultados.Problema(422, "Regla de negocio incumplida", ex.Message, regla: ex.BrokenRule.GetType().Name);
        }
        catch (DomainException ex)
        {
            return Resultados.Problema(400, "Dato inválido para el dominio", ex.Message);
        }
        catch (ConflictoDeConcurrenciaException ex)
        {
            return Resultados.Problema(409, "Conflicto de concurrencia", ex.Message);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Error no controlado en {Ruta}", contexto.Solicitud.Ruta);
            return Resultados.Problema(500, "Error interno", "Ocurrió un error inesperado.");
        }
    }
}
