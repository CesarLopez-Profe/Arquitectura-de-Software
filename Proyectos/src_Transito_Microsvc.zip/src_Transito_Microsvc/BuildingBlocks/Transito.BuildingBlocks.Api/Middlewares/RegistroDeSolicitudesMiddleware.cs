using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api.Middlewares;

/// <summary>Registra cada petición entrante con su código de respuesta y su duración.</summary>
public sealed class RegistroDeSolicitudesMiddleware(ILogger<RegistroDeSolicitudesMiddleware> logger) : IMiddlewareHttp
{
    public async Task<RespuestaHttp> InvocarAsync(
        ContextoHttp contexto,
        Func<Task<RespuestaHttp>> siguiente,
        CancellationToken cancellationToken)
    {
        var cronometro = Stopwatch.StartNew();
        var respuesta = await siguiente();
        var nivel = respuesta.Codigo >= 500 ? LogLevel.Error : respuesta.Codigo >= 400 ? LogLevel.Warning : LogLevel.Information;
        logger.Log(nivel, "HTTP entrante {Metodo} {Ruta} → {Codigo} ({Ms} ms)",
            contexto.Solicitud.Metodo, contexto.Solicitud.Ruta, respuesta.Codigo, cronometro.ElapsedMilliseconds);
        return respuesta;
    }
}
