using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api;

/// <summary>Un endpoint: recibe el contexto de la petición y produce la respuesta.</summary>
public delegate Task<RespuestaHttp> ManejadorDeRuta(ContextoHttp contexto, CancellationToken cancellationToken);
