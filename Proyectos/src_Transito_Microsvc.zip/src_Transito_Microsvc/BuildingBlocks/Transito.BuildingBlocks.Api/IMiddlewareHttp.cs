using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Patrón Chain of Responsibility, igual que los middlewares de ASP.NET Core: cada eslabón puede
/// actuar antes y después del siguiente, o cortar la cadena devolviendo su propia respuesta.
/// </summary>
public interface IMiddlewareHttp
{
    Task<RespuestaHttp> InvocarAsync(
        ContextoHttp contexto,
        Func<Task<RespuestaHttp>> siguiente,
        CancellationToken cancellationToken);
}
