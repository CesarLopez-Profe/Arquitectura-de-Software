namespace Transito.BuildingBlocks.Api;

/// <summary>Plantilla de ruta con parámetros entre llaves, por ejemplo <c>/api/sanciones/{id}</c>.</summary>
internal sealed class RutaRegistrada
{
    private readonly string[] _segmentos;

    public RutaRegistrada(string metodo, string plantilla, ManejadorDeRuta manejador)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(metodo);
        ArgumentException.ThrowIfNullOrWhiteSpace(plantilla);
        Metodo = metodo.ToUpperInvariant();
        Plantilla = plantilla;
        Manejador = manejador ?? throw new ArgumentNullException(nameof(manejador));
        _segmentos = plantilla.Trim('/').Split('/');
    }

    public string Metodo { get; }
    public string Plantilla { get; }
    public ManejadorDeRuta Manejador { get; }

    public bool Coincide(string ruta, out IReadOnlyDictionary<string, string> parametros)
    {
        var parametrosEncontrados = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        parametros = parametrosEncontrados;

        var segmentos = ruta.Trim('/').Split('/');
        if (segmentos.Length != _segmentos.Length)
            return false;

        for (var i = 0; i < segmentos.Length; i++)
        {
            var esperado = _segmentos[i];
            if (esperado.StartsWith('{') && esperado.EndsWith('}'))
                parametrosEncontrados[esperado[1..^1]] = Uri.UnescapeDataString(segmentos[i]);
            else if (!string.Equals(esperado, segmentos[i], StringComparison.OrdinalIgnoreCase))
                return false;
        }
        return true;
    }
}
