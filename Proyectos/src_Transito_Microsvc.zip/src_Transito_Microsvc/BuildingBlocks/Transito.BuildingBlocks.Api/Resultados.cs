using System.Text;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Métodos fábrica para construir respuestas HTTP coherentes (como <c>Results.Ok</c> en
/// ASP.NET Core). Todo cuerpo sale como JSON serializado por el singleton del serializador.
/// </summary>
public static class Resultados
{
    private const string BaseDeTipos = "https://transito.gov.co/problemas/";

    public static RespuestaHttp Ok(object cuerpo) => Json(200, cuerpo);

    public static RespuestaHttp Creado(string ubicacion, object cuerpo) =>
        Json(201, cuerpo).ConEncabezado(EncabezadosHttp.Ubicacion, ubicacion);

    public static RespuestaHttp Aceptado(object cuerpo) => Json(202, cuerpo);

    public static RespuestaHttp SinContenido() => new(204, null);

    public static RespuestaHttp Problema(
        int estado,
        string titulo,
        string? detalle = null,
        IReadOnlyDictionary<string, string[]>? errores = null,
        string? regla = null) =>
        Json(estado, new DetallesDelProblema(BaseDeTipos + Slug(titulo), titulo, estado, detalle, errores, regla))
            .ConEncabezado(EncabezadosHttp.TipoDeContenido, "application/problem+json");

    private static RespuestaHttp Json(int estado, object cuerpo) =>
        new RespuestaHttp(estado, SerializadorJson.Instancia.Serializar(cuerpo, cuerpo.GetType()))
            .ConEncabezado(EncabezadosHttp.TipoDeContenido, "application/json");

    /// <summary>"Regla de negocio incumplida" → "regla-de-negocio-incumplida" (sin tildes).</summary>
    private static string Slug(string texto)
    {
        var sinTildes = new string(texto.ToLowerInvariant()
            .Normalize(NormalizationForm.FormD)
            .Where(c => char.IsAsciiLetterOrDigit(c) || c == ' ')
            .ToArray());
        return string.Join('-', sinTildes.Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }
}
