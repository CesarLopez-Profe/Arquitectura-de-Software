using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.BuildingBlocks.Api;

/// <summary>
/// Enrutador al estilo de las Minimal APIs de ASP.NET Core: asocia método + plantilla de ruta
/// con un endpoint. Responde 404 si ninguna ruta coincide y 405 si la ruta existe con otro método.
/// </summary>
public sealed class EnrutadorHttp
{
    private readonly List<RutaRegistrada> _rutas = [];

    public IReadOnlyList<string> Rutas => _rutas.Select(r => $"{r.Metodo} {r.Plantilla}").ToList();

    public EnrutadorHttp MapearGet(string plantilla, ManejadorDeRuta manejador) => Mapear("GET", plantilla, manejador);

    public EnrutadorHttp MapearPost(string plantilla, ManejadorDeRuta manejador) => Mapear("POST", plantilla, manejador);

    public EnrutadorHttp Mapear(string metodo, string plantilla, ManejadorDeRuta manejador)
    {
        _rutas.Add(new RutaRegistrada(metodo, plantilla, manejador));
        return this;
    }

    public Task<RespuestaHttp> DespacharAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var rutaExisteConOtroMetodo = false;
        foreach (var ruta in _rutas)
        {
            if (!ruta.Coincide(contexto.RutaSinConsulta, out var parametros))
                continue;

            if (ruta.Metodo != contexto.Solicitud.Metodo)
            {
                rutaExisteConOtroMetodo = true;
                continue;
            }

            contexto.EstablecerParametrosDeRuta(parametros);
            return ruta.Manejador(contexto, cancellationToken);
        }

        return Task.FromResult(rutaExisteConOtroMetodo
            ? Resultados.Problema(405, "Método no permitido", $"{contexto.Solicitud.Metodo} no se admite en esta ruta.")
            : Resultados.Problema(404, "Ruta no encontrada", $"No existe {contexto.RutaSinConsulta}."));
    }
}
