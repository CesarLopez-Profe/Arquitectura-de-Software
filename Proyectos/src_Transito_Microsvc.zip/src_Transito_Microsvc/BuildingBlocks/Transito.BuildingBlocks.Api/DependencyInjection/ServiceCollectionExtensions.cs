using Microsoft.Extensions.DependencyInjection;
using Transito.BuildingBlocks.Api.Middlewares;

namespace Transito.BuildingBlocks.Api.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra el servidor HTTP simulado, la cadena de middlewares (el orden de registro es el
    /// orden de ejecución) y el enrutador construido a partir de todos los módulos de endpoints.
    /// </summary>
    public static IServiceCollection AgregarApiSimulada(this IServiceCollection services)
    {
        services.AddSingleton<IMiddlewareHttp, CorrelacionMiddleware>();
        services.AddSingleton<IMiddlewareHttp, RegistroDeSolicitudesMiddleware>();
        services.AddSingleton<IMiddlewareHttp, ManejoDeErroresMiddleware>();

        services.AddSingleton(sp =>
        {
            var enrutador = new EnrutadorHttp();
            foreach (var modulo in sp.GetServices<IModuloDeEndpoints>())
                modulo.Mapear(enrutador);
            return enrutador;
        });

        services.AddHostedService<ServidorApi>();
        return services;
    }

    public static IServiceCollection AgregarModuloDeEndpoints<TModulo>(this IServiceCollection services)
        where TModulo : class, IModuloDeEndpoints =>
        services.AddSingleton<IModuloDeEndpoints, TModulo>();
}
