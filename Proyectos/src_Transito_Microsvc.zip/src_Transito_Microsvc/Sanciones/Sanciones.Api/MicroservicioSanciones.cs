using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Sanciones.Api.Endpoints;
using Sanciones.Application.DependencyInjection;
using Sanciones.Infrastructure.DependencyInjection;
using Transito.BuildingBlocks.Api.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Sanciones.Api;

/// <summary>Composition root del microservicio Sanciones.</summary>
public static class MicroservicioSanciones
{
    public const string Nombre = "sanciones";

    public static IHost Construir(EntornoDeSimulacion entorno, Action<ILoggingBuilder>? configurarRegistro = null)
    {
        ArgumentNullException.ThrowIfNull(entorno);

        var constructor = Host.CreateEmptyApplicationBuilder(new HostApplicationBuilderSettings { ApplicationName = Nombre });
        constructor.ConfigureContainer(new DefaultServiceProviderFactory(
            new ServiceProviderOptions { ValidateOnBuild = true, ValidateScopes = true }));

        constructor.Services.AddLogging(registro => configurarRegistro?.Invoke(registro));
        constructor.Services
            .AgregarAplicacionSanciones()
            .AgregarInfraestructuraSanciones(entorno, new OpcionesDeMicroservicio { Nombre = Nombre })
            .AgregarApiSimulada()
            .AgregarModuloDeEndpoints<SancionesEndpoints>()
            .AgregarModuloDeEndpoints<InfraccionesEndpoints>();

        return constructor.Build();
    }
}
