namespace Sanciones.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/sanciones/{id}/apelacion/resolucion.</summary>
public sealed record ResolverApelacionSolicitud(bool Aceptada, string Fundamento);
