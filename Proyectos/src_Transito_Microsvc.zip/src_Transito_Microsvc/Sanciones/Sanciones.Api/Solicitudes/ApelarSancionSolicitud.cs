namespace Sanciones.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/sanciones/{id}/apelacion.</summary>
public sealed record ApelarSancionSolicitud(string Motivo);
