namespace Sanciones.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/sanciones.</summary>
public sealed record RegistrarSancionSolicitud(
    Guid ConductorId,
    string Placa,
    string CodigoInfraccion,
    string Lugar,
    DateTimeOffset FechaInfraccion);
