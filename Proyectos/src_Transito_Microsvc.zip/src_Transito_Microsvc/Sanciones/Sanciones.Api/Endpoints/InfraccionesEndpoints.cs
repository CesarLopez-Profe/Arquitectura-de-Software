using Sanciones.Application.Consultas.ListarInfracciones;
using Transito.BuildingBlocks.Api;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Sanciones.Api.Endpoints;

/// <summary>
/// Segundo módulo de endpoints del mismo microservicio: demuestra que agregar recursos no exige
/// modificar el servidor ni los otros módulos (abierto/cerrado).
/// </summary>
public sealed class InfraccionesEndpoints : IModuloDeEndpoints
{
    public void Mapear(EnrutadorHttp enrutador) =>
        enrutador.MapearGet("/api/infracciones", ListarAsync);

    private static async Task<RespuestaHttp> ListarAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(new ListarInfraccionesConsulta(), cancellationToken));
}
