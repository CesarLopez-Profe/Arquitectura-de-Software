using Sanciones.Api.Solicitudes;
using Sanciones.Application.Comandos.ApelarSancion;
using Sanciones.Application.Comandos.RegistrarSancion;
using Sanciones.Application.Comandos.ResolverApelacion;
using Sanciones.Application.Consultas.ListarSancionesDelConductor;
using Sanciones.Application.Consultas.ObtenerObligacion;
using Sanciones.Application.Consultas.ObtenerSancion;
using Transito.BuildingBlocks.Api;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Sanciones.Api.Endpoints;

/// <summary>Adaptador primario: endpoints HTTP del recurso sanción.</summary>
public sealed class SancionesEndpoints : IModuloDeEndpoints
{
    public void Mapear(EnrutadorHttp enrutador) => enrutador
        .MapearPost("/api/sanciones", RegistrarAsync)
        .MapearGet("/api/sanciones/{id}", ObtenerAsync)
        .MapearGet("/api/sanciones/{id}/obligacion", ObtenerObligacionAsync)
        .MapearPost("/api/sanciones/{id}/apelacion", ApelarAsync)
        .MapearPost("/api/sanciones/{id}/apelacion/resolucion", ResolverApelacionAsync)
        .MapearGet("/api/conductores/{conductorId}/sanciones", ListarDelConductorAsync);

    private static async Task<RespuestaHttp> RegistrarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var s = contexto.LeerCuerpo<RegistrarSancionSolicitud>();
        var registrada = await contexto.Mediador.EnviarAsync(
            new RegistrarSancionComando(s.ConductorId, s.Placa, s.CodigoInfraccion, s.Lugar, s.FechaInfraccion),
            cancellationToken);
        return Resultados.Creado($"/api/sanciones/{registrada.SancionId}", registrada);
    }

    private static async Task<RespuestaHttp> ObtenerAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ObtenerSancionConsulta(contexto.ParametroGuid("id")), cancellationToken));

    private static async Task<RespuestaHttp> ObtenerObligacionAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ObtenerObligacionConsulta(contexto.ParametroGuid("id"), contexto.ConsultaFecha("fechaPago")),
            cancellationToken));

    private static async Task<RespuestaHttp> ApelarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var s = contexto.LeerCuerpo<ApelarSancionSolicitud>();
        await contexto.Mediador.EnviarAsync(new ApelarSancionComando(contexto.ParametroGuid("id"), s.Motivo), cancellationToken);
        return Resultados.Aceptado(new { estado = "EnApelacion" });
    }

    private static async Task<RespuestaHttp> ResolverApelacionAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var s = contexto.LeerCuerpo<ResolverApelacionSolicitud>();
        await contexto.Mediador.EnviarAsync(
            new ResolverApelacionComando(contexto.ParametroGuid("id"), s.Aceptada, s.Fundamento), cancellationToken);
        return Resultados.Ok(new { aceptada = s.Aceptada });
    }

    private static async Task<RespuestaHttp> ListarDelConductorAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ListarSancionesDelConductorConsulta(contexto.ParametroGuid("conductorId")), cancellationToken));
}
