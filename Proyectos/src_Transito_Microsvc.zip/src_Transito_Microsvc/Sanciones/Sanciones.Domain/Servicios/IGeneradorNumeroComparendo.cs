using Sanciones.Domain.Sanciones;

namespace Sanciones.Domain.Servicios;

/// <summary>Puerto: el consecutivo depende de un almacenamiento externo.</summary>
public interface IGeneradorNumeroComparendo
{
    Task<NumeroComparendo> SiguienteAsync(int anio, CancellationToken cancellationToken);
}
