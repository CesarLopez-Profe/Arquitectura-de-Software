using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Servicios;

/// <summary>
/// Estrategia concreta. Simplificación del descuento por pronto pago (art. 136 CNT):
/// 50 % hasta el día 5 y 25 % hasta el día 20 después de la infracción (días calendario).
/// </summary>
public sealed class DescuentoPorProntoPago : IPoliticaDeDescuento
{
    public const int DiasDescuentoTotal = 5;
    public const int DiasDescuentoParcial = 20;

    public Dinero CalcularValorAPagar(Dinero valorMulta, DateTimeOffset fechaInfraccion, DateTimeOffset fechaPago)
    {
        ArgumentNullException.ThrowIfNull(valorMulta);
        var dias = (fechaPago.Date - fechaInfraccion.Date).TotalDays;
        if (dias < 0)
            throw new DomainException("La fecha de pago no puede ser anterior a la infracción.");

        var porcentaje = dias switch
        {
            <= DiasDescuentoTotal => 50m,
            <= DiasDescuentoParcial => 25m,
            _ => 0m
        };

        return valorMulta.AplicarDescuento(porcentaje);
    }
}
