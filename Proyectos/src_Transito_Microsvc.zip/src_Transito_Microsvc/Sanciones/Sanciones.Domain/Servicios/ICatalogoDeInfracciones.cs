using Sanciones.Domain.Sanciones;

namespace Sanciones.Domain.Servicios;

/// <summary>
/// Puerto hacia el catálogo oficial de infracciones (código, descripción, multa y puntos).
/// El agente de tránsito solo indica el código; el valor y los puntos los define la norma.
/// </summary>
public interface ICatalogoDeInfracciones
{
    Infraccion? Buscar(string codigo);
    IReadOnlyCollection<Infraccion> Todas();
}
