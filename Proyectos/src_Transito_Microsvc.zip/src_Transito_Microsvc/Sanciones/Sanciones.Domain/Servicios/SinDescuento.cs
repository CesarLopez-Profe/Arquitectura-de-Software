using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Servicios;

/// <summary>
/// Estrategia alternativa: se cobra el valor completo (por ejemplo, para reincidentes o si la ley
/// elimina el beneficio). Cambiar de estrategia es cambiar un registro en el contenedor.
/// </summary>
public sealed class SinDescuento : IPoliticaDeDescuento
{
    public Dinero CalcularValorAPagar(Dinero valorMulta, DateTimeOffset fechaInfraccion, DateTimeOffset fechaPago) =>
        valorMulta ?? throw new ArgumentNullException(nameof(valorMulta));
}
