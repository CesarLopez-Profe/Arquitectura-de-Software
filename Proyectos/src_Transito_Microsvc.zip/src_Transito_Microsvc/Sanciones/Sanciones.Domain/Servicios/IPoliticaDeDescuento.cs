using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Servicios;

/// <summary>
/// Patrón Strategy: cómo se calcula el valor a pagar de una multa en una fecha. Se modela como
/// interfaz para poder cambiar la política (por ley o por campaña) sin tocar el agregado.
/// </summary>
public interface IPoliticaDeDescuento
{
    Dinero CalcularValorAPagar(Dinero valorMulta, DateTimeOffset fechaInfraccion, DateTimeOffset fechaPago);
}
