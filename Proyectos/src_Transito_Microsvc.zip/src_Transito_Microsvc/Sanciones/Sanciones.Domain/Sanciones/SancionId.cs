using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>Identificador fuertemente tipado de la sanción.</summary>
public readonly record struct SancionId
{
    private readonly Guid _valor;

    public SancionId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("SancionId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador de la sanción");
    }

    public static SancionId Nueva() => new(Guid.NewGuid());

    public override string ToString() => _valor.ToString();
}
