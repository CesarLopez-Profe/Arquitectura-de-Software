namespace Sanciones.Domain.Sanciones;

/// <summary>Memento del agregado Sancion: su estado completo con tipos primitivos.</summary>
public sealed record SancionMemento(
    Guid Id,
    string Numero,
    Guid ConductorId,
    string Placa,
    string CodigoInfraccion,
    string DescripcionInfraccion,
    decimal ValorMulta,
    string Moneda,
    int PuntosADescontar,
    string Lugar,
    DateTimeOffset FechaInfraccion,
    EstadoSancion Estado,
    Guid? PagoId,
    decimal? MontoPagado,
    DateTimeOffset? FechaPago,
    IReadOnlyList<ApelacionMemento> Apelaciones);
