namespace Sanciones.Domain.Sanciones;

/// <summary>Qué decidió la sanción al recibir un pago confirmado por el contexto Pagos.</summary>
public enum ResultadoRecepcionPago
{
    /// <summary>El pago saldó la sanción.</summary>
    Aplicado = 1,

    /// <summary>Ese mismo pago ya se había aplicado (mensaje repetido).</summary>
    Duplicado = 2,

    /// <summary>La sanción no admitía el pago; se emitió PagoDeSancionRechazado para compensar.</summary>
    Rechazado = 3
}
