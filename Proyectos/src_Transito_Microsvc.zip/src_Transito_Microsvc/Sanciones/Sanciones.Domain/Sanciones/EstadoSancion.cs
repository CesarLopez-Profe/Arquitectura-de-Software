namespace Sanciones.Domain.Sanciones;

public enum EstadoSancion
{
    Pendiente = 1,
    EnApelacion = 2,
    Pagada = 3,
    Anulada = 4
}
