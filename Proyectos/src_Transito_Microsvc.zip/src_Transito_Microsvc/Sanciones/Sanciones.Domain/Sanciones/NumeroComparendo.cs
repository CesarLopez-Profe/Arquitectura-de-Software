using System.Text.RegularExpressions;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>Número del comparendo con formato COM-AAAA-NNN.</summary>
public sealed partial record NumeroComparendo
{
    private readonly string? _valor;

    private NumeroComparendo() { }

    public string Valor
    {
        get => Guard.Inicializado(_valor, nameof(Valor));
        private init
        {
            var normalizado = Guard.Texto(value, "número de comparendo", 20).ToUpperInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un número de comparendo válido (COM-AAAA-NNN).");
            _valor = normalizado;
        }
    }

    public static NumeroComparendo De(string valor) => new() { Valor = valor };

    public static NumeroComparendo Generar(int anio, long consecutivo) => De($"COM-{anio}-{consecutivo:D3}");

    public override string ToString() => Valor;

    [GeneratedRegex(@"^COM-\d{4}-\d{3,}$")]
    private static partial Regex Formato();
}
