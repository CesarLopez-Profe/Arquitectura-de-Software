namespace Sanciones.Domain.Sanciones;

public enum ResultadoApelacion
{
    Pendiente = 1,
    Aceptada = 2,
    Rechazada = 3
}
