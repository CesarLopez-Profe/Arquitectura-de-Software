using Sanciones.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

public sealed record SancionAnulada(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    ConductorId ConductorId,
    string Motivo) : DomainEvent(OcurrioEn);
