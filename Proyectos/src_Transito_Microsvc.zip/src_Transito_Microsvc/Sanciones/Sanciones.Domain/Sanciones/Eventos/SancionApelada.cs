using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

public sealed record SancionApelada(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    ApelacionId ApelacionId) : DomainEvent(OcurrioEn);
