using Sanciones.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

public sealed record SancionRegistrada(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    string NumeroComparendo,
    ConductorId ConductorId,
    string Placa,
    string CodigoInfraccion,
    Dinero ValorMulta,
    int PuntosADescontar) : DomainEvent(OcurrioEn);
