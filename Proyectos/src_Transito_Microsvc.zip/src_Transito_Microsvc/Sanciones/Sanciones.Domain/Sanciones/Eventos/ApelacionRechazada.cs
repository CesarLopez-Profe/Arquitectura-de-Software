using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

public sealed record ApelacionRechazada(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    ApelacionId ApelacionId) : DomainEvent(OcurrioEn);
