using Sanciones.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

public sealed record SancionPagada(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    ConductorId ConductorId,
    Guid PagoId,
    Dinero MontoPagado,
    int PuntosADescontar) : DomainEvent(OcurrioEn);
