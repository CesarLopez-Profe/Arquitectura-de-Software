using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Eventos;

/// <summary>La sanción no pudo aplicar un pago ya confirmado; el dinero debe devolverse.</summary>
public sealed record PagoDeSancionRechazado(
    DateTimeOffset OcurrioEn,
    SancionId SancionId,
    Guid PagoId,
    string Motivo) : DomainEvent(OcurrioEn);
