using Sanciones.Domain.Comun;

namespace Sanciones.Domain.Sanciones;

/// <summary>Puerto de persistencia del agregado. La implementación vive en infraestructura.</summary>
public interface ISancionRepository
{
    Task<Sancion?> ObtenerAsync(SancionId id, CancellationToken cancellationToken);
    Task<Sancion?> ObtenerPorNumeroAsync(NumeroComparendo numero, CancellationToken cancellationToken);
    Task<IReadOnlyList<Sancion>> ListarPorConductorAsync(ConductorId conductorId, CancellationToken cancellationToken);
    Task AgregarAsync(Sancion sancion, CancellationToken cancellationToken);
    Task ActualizarAsync(Sancion sancion, CancellationToken cancellationToken);
}
