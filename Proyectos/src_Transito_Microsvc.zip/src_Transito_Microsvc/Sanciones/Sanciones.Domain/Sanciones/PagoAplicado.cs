using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>
/// Lo que Sanciones necesita saber de un pago: qué pago fue, cuánto y cuándo. El PagoId es un
/// Guid simple porque el tipo "Pago" pertenece a otro contexto.
/// </summary>
public sealed record PagoAplicado
{
    private readonly Guid _pagoId;
    private readonly Dinero? _monto;
    private readonly DateTimeOffset _fecha;

    public PagoAplicado(Guid pagoId, Dinero monto, DateTimeOffset fecha)
    {
        PagoId = pagoId;
        Monto = monto;
        Fecha = fecha;
    }

    public Guid PagoId
    {
        get => Guard.Asignado(_pagoId, nameof(PagoId));
        private init => _pagoId = Guard.NoVacio(value, "pago aplicado");
    }

    public Dinero Monto
    {
        get => Guard.Inicializado(_monto, nameof(Monto));
        private init => _monto = Guard.NoNulo(value, "monto pagado");
    }

    public DateTimeOffset Fecha
    {
        get => Guard.Asignado(_fecha, nameof(Fecha));
        private init => _fecha = Guard.FechaValida(value, "fecha del pago");
    }
}
