using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>Identificador de la apelación (entidad interna del agregado Sancion).</summary>
public readonly record struct ApelacionId
{
    private readonly Guid _valor;

    public ApelacionId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("ApelacionId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador de la apelación");
    }

    public static ApelacionId Nueva() => new(Guid.NewGuid());

    public override string ToString() => _valor.ToString();
}
