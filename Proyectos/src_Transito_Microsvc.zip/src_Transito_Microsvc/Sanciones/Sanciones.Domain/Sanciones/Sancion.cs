using Sanciones.Domain.Comun;
using Sanciones.Domain.Sanciones.Eventos;
using Sanciones.Domain.Sanciones.Reglas;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>
/// Raíz del agregado Sanción (comparendo). Contiene sus apelaciones y el pago que la saldó.
/// Todas las transiciones de estado pasan por aquí y cada una emite su evento de dominio.
/// </summary>
public sealed class Sancion : AggregateRoot<SancionId>, IOriginador<Sancion, SancionMemento>
{
    /// <summary>Simplificación: el plazo legal se cuenta en días hábiles.</summary>
    public const int DiasParaApelar = 11;

    private readonly List<Apelacion> _apelaciones = [];
    private NumeroComparendo? _numero;
    private ConductorId _conductorId;
    private Placa? _placa;
    private Infraccion? _infraccion;
    private string? _lugar;
    private DateTimeOffset _fechaInfraccion;
    private EstadoSancion _estado;
    private PagoAplicado? _pago;

    private Sancion(SancionId id) : base(id) { }

    public NumeroComparendo Numero
    {
        get => Guard.Inicializado(_numero, nameof(Numero));
        private set => _numero = Guard.NoNulo(value, "número de comparendo");
    }

    public ConductorId ConductorId
    {
        get => Guard.Asignado(_conductorId, nameof(ConductorId));
        private set => _conductorId = Guard.NoPorDefecto(value, "conductor");
    }

    public Placa Placa
    {
        get => Guard.Inicializado(_placa, nameof(Placa));
        private set => _placa = Guard.NoNulo(value, "placa");
    }

    public Infraccion Infraccion
    {
        get => Guard.Inicializado(_infraccion, nameof(Infraccion));
        private set => _infraccion = Guard.NoNulo(value, "infracción");
    }

    public string Lugar
    {
        get => Guard.Inicializado(_lugar, nameof(Lugar));
        private set => _lugar = Guard.Texto(value, "lugar de la infracción", 200);
    }

    public DateTimeOffset FechaInfraccion
    {
        get => Guard.Asignado(_fechaInfraccion, nameof(FechaInfraccion));
        private set => _fechaInfraccion = Guard.FechaValida(value, "fecha de la infracción");
    }

    public EstadoSancion Estado
    {
        get => _estado;
        private set => _estado = Guard.Definido(value, "estado de la sanción");
    }

    /// <summary>Opcional: solo existe cuando la sanción quedó pagada.</summary>
    public PagoAplicado? Pago
    {
        get => _pago;
        private set => _pago = value;
    }

    public IReadOnlyCollection<Apelacion> Apelaciones => _apelaciones.AsReadOnly();

    public Apelacion? ApelacionEnCurso =>
        _apelaciones.SingleOrDefault(a => a.Resultado == ResultadoApelacion.Pendiente);

    public bool AdmitePago => Estado == EstadoSancion.Pendiente;

    public static Sancion Registrar(
        SancionId id,
        NumeroComparendo numero,
        ConductorId conductorId,
        Placa placa,
        Infraccion infraccion,
        string lugar,
        DateTimeOffset fechaInfraccion,
        DateTimeOffset ahora)
    {
        CheckRule(new FechaDeInfraccionNoPuedeSerFutura(fechaInfraccion, ahora));

        var sancion = new Sancion(id)
        {
            Numero = numero,
            ConductorId = conductorId,
            Placa = placa,
            Infraccion = infraccion,
            Lugar = lugar,
            FechaInfraccion = fechaInfraccion,
            Estado = EstadoSancion.Pendiente
        };

        sancion.Raise(new SancionRegistrada(
            ahora, id, numero.Valor, conductorId, placa.Valor,
            infraccion.Codigo, infraccion.ValorMulta, infraccion.PuntosADescontar));
        return sancion;
    }

    /// <summary>Valor a pagar en una fecha, aplicando la política de descuento (Strategy).</summary>
    public Dinero CalcularValorAPagar(DateTimeOffset fechaPago, IPoliticaDeDescuento politica)
    {
        ArgumentNullException.ThrowIfNull(politica);
        CheckRule(new SancionDebeEstarPendiente(Estado));
        return politica.CalcularValorAPagar(Infraccion.ValorMulta, FechaInfraccion, fechaPago);
    }

    /// <summary>
    /// Recibe un pago que Pagos YA confirmó. Como el dinero ya se cobró, no se lanza excepción:
    /// la sanción decide si lo aplica o lo rechaza, y en ese caso emite
    /// <see cref="PagoDeSancionRechazado"/> para que Pagos lo reverse (compensación de la saga).
    /// </summary>
    public ResultadoRecepcionPago RecibirPago(PagoAplicado pago, IPoliticaDeDescuento politica)
    {
        ArgumentNullException.ThrowIfNull(pago);
        ArgumentNullException.ThrowIfNull(politica);

        if (Pago?.PagoId == pago.PagoId)
            return ResultadoRecepcionPago.Duplicado;

        var reglaIncumplida = PrimeraReglaIncumplidaParaPagar(pago, politica);
        if (reglaIncumplida is not null)
        {
            Raise(new PagoDeSancionRechazado(pago.Fecha, Id, pago.PagoId, reglaIncumplida.Message));
            return ResultadoRecepcionPago.Rechazado;
        }

        Pago = pago;
        Estado = EstadoSancion.Pagada;
        Raise(new SancionPagada(pago.Fecha, Id, ConductorId, pago.PagoId, pago.Monto, Infraccion.PuntosADescontar));
        return ResultadoRecepcionPago.Aplicado;
    }

    public void Apelar(string motivo, DateTimeOffset ahora)
    {
        CheckRule(new SancionDebeEstarPendiente(Estado));
        CheckRule(new SoloSePermiteUnaApelacion(_apelaciones.Count));
        CheckRule(new ApelacionDebePresentarseDentroDelPlazo(FechaInfraccion, ahora, DiasParaApelar));

        var apelacion = Apelacion.Presentar(motivo, ahora);
        _apelaciones.Add(apelacion);
        Estado = EstadoSancion.EnApelacion;

        Raise(new SancionApelada(ahora, Id, apelacion.Id));
    }

    public void ResolverApelacion(bool aceptada, string fundamento, DateTimeOffset ahora)
    {
        CheckRule(new SancionDebeTenerApelacionEnCurso(Estado));

        var apelacion = ApelacionEnCurso!;
        apelacion.Resolver(aceptada, fundamento, ahora);

        if (aceptada)
        {
            Estado = EstadoSancion.Anulada;
            Raise(new SancionAnulada(ahora, Id, ConductorId, "Apelación aceptada: " + apelacion.Fundamento));
        }
        else
        {
            Estado = EstadoSancion.Pendiente;
            Raise(new ApelacionRechazada(ahora, Id, apelacion.Id));
        }
    }

    private IBusinessRule? PrimeraReglaIncumplidaParaPagar(PagoAplicado pago, IPoliticaDeDescuento politica)
    {
        IBusinessRule pendiente = new SancionDebeEstarPendiente(Estado);
        if (pendiente.IsBroken())
            return pendiente;

        var esperado = politica.CalcularValorAPagar(Infraccion.ValorMulta, FechaInfraccion, pago.Fecha);
        IBusinessRule monto = new MontoPagadoDebeSerIgualAlValorAPagar(pago.Monto, esperado);
        return monto.IsBroken() ? monto : null;
    }

    // ---------- Memento ----------

    public SancionMemento CrearMemento() => new(
        Id.Valor,
        Numero.Valor,
        ConductorId.Valor,
        Placa.Valor,
        Infraccion.Codigo,
        Infraccion.Descripcion,
        Infraccion.ValorMulta.Monto,
        Infraccion.ValorMulta.Moneda,
        Infraccion.PuntosADescontar,
        Lugar,
        FechaInfraccion,
        Estado,
        Pago?.PagoId,
        Pago?.Monto.Monto,
        Pago?.Fecha,
        _apelaciones.Select(a => a.CrearMemento()).ToList());

    public static Sancion RestaurarDesde(SancionMemento memento)
    {
        ArgumentNullException.ThrowIfNull(memento);

        var sancion = new Sancion(new SancionId(memento.Id))
        {
            Numero = NumeroComparendo.De(memento.Numero),
            ConductorId = new ConductorId(memento.ConductorId),
            Placa = Placa.De(memento.Placa),
            Infraccion = Infraccion.Crear(
                memento.CodigoInfraccion, memento.DescripcionInfraccion,
                Dinero.De(memento.ValorMulta, memento.Moneda), memento.PuntosADescontar),
            Lugar = memento.Lugar,
            FechaInfraccion = memento.FechaInfraccion,
            Estado = memento.Estado,
            Pago = memento.PagoId is { } pagoId
                ? new PagoAplicado(pagoId, Dinero.De(memento.MontoPagado ?? 0, memento.Moneda),
                    memento.FechaPago ?? memento.FechaInfraccion)
                : null
        };
        sancion._apelaciones.AddRange(memento.Apelaciones.Select(Apelacion.RestaurarDesde));
        return sancion;
    }
}
