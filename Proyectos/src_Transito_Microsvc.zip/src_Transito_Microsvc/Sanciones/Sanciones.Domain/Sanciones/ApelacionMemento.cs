namespace Sanciones.Domain.Sanciones;

/// <summary>Instantánea serializable de una apelación (parte del memento de la sanción).</summary>
public sealed record ApelacionMemento(
    Guid Id,
    string Motivo,
    DateTimeOffset FechaPresentacion,
    ResultadoApelacion Resultado,
    string? Fundamento,
    DateTimeOffset? FechaResolucion);
