using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class SoloSePermiteUnaApelacion(int apelacionesPresentadas) : IBusinessRule
{
    public bool IsBroken() => apelacionesPresentadas > 0;

    public string Message => "La sanción ya fue apelada una vez.";
}
