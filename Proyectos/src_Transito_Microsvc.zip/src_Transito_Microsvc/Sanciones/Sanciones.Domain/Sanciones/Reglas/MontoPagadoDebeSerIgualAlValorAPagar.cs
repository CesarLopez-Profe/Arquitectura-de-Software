using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class MontoPagadoDebeSerIgualAlValorAPagar(Dinero pagado, Dinero esperado) : IBusinessRule
{
    public bool IsBroken() => pagado != esperado;

    public string Message => $"El monto pagado ({pagado}) no corresponde al valor a pagar ({esperado}).";
}
