using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class ApelacionDebePresentarseDentroDelPlazo(
    DateTimeOffset fechaInfraccion,
    DateTimeOffset ahora,
    int diasPermitidos) : IBusinessRule
{
    public bool IsBroken() => (ahora.Date - fechaInfraccion.Date).TotalDays > diasPermitidos;

    public string Message => $"El plazo de {diasPermitidos} días para apelar ya venció.";
}
