using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class SancionDebeTenerApelacionEnCurso(EstadoSancion estado) : IBusinessRule
{
    public bool IsBroken() => estado != EstadoSancion.EnApelacion;

    public string Message => "La sanción no tiene una apelación en curso.";
}
