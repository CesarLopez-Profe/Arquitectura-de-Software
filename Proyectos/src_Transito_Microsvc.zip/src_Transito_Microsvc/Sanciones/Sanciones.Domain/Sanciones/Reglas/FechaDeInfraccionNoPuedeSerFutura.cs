using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class FechaDeInfraccionNoPuedeSerFutura(DateTimeOffset fechaInfraccion, DateTimeOffset ahora)
    : IBusinessRule
{
    public bool IsBroken() => fechaInfraccion > ahora;

    public string Message => "La fecha de la infracción no puede estar en el futuro.";
}
