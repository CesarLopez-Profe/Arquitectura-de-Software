using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones.Reglas;

public sealed class SancionDebeEstarPendiente(EstadoSancion estado) : IBusinessRule
{
    public bool IsBroken() => estado != EstadoSancion.Pendiente;

    public string Message => estado switch
    {
        EstadoSancion.Pagada => "La sanción ya fue pagada.",
        EstadoSancion.Anulada => "La sanción fue anulada.",
        EstadoSancion.EnApelacion => "La sanción tiene una apelación en curso.",
        _ => "La sanción no está pendiente."
    };
}
