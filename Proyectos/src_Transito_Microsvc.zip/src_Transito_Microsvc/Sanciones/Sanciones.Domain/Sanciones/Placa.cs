using System.Text.RegularExpressions;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>Placa colombiana: ABC123 (automotor) o ABC12D (motocicleta).</summary>
public sealed partial record Placa
{
    private readonly string? _valor;

    private Placa() { }

    /// <summary>Setter: quita guiones y espacios, pasa a mayúsculas y valida el formato.</summary>
    public string Valor
    {
        get => Guard.Inicializado(_valor, nameof(Valor));
        private init
        {
            var normalizado = Guard.Texto(value, "placa", 10).Replace("-", "").Replace(" ", "").ToUpperInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es una placa válida.");
            _valor = normalizado;
        }
    }

    public bool EsMotocicleta => char.IsLetter(Valor[^1]);

    public static Placa De(string valor) => new() { Valor = valor };

    public override string ToString() => Valor;

    [GeneratedRegex(@"^[A-Z]{3}(\d{3}|\d{2}[A-Z])$")]
    private static partial Regex Formato();
}
