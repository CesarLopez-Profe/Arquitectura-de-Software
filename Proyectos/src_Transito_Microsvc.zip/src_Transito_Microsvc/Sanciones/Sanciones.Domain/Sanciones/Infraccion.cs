using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>
/// Infracción del código de tránsito: qué se hizo, cuánto cuesta y cuántos puntos implica.
/// Value object inmutable; por eso el catálogo puede compartir una misma instancia entre muchas
/// sanciones (patrón Flyweight en infraestructura).
/// </summary>
public sealed record Infraccion
{
    public const int PuntosMaximos = 30;

    private readonly string? _codigo;
    private readonly string? _descripcion;
    private readonly Dinero? _valorMulta;
    private readonly int _puntosADescontar;

    private Infraccion() { }

    public string Codigo
    {
        get => Guard.Inicializado(_codigo, nameof(Codigo));
        private init => _codigo = Guard.Texto(value, "código de infracción", 10).ToUpperInvariant();
    }

    public string Descripcion
    {
        get => Guard.Inicializado(_descripcion, nameof(Descripcion));
        private init => _descripcion = Guard.Texto(value, "descripción de la infracción", 200);
    }

    /// <summary>Setter: la multa es obligatoria y mayor que cero.</summary>
    public Dinero ValorMulta
    {
        get => Guard.Inicializado(_valorMulta, nameof(ValorMulta));
        private init
        {
            var multa = Guard.NoNulo(value, "valor de la multa");
            if (multa.EsCero)
                throw new DomainException("El valor de la multa debe ser mayor que cero.");
            _valorMulta = multa;
        }
    }

    public int PuntosADescontar
    {
        get => _puntosADescontar;
        private init => _puntosADescontar = Guard.EnRango(value, 0, PuntosMaximos, "puntos a descontar");
    }

    public static Infraccion Crear(string codigo, string descripcion, Dinero valorMulta, int puntosADescontar) =>
        new()
        {
            Codigo = codigo,
            Descripcion = descripcion,
            ValorMulta = valorMulta,
            PuntosADescontar = puntosADescontar
        };
}
