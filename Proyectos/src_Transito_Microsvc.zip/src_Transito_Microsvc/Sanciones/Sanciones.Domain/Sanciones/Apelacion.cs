using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Sanciones;

/// <summary>
/// Entidad interna del agregado Sancion. Tiene identidad propia, pero solo la raíz puede crearla
/// o modificarla (fábrica y métodos internal).
/// </summary>
public sealed class Apelacion : Entity<ApelacionId>
{
    private string? _motivo;
    private DateTimeOffset _fechaPresentacion;
    private ResultadoApelacion _resultado;
    private string? _fundamento;
    private DateTimeOffset? _fechaResolucion;

    private Apelacion(ApelacionId id) : base(id) { }

    public string Motivo
    {
        get => Guard.Inicializado(_motivo, nameof(Motivo));
        private set => _motivo = Guard.Texto(value, "motivo de la apelación", 500);
    }

    public DateTimeOffset FechaPresentacion
    {
        get => Guard.Asignado(_fechaPresentacion, nameof(FechaPresentacion));
        private set => _fechaPresentacion = Guard.FechaValida(value, "fecha de presentación");
    }

    public ResultadoApelacion Resultado
    {
        get => _resultado;
        private set => _resultado = Guard.Definido(value, "resultado de la apelación");
    }

    public string? Fundamento
    {
        get => _fundamento;
        private set => _fundamento = Guard.TextoOpcional(value, "fundamento", 500);
    }

    /// <summary>Setter: si hay fecha, no puede ser anterior a la presentación.</summary>
    public DateTimeOffset? FechaResolucion
    {
        get => _fechaResolucion;
        private set
        {
            if (value is { } fecha && fecha < FechaPresentacion)
                throw new DomainException("La resolución no puede ser anterior a la presentación de la apelación.");
            _fechaResolucion = value;
        }
    }

    internal static Apelacion Presentar(string motivo, DateTimeOffset ahora) =>
        new(ApelacionId.Nueva())
        {
            Motivo = motivo,
            FechaPresentacion = ahora,
            Resultado = ResultadoApelacion.Pendiente
        };

    internal void Resolver(bool aceptada, string fundamento, DateTimeOffset ahora)
    {
        if (Resultado != ResultadoApelacion.Pendiente)
            throw new DomainException("La apelación ya fue resuelta.");

        Fundamento = Guard.Texto(fundamento, "fundamento de la resolución", 500);
        FechaResolucion = ahora;
        Resultado = aceptada ? ResultadoApelacion.Aceptada : ResultadoApelacion.Rechazada;
    }

    internal ApelacionMemento CrearMemento() =>
        new(Id.Valor, Motivo, FechaPresentacion, Resultado, Fundamento, FechaResolucion);

    internal static Apelacion RestaurarDesde(ApelacionMemento memento) =>
        new(new ApelacionId(memento.Id))
        {
            Motivo = memento.Motivo,
            FechaPresentacion = memento.FechaPresentacion,
            Resultado = memento.Resultado,
            Fundamento = memento.Fundamento,
            FechaResolucion = memento.FechaResolucion
        };
}
