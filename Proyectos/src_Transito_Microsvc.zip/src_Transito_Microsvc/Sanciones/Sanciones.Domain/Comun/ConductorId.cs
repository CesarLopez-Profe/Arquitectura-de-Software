using Transito.BuildingBlocks.Domain;

namespace Sanciones.Domain.Comun;

/// <summary>
/// Identidad del conductor tal como la conoce Sanciones. El conductor no se modela aquí: solo se
/// guarda su identificador, que es lo único compartido con otros contextos (por valor, no por tipo).
/// </summary>
public readonly record struct ConductorId
{
    private readonly Guid _valor;

    public ConductorId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("ConductorId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador del conductor");
    }

    public override string ToString() => _valor.ToString();
}
