using System.Collections.Concurrent;
using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Infrastructure.Catalogo;

/// <summary>
/// Patrón Flyweight (estructural) como fábrica de objetos compartidos: hay miles de sanciones pero
/// pocas infracciones distintas. Cada <see cref="Infraccion"/> se crea una sola vez (la primera
/// vez que se pide) y la misma instancia inmutable se reutiliza en todas las sanciones.
/// Valores ilustrativos inspirados en el Código Nacional de Tránsito (Ley 769 de 2002).
/// </summary>
public sealed class CatalogoDeInfraccionesEnMemoria : ICatalogoDeInfracciones
{
    private static readonly IReadOnlyDictionary<string, (string Descripcion, decimal Multa, int Puntos)> Definiciones =
        new Dictionary<string, (string, decimal, int)>(StringComparer.OrdinalIgnoreCase)
        {
            ["B01"] = ("Conducir sin portar la licencia de conducción", 233_500m, 2),
            ["C02"] = ("Estacionar en sitio prohibido", 467_000m, 4),
            ["C29"] = ("Conducir a velocidad superior a la máxima permitida", 875_500m, 8),
            ["D04"] = ("No detenerse ante la luz roja del semáforo", 875_500m, 10),
            ["F"] = ("Conducir en estado de embriaguez", 1_751_000m, 30)
        };

    private readonly ConcurrentDictionary<string, Infraccion> _instanciasCompartidas = new(StringComparer.OrdinalIgnoreCase);

    public int InstanciasCreadas => _instanciasCompartidas.Count;

    public Infraccion? Buscar(string codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo) || !Definiciones.ContainsKey(codigo.Trim()))
            return null;

        return _instanciasCompartidas.GetOrAdd(codigo.Trim(), Crear);
    }

    public IReadOnlyCollection<Infraccion> Todas() =>
        Definiciones.Keys.Select(codigo => Buscar(codigo)!).ToList();

    private static Infraccion Crear(string codigo)
    {
        var (descripcion, multa, puntos) = Definiciones[codigo];
        return Infraccion.Crear(codigo, descripcion, Dinero.De(multa), puntos);
    }
}
