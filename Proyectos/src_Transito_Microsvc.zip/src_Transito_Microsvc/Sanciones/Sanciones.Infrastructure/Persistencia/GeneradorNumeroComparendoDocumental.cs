using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Infrastructure.Persistencia;

namespace Sanciones.Infrastructure.Persistencia;

/// <summary>Adaptador: un consecutivo por año guardado como documento JSON.</summary>
public sealed class GeneradorNumeroComparendoDocumental(GeneradorDeConsecutivos consecutivos) : IGeneradorNumeroComparendo
{
    public Task<NumeroComparendo> SiguienteAsync(int anio, CancellationToken cancellationToken) =>
        Task.FromResult(NumeroComparendo.Generar(anio, consecutivos.Siguiente($"comparendos-{anio}")));
}
