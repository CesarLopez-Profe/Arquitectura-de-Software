using Sanciones.Domain.Comun;
using Sanciones.Domain.Sanciones;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Sanciones.Infrastructure.Persistencia;

/// <summary>Adaptador del puerto <see cref="ISancionRepository"/> sobre la base documental JSON.</summary>
public sealed class RepositorioDeSanciones(
    BaseDeDatosDocumental baseDeDatos,
    UnidadDeTrabajoDocumental unidadDeTrabajo,
    ISerializador serializador)
    : RepositorioDocumentalBase<Sancion, SancionId, SancionMemento>(baseDeDatos, unidadDeTrabajo, serializador),
      ISancionRepository
{
    protected override string Coleccion => "sanciones";

    protected override string ClaveDe(SancionId id) => id.Valor.ToString();

    public Task<Sancion?> ObtenerAsync(SancionId id, CancellationToken cancellationToken) =>
        ObtenerPorIdAsync(id, cancellationToken);

    public async Task<Sancion?> ObtenerPorNumeroAsync(NumeroComparendo numero, CancellationToken cancellationToken) =>
        (await BuscarAsync(m => m.Numero == numero.Valor, cancellationToken)).SingleOrDefault();

    public Task<IReadOnlyList<Sancion>> ListarPorConductorAsync(ConductorId conductorId, CancellationToken cancellationToken) =>
        BuscarAsync(m => m.ConductorId == conductorId.Valor, cancellationToken);
}
