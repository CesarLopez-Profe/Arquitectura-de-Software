using Microsoft.Extensions.DependencyInjection;
using Pagos.Contracts;
using Sanciones.Application.Integracion.Consumidores;
using Sanciones.Contracts;
using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Sanciones.Infrastructure.Catalogo;
using Sanciones.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Sanciones.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AgregarInfraestructuraSanciones(
        this IServiceCollection services,
        EntornoDeSimulacion entorno,
        OpcionesDeMicroservicio opciones)
    {
        services.AgregarBloquesDeInfraestructura(entorno, opciones);

        // Adaptadores de los puertos del dominio
        services.AddScoped<ISancionRepository, RepositorioDeSanciones>();
        services.AddScoped<IGeneradorNumeroComparendo, GeneradorNumeroComparendoDocumental>();
        services.AddSingleton<ICatalogoDeInfracciones, CatalogoDeInfraccionesEnMemoria>();

        // Canales de salida: la Policía recibe por webhook los comparendos nuevos.
        services.AgregarCanalesDeSalida(canales => canales
            .ConBusDeEventos()
            .ConBitacoraDeAuditoria()
            .ConBuzonDeArchivos()
            .ConWebhook("policia", "/webhooks/comparendos", SancionesTopicos.SancionRegistrada));

        // Lo que Sanciones escucha de otros contextos
        services.AgregarConsumidor<PagoConfirmadoV1, PagoConfirmadoConsumidor>(PagosTopicos.PagoConfirmado);

        return services;
    }
}
