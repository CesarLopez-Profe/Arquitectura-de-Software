namespace Sanciones.Contracts;

/// <summary>Se publica cuando una apelación aceptada anula la sanción.</summary>
public sealed record SancionAnuladaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid SancionId,
    Guid ConductorId,
    string Motivo);
