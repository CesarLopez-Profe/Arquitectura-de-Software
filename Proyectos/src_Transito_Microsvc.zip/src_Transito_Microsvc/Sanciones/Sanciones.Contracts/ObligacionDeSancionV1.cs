namespace Sanciones.Contracts;

/// <summary>
/// Respuesta de la consulta síncrona GET /api/sanciones/{id}/obligacion?fechaPago=...
/// Es la vista mínima que Sanciones expone para que otros contextos puedan cobrar.
/// </summary>
public sealed record ObligacionDeSancionV1(
    Guid SancionId,
    string NumeroComparendo,
    string Estado,
    bool AdmitePago,
    decimal ValorAPagar,
    string Moneda,
    string Descripcion);
