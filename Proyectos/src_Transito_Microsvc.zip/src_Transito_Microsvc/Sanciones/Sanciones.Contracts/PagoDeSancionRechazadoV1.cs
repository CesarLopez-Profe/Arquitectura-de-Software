namespace Sanciones.Contracts;

/// <summary>
/// Se publica cuando Sanciones no pudo aplicar un pago confirmado (por ejemplo, la sanción fue
/// anulada mientras se pagaba). Pagos lo consume para reversar el pago (compensación).
/// </summary>
public sealed record PagoDeSancionRechazadoV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid SancionId,
    Guid PagoId,
    string Motivo);
