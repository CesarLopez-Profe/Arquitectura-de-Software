namespace Sanciones.Contracts;

/// <summary>Se publica cuando se registra un comparendo.</summary>
public sealed record SancionRegistradaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid SancionId,
    string NumeroComparendo,
    Guid ConductorId,
    string Placa,
    string CodigoInfraccion,
    decimal ValorMulta,
    string Moneda,
    int PuntosADescontar);
