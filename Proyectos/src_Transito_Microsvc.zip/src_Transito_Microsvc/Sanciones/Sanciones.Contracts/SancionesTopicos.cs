namespace Sanciones.Contracts;

/// <summary>Tópicos en los que Sanciones publica. Convención: contexto.evento.version.</summary>
public static class SancionesTopicos
{
    public const string Todos = "sanciones.*";
    public const string SancionRegistrada = "sanciones.sancion-registrada.v1";
    public const string SancionPagada = "sanciones.sancion-pagada.v1";
    public const string SancionAnulada = "sanciones.sancion-anulada.v1";
    public const string PagoDeSancionRechazado = "sanciones.pago-de-sancion-rechazado.v1";
}
