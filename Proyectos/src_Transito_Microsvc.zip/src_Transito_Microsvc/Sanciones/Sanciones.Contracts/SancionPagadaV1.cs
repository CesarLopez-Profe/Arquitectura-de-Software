namespace Sanciones.Contracts;

/// <summary>Se publica cuando la sanción queda saldada. Licencias lo consume para descontar puntos.</summary>
public sealed record SancionPagadaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid SancionId,
    Guid ConductorId,
    Guid PagoId,
    decimal MontoPagado,
    string Moneda,
    int PuntosADescontar);
