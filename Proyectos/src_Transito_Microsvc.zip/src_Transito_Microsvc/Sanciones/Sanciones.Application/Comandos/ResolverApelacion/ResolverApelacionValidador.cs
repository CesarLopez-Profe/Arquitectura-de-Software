using Transito.BuildingBlocks.Application.Validacion;

namespace Sanciones.Application.Comandos.ResolverApelacion;

public sealed class ResolverApelacionValidador : ValidadorBase<ResolverApelacionComando>
{
    protected override void DefinirReglas(ResolverApelacionComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.SancionId, nameof(instancia.SancionId))
            .Requerido(instancia.Fundamento, nameof(instancia.Fundamento), 500);
}
