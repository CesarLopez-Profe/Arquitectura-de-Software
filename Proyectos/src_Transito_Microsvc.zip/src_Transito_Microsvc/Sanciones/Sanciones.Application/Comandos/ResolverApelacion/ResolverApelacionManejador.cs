using Sanciones.Domain.Sanciones;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Sanciones.Application.Comandos.ResolverApelacion;

public sealed class ResolverApelacionManejador(ISancionRepository sanciones, IClock reloj)
    : IManejadorDeComando<ResolverApelacionComando, Unidad>
{
    public async Task<Unidad> ManejarAsync(ResolverApelacionComando comando, CancellationToken cancellationToken)
    {
        var sancion = await sanciones.ObtenerAsync(new SancionId(comando.SancionId), cancellationToken)
                      ?? throw new RecursoNoEncontradoException("la sanción", comando.SancionId);

        sancion.ResolverApelacion(comando.Aceptada, comando.Fundamento, reloj.Now);
        await sanciones.ActualizarAsync(sancion, cancellationToken);
        return Unidad.Valor;
    }
}
