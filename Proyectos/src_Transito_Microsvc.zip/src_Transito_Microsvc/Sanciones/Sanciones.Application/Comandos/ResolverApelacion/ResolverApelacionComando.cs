using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Comandos.ResolverApelacion;

public sealed record ResolverApelacionComando(Guid SancionId, bool Aceptada, string Fundamento) : IComando<Unidad>;
