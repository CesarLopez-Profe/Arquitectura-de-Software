using Transito.BuildingBlocks.Application.Validacion;

namespace Sanciones.Application.Comandos.RecibirPago;

public sealed class RecibirPagoValidador : ValidadorBase<RecibirPagoComando>
{
    protected override void DefinirReglas(RecibirPagoComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.SancionId, nameof(instancia.SancionId))
            .NoVacio(instancia.PagoId, nameof(instancia.PagoId))
            .Positivo(instancia.Monto, nameof(instancia.Monto))
            .Requerido(instancia.Moneda, nameof(instancia.Moneda), 3);
}
