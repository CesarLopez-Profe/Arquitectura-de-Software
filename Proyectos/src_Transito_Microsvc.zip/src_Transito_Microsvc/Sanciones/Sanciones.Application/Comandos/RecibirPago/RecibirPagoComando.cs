using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Comandos.RecibirPago;

/// <summary>Aplica a la sanción un pago que el contexto Pagos ya confirmó.</summary>
public sealed record RecibirPagoComando(
    Guid SancionId,
    Guid PagoId,
    decimal Monto,
    string Moneda,
    DateTimeOffset FechaPago) : IComando<string>;
