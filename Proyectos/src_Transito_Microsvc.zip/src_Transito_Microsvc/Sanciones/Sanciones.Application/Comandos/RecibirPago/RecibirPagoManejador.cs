using Microsoft.Extensions.Logging;
using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Domain;

namespace Sanciones.Application.Comandos.RecibirPago;

/// <summary>
/// La decisión (aplicar, ignorar duplicado o rechazar) la toma el agregado. Si la sanción no
/// existe, se lanza excepción: el broker reintenta y, al agotar los intentos, el mensaje queda
/// en la cola de mensajes muertos para revisión manual.
/// </summary>
public sealed class RecibirPagoManejador(
    ISancionRepository sanciones,
    IPoliticaDeDescuento politica,
    ILogger<RecibirPagoManejador> logger) : IManejadorDeComando<RecibirPagoComando, string>
{
    public async Task<string> ManejarAsync(RecibirPagoComando comando, CancellationToken cancellationToken)
    {
        var sancion = await sanciones.ObtenerAsync(new SancionId(comando.SancionId), cancellationToken)
                      ?? throw new RecursoNoEncontradoException("la sanción", comando.SancionId);

        var pago = new PagoAplicado(comando.PagoId, Dinero.De(comando.Monto, comando.Moneda), comando.FechaPago);
        var resultado = sancion.RecibirPago(pago, politica);
        await sanciones.ActualizarAsync(sancion, cancellationToken);

        logger.LogInformation("Sanción {Numero}: pago {Resultado}", sancion.Numero, resultado.ToString().ToUpperInvariant());
        return resultado.ToString();
    }
}
