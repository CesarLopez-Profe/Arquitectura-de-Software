using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Comandos.ApelarSancion;

public sealed record ApelarSancionComando(Guid SancionId, string Motivo) : IComando<Unidad>;
