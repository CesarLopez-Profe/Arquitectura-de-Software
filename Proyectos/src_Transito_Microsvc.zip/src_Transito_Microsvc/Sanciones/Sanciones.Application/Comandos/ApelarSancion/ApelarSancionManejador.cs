using Sanciones.Domain.Sanciones;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Sanciones.Application.Comandos.ApelarSancion;

public sealed class ApelarSancionManejador(ISancionRepository sanciones, IClock reloj)
    : IManejadorDeComando<ApelarSancionComando, Unidad>
{
    public async Task<Unidad> ManejarAsync(ApelarSancionComando comando, CancellationToken cancellationToken)
    {
        var sancion = await sanciones.ObtenerAsync(new SancionId(comando.SancionId), cancellationToken)
                      ?? throw new RecursoNoEncontradoException("la sanción", comando.SancionId);

        sancion.Apelar(comando.Motivo, reloj.Now);
        await sanciones.ActualizarAsync(sancion, cancellationToken);
        return Unidad.Valor;
    }
}
