using Transito.BuildingBlocks.Application.Validacion;

namespace Sanciones.Application.Comandos.ApelarSancion;

public sealed class ApelarSancionValidador : ValidadorBase<ApelarSancionComando>
{
    protected override void DefinirReglas(ApelarSancionComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.SancionId, nameof(instancia.SancionId))
            .Requerido(instancia.Motivo, nameof(instancia.Motivo), 500);
}
