using Transito.BuildingBlocks.Application.Validacion;

namespace Sanciones.Application.Comandos.RegistrarSancion;

public sealed class RegistrarSancionValidador : ValidadorBase<RegistrarSancionComando>
{
    protected override void DefinirReglas(RegistrarSancionComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.ConductorId, nameof(instancia.ConductorId))
            .Requerido(instancia.Placa, nameof(instancia.Placa), 10)
            .Requerido(instancia.CodigoInfraccion, nameof(instancia.CodigoInfraccion), 10)
            .Requerido(instancia.Lugar, nameof(instancia.Lugar), 200)
            .Cumple(instancia.FechaInfraccion != default, nameof(instancia.FechaInfraccion), "Es obligatoria.");
}
