using Sanciones.Domain.Comun;
using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Sanciones.Application.Comandos.RegistrarSancion;

public sealed class RegistrarSancionManejador(
    ISancionRepository sanciones,
    IGeneradorNumeroComparendo generadorDeNumeros,
    ICatalogoDeInfracciones catalogo,
    IClock reloj) : IManejadorDeComando<RegistrarSancionComando, SancionRegistradaDto>
{
    public async Task<SancionRegistradaDto> ManejarAsync(RegistrarSancionComando comando, CancellationToken cancellationToken)
    {
        var infraccion = catalogo.Buscar(comando.CodigoInfraccion)
                         ?? throw new RecursoNoEncontradoException("la infracción", comando.CodigoInfraccion);

        var ahora = reloj.Now;
        var numero = await generadorDeNumeros.SiguienteAsync(ahora.Year, cancellationToken);

        var sancion = Sancion.Registrar(
            SancionId.Nueva(),
            numero,
            new ConductorId(comando.ConductorId),
            Placa.De(comando.Placa),
            infraccion,
            comando.Lugar,
            comando.FechaInfraccion,
            ahora);

        await sanciones.AgregarAsync(sancion, cancellationToken);

        return new SancionRegistradaDto(
            sancion.Id.Valor, sancion.Numero.Valor, infraccion.Codigo,
            infraccion.ValorMulta.Monto, infraccion.ValorMulta.Moneda, infraccion.PuntosADescontar);
    }
}
