using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Comandos.RegistrarSancion;

/// <summary>Intención: registrar un comparendo. El agente solo indica el código de la infracción.</summary>
public sealed record RegistrarSancionComando(
    Guid ConductorId,
    string Placa,
    string CodigoInfraccion,
    string Lugar,
    DateTimeOffset FechaInfraccion) : IComando<SancionRegistradaDto>;
