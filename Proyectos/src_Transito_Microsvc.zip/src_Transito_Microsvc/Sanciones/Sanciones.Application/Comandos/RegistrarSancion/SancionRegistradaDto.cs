namespace Sanciones.Application.Comandos.RegistrarSancion;

public sealed record SancionRegistradaDto(
    Guid SancionId,
    string NumeroComparendo,
    string CodigoInfraccion,
    decimal ValorMulta,
    string Moneda,
    int PuntosADescontar);
