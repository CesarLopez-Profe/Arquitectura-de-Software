using Pagos.Contracts;
using Sanciones.Application.Comandos.RecibirPago;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Integracion;

namespace Sanciones.Application.Integracion.Consumidores;

/// <summary>
/// Consume PagoConfirmadoV1. Pagos cobra muchos tipos de obligación; Sanciones solo atiende los
/// de tipo "Sancion" y los traduce a su propio comando.
/// </summary>
public sealed class PagoConfirmadoConsumidor(IMediador mediador) : IManejadorDeEventoDeIntegracion<PagoConfirmadoV1>
{
    public const string TipoObligacionSancion = "Sancion";

    public async Task ManejarAsync(PagoConfirmadoV1 mensaje, ContextoDeMensaje contexto, CancellationToken cancellationToken)
    {
        if (!string.Equals(mensaje.TipoObligacion, TipoObligacionSancion, StringComparison.OrdinalIgnoreCase))
            return;

        await mediador.EnviarAsync(
            new RecibirPagoComando(mensaje.ObligacionId, mensaje.PagoId, mensaje.Monto, mensaje.Moneda, mensaje.OcurrioEn),
            cancellationToken);
    }
}
