using Sanciones.Contracts;
using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Sanciones.Application.Integracion.Traductores;

public sealed class SancionAnuladaTraductor : TraductorDeEventoDeDominio<SancionAnulada>
{
    protected override string Topico => SancionesTopicos.SancionAnulada;

    protected override object CrearContrato(SancionAnulada evento) => new SancionAnuladaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.SancionId.Valor,
        evento.ConductorId.Valor,
        evento.Motivo);
}
