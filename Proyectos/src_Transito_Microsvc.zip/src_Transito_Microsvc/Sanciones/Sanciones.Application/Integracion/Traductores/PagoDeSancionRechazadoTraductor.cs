using Sanciones.Contracts;
using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Sanciones.Application.Integracion.Traductores;

public sealed class PagoDeSancionRechazadoTraductor : TraductorDeEventoDeDominio<PagoDeSancionRechazado>
{
    protected override string Topico => SancionesTopicos.PagoDeSancionRechazado;

    protected override object CrearContrato(PagoDeSancionRechazado evento) => new PagoDeSancionRechazadoV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.SancionId.Valor,
        evento.PagoId,
        evento.Motivo);
}
