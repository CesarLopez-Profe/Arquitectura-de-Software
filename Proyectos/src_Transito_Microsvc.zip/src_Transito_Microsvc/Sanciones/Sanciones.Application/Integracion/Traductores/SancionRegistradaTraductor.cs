using Sanciones.Contracts;
using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Sanciones.Application.Integracion.Traductores;

public sealed class SancionRegistradaTraductor : TraductorDeEventoDeDominio<SancionRegistrada>
{
    protected override string Topico => SancionesTopicos.SancionRegistrada;

    protected override object CrearContrato(SancionRegistrada evento) => new SancionRegistradaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.SancionId.Valor,
        evento.NumeroComparendo,
        evento.ConductorId.Valor,
        evento.Placa,
        evento.CodigoInfraccion,
        evento.ValorMulta.Monto,
        evento.ValorMulta.Moneda,
        evento.PuntosADescontar);
}
