using Sanciones.Contracts;
using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Sanciones.Application.Integracion.Traductores;

public sealed class SancionPagadaTraductor : TraductorDeEventoDeDominio<SancionPagada>
{
    protected override string Topico => SancionesTopicos.SancionPagada;

    protected override object CrearContrato(SancionPagada evento) => new SancionPagadaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.SancionId.Valor,
        evento.ConductorId.Valor,
        evento.PagoId,
        evento.MontoPagado.Monto,
        evento.MontoPagado.Moneda,
        evento.PuntosADescontar);
}
