using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Sanciones.Application.EventosDeDominio;

/// <summary>Observador local: informa que la apelación prosperó.</summary>
public sealed class NotificarSancionAnuladaManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<SancionAnulada>
{
    protected override Task AlOcurrirAsync(SancionAnulada evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            "Sanción anulada",
            $"Su sanción fue anulada. {evento.Motivo}",
            CanalDeNotificacion.Email),
            cancellationToken);
}
