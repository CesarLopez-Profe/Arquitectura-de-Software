using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Sanciones.Application.EventosDeDominio;

/// <summary>Observador local: envía el paz y salvo de la sanción.</summary>
public sealed class NotificarSancionPagadaManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<SancionPagada>
{
    protected override Task AlOcurrirAsync(SancionPagada evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            "Paz y salvo de comparendo",
            $"Recibimos su pago de {evento.MontoPagado}. La sanción quedó saldada.",
            CanalDeNotificacion.Email),
            cancellationToken);
}
