using Sanciones.Domain.Sanciones.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Sanciones.Application.EventosDeDominio;

/// <summary>Observador local: avisa al conductor del comparendo por correo y SMS.</summary>
public sealed class NotificarSancionRegistradaManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<SancionRegistrada>
{
    protected override Task AlOcurrirAsync(SancionRegistrada evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            $"Comparendo {evento.NumeroComparendo}",
            $"Se registró el comparendo {evento.NumeroComparendo} ({evento.CodigoInfraccion}) al vehículo " +
            $"{evento.Placa} por {evento.ValorMulta}. Pague en 5 días y obtenga 50 % de descuento.",
            CanalDeNotificacion.Email | CanalDeNotificacion.Sms),
            cancellationToken);
}
