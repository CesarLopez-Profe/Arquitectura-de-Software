using Sanciones.Application.Consultas.Dtos;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ListarInfracciones;

public sealed class ListarInfraccionesManejador(ICatalogoDeInfracciones catalogo)
    : IManejadorDeConsulta<ListarInfraccionesConsulta, IReadOnlyList<InfraccionDto>>
{
    public Task<IReadOnlyList<InfraccionDto>> ManejarAsync(ListarInfraccionesConsulta consulta, CancellationToken cancellationToken) =>
        Task.FromResult<IReadOnlyList<InfraccionDto>>(
            catalogo.Todas().OrderBy(i => i.Codigo).Select(i => i.ADto()).ToList());
}
