using Sanciones.Application.Consultas.Dtos;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ListarInfracciones;

public sealed record ListarInfraccionesConsulta : IConsulta<IReadOnlyList<InfraccionDto>>;
