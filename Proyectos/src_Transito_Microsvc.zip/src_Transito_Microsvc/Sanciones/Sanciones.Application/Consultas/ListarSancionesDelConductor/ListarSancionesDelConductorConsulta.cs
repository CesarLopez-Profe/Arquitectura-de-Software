using Sanciones.Application.Consultas.Dtos;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ListarSancionesDelConductor;

public sealed record ListarSancionesDelConductorConsulta(Guid ConductorId) : IConsulta<IReadOnlyList<SancionDto>>;
