using Sanciones.Application.Consultas.Dtos;
using Sanciones.Domain.Comun;
using Sanciones.Domain.Sanciones;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ListarSancionesDelConductor;

public sealed class ListarSancionesDelConductorManejador(ISancionRepository sanciones)
    : IManejadorDeConsulta<ListarSancionesDelConductorConsulta, IReadOnlyList<SancionDto>>
{
    public async Task<IReadOnlyList<SancionDto>> ManejarAsync(
        ListarSancionesDelConductorConsulta consulta,
        CancellationToken cancellationToken)
    {
        if (consulta.ConductorId == Guid.Empty)
            return [];

        var delConductor = await sanciones.ListarPorConductorAsync(new ConductorId(consulta.ConductorId), cancellationToken);
        return delConductor.OrderBy(s => s.FechaInfraccion).Select(s => s.ADto()).ToList();
    }
}
