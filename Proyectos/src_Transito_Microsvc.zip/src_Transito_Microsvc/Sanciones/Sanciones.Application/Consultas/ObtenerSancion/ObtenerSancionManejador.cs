using Sanciones.Application.Consultas.Dtos;
using Sanciones.Domain.Sanciones;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;

namespace Sanciones.Application.Consultas.ObtenerSancion;

public sealed class ObtenerSancionManejador(ISancionRepository sanciones)
    : IManejadorDeConsulta<ObtenerSancionConsulta, SancionDto>
{
    public async Task<SancionDto> ManejarAsync(ObtenerSancionConsulta consulta, CancellationToken cancellationToken)
    {
        if (consulta.SancionId == Guid.Empty)
            throw new RecursoNoEncontradoException("la sanción", consulta.SancionId);

        var sancion = await sanciones.ObtenerAsync(new SancionId(consulta.SancionId), cancellationToken)
                      ?? throw new RecursoNoEncontradoException("la sanción", consulta.SancionId);
        return sancion.ADto();
    }
}
