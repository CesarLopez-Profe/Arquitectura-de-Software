using Sanciones.Application.Consultas.Dtos;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ObtenerSancion;

public sealed record ObtenerSancionConsulta(Guid SancionId) : IConsulta<SancionDto>;
