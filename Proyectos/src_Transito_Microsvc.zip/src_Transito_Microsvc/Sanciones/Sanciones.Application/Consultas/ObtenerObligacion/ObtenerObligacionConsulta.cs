using Sanciones.Contracts;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Sanciones.Application.Consultas.ObtenerObligacion;

/// <summary>
/// Consulta que Sanciones expone a otros contextos (Pagos, la app ciudadana): cuánto se debe pagar
/// en una fecha. Responde con el contrato publicado, no con el modelo interno.
/// </summary>
public sealed record ObtenerObligacionConsulta(Guid SancionId, DateTimeOffset? FechaPago) : IConsulta<ObligacionDeSancionV1>;
