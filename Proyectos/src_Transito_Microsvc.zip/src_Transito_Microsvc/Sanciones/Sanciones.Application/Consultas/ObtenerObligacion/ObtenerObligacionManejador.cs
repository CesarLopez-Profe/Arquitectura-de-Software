using Sanciones.Contracts;
using Sanciones.Domain.Sanciones;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Sanciones.Application.Consultas.ObtenerObligacion;

public sealed class ObtenerObligacionManejador(
    ISancionRepository sanciones,
    IPoliticaDeDescuento politica,
    IClock reloj) : IManejadorDeConsulta<ObtenerObligacionConsulta, ObligacionDeSancionV1>
{
    public async Task<ObligacionDeSancionV1> ManejarAsync(ObtenerObligacionConsulta consulta, CancellationToken cancellationToken)
    {
        if (consulta.SancionId == Guid.Empty)
            throw new RecursoNoEncontradoException("la sanción", consulta.SancionId);

        var sancion = await sanciones.ObtenerAsync(new SancionId(consulta.SancionId), cancellationToken)
                      ?? throw new RecursoNoEncontradoException("la sanción", consulta.SancionId);

        var valor = sancion.AdmitePago
            ? sancion.CalcularValorAPagar(consulta.FechaPago ?? reloj.Now, politica)
            : sancion.Infraccion.ValorMulta;

        return new ObligacionDeSancionV1(
            sancion.Id.Valor,
            sancion.Numero.Valor,
            sancion.Estado.ToString(),
            sancion.AdmitePago,
            valor.Monto,
            valor.Moneda,
            $"{sancion.Infraccion.Codigo} - {sancion.Infraccion.Descripcion}");
    }
}
