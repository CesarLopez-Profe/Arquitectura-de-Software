namespace Sanciones.Application.Consultas.Dtos;

/// <summary>Modelo de lectura de una sanción.</summary>
public sealed record SancionDto(
    Guid Id,
    string NumeroComparendo,
    Guid ConductorId,
    string Placa,
    string CodigoInfraccion,
    string Infraccion,
    decimal ValorMulta,
    string Moneda,
    int PuntosADescontar,
    string Lugar,
    DateTimeOffset FechaInfraccion,
    string Estado,
    Guid? PagoId,
    IReadOnlyList<ApelacionDto> Apelaciones);
