namespace Sanciones.Application.Consultas.Dtos;

public sealed record InfraccionDto(string Codigo, string Descripcion, decimal ValorMulta, string Moneda, int Puntos);
