using Sanciones.Domain.Sanciones;

namespace Sanciones.Application.Consultas.Dtos;

/// <summary>Convierte el agregado en su modelo de lectura.</summary>
public static class SancionMapeador
{
    public static SancionDto ADto(this Sancion sancion) => new(
        sancion.Id.Valor,
        sancion.Numero.Valor,
        sancion.ConductorId.Valor,
        sancion.Placa.Valor,
        sancion.Infraccion.Codigo,
        sancion.Infraccion.Descripcion,
        sancion.Infraccion.ValorMulta.Monto,
        sancion.Infraccion.ValorMulta.Moneda,
        sancion.Infraccion.PuntosADescontar,
        sancion.Lugar,
        sancion.FechaInfraccion,
        sancion.Estado.ToString(),
        sancion.Pago?.PagoId,
        sancion.Apelaciones
            .Select(a => new ApelacionDto(a.Id.Valor, a.Motivo, a.FechaPresentacion, a.Resultado.ToString(), a.Fundamento))
            .ToList());

    public static InfraccionDto ADto(this Infraccion infraccion) => new(
        infraccion.Codigo,
        infraccion.Descripcion,
        infraccion.ValorMulta.Monto,
        infraccion.ValorMulta.Moneda,
        infraccion.PuntosADescontar);
}
