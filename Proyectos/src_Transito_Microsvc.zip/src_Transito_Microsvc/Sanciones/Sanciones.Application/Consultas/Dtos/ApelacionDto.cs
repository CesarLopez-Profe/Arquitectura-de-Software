namespace Sanciones.Application.Consultas.Dtos;

public sealed record ApelacionDto(
    Guid Id,
    string Motivo,
    DateTimeOffset FechaPresentacion,
    string Resultado,
    string? Fundamento);
