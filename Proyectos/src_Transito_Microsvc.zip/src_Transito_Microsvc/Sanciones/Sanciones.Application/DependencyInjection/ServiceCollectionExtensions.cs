using Microsoft.Extensions.DependencyInjection;
using Sanciones.Domain.Servicios;
using Transito.BuildingBlocks.Application.DependencyInjection;

namespace Sanciones.Application.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>Casos de uso de Sanciones + estrategia de descuento del dominio.</summary>
    public static IServiceCollection AgregarAplicacionSanciones(this IServiceCollection services)
    {
        services.AgregarBloquesDeAplicacion(typeof(ServiceCollectionExtensions).Assembly);

        // Strategy: cambiar a SinDescuento es cambiar esta línea.
        services.AddSingleton<IPoliticaDeDescuento, DescuentoPorProntoPago>();

        return services;
    }
}
