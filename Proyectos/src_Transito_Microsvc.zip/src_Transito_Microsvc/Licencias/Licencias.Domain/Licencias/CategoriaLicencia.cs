namespace Licencias.Domain.Licencias;

/// <summary>Categorías de licencia de conducción en Colombia.</summary>
public enum CategoriaLicencia
{
    A1 = 1,
    A2,
    B1,
    B2,
    B3,
    C1,
    C2,
    C3
}
