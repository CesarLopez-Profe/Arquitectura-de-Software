using System.Text.RegularExpressions;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>
/// Número de licencia con formato LIC-AAAA-NNN. <c>partial</c> porque el generador de código de
/// .NET completa el método <see cref="Formato"/> con la expresión regular compilada.
/// </summary>
public sealed partial record NumeroLicencia
{
    private readonly string? _valor;

    private NumeroLicencia() { }

    /// <summary>Setter: normaliza a mayúsculas y valida el formato. Getter: exige que exista.</summary>
    public string Valor
    {
        get => Guard.Inicializado(_valor, nameof(Valor));
        private init
        {
            var normalizado = Guard.Texto(value, "número de licencia", 20).ToUpperInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un número de licencia válido (LIC-AAAA-NNN).");
            _valor = normalizado;
        }
    }

    public static NumeroLicencia De(string valor) => new() { Valor = valor };

    public static NumeroLicencia Generar(int anio, long consecutivo) => De($"LIC-{anio}-{consecutivo:D3}");

    public override string ToString() => Valor;

    [GeneratedRegex(@"^LIC-\d{4}-\d{3,}$")]
    private static partial Regex Formato();
}
