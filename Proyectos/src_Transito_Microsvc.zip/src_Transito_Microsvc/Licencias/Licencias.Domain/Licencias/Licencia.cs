using Licencias.Domain.Comun;
using Licencias.Domain.Licencias.Eventos;
using Licencias.Domain.Licencias.Reglas;
using Licencias.Domain.Servicios;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>
/// Raíz del agregado Licencia de conducción. Su única responsabilidad es mantener consistente el
/// estado de una licencia: vigencia, saldo de puntos, estado e historial de descuentos.
/// Delegaciones: la aritmética del saldo a <see cref="SaldoDePuntos"/>, las fechas a
/// <see cref="Vigencia"/>, la duración a <see cref="IPoliticaDeVigencia"/> y cada regla a su clase.
/// <para>
/// Encapsulamiento: todos los setters son privados y validan; los getters de referencia fallan si
/// el campo nunca se inicializó. Desde fuera solo se cambia el estado con métodos de negocio.
/// </para>
/// </summary>
public sealed class Licencia : AggregateRoot<LicenciaId>, IOriginador<Licencia, LicenciaMemento>
{
    private readonly List<DescuentoDePuntos> _descuentos = [];
    private NumeroLicencia? _numero;
    private ConductorId _conductorId;
    private CategoriaLicencia _categoria;
    private Vigencia? _vigencia;
    private SaldoDePuntos? _saldo;
    private EstadoLicencia _estado;
    private string? _motivoEstado;

    private Licencia(LicenciaId id) : base(id) { }

    public NumeroLicencia Numero
    {
        get => Guard.Inicializado(_numero, nameof(Numero));
        private set => _numero = Guard.NoNulo(value, "número de licencia");
    }

    public ConductorId ConductorId
    {
        get => Guard.Asignado(_conductorId, nameof(ConductorId));
        private set => _conductorId = Guard.NoPorDefecto(value, "conductor");
    }

    public CategoriaLicencia Categoria
    {
        get => _categoria;
        private set => _categoria = Guard.Definido(value, "categoría");
    }

    public Vigencia Vigencia
    {
        get => Guard.Inicializado(_vigencia, nameof(Vigencia));
        private set => _vigencia = Guard.NoNulo(value, "vigencia");
    }

    public SaldoDePuntos Saldo
    {
        get => Guard.Inicializado(_saldo, nameof(Saldo));
        private set => _saldo = Guard.NoNulo(value, "saldo de puntos");
    }

    public EstadoLicencia Estado
    {
        get => _estado;
        private set => _estado = Guard.Definido(value, "estado");
    }

    /// <summary>Setter: texto opcional de máximo 300 caracteres, sin espacios sobrantes.</summary>
    public string? MotivoEstado
    {
        get => _motivoEstado;
        private set => _motivoEstado = Guard.TextoOpcional(value, "motivo", 300);
    }

    public IReadOnlyCollection<DescuentoDePuntos> Descuentos => _descuentos.AsReadOnly();

    /// <summary>Método fábrica: única forma de crear una licencia nueva. Emite LicenciaExpedida.</summary>
    public static Licencia Expedir(
        LicenciaId id,
        NumeroLicencia numero,
        ConductorId conductorId,
        CategoriaLicencia categoria,
        IPoliticaDeVigencia politica,
        DateTimeOffset ahora)
    {
        ArgumentNullException.ThrowIfNull(politica);
        Guard.Definido(categoria, "categoría");

        var licencia = new Licencia(id)
        {
            Numero = numero,
            ConductorId = conductorId,
            Categoria = categoria,
            Vigencia = politica.CalcularVigencia(categoria, DateOnly.FromDateTime(ahora.Date)),
            Saldo = SaldoDePuntos.Inicial,
            Estado = EstadoLicencia.Vigente
        };

        licencia.Raise(new LicenciaExpedida(
            ahora, id, conductorId, numero.Valor, categoria, licencia.Vigencia.Vencimiento));
        return licencia;
    }

    public bool PermiteConducirEn(DateOnly fecha) =>
        Estado == EstadoLicencia.Vigente && Vigencia.Cubre(fecha);

    public bool YaDescontoPorSancion(Guid sancionId) =>
        _descuentos.Any(d => d.SancionId == sancionId);

    /// <summary>
    /// Descuenta los puntos de una sanción. Es idempotente: si la misma sanción llega dos veces
    /// (entrega "al menos una vez"), no descuenta de nuevo. Si el saldo se agota, suspende.
    /// </summary>
    public void DescontarPuntos(Guid sancionId, int puntos, DateTimeOffset ahora)
    {
        Guard.NoVacio(sancionId, "sanción");
        if (YaDescontoPorSancion(sancionId))
            return;

        CheckRule(new LicenciaCanceladaNoAdmiteCambios(Estado));

        var saldoAnterior = Saldo;
        Saldo = Saldo.Descontar(puntos);
        var aplicados = saldoAnterior.Valor - Saldo.Valor;

        _descuentos.Add(DescuentoDePuntos.Registrar(sancionId, puntos, aplicados, ahora));
        Raise(new PuntosDescontados(ahora, Id, ConductorId, sancionId, aplicados, Saldo.Valor));

        if (Saldo.EstaAgotado && Estado == EstadoLicencia.Vigente)
            Suspender("Saldo de puntos agotado", ahora);
    }

    public void Renovar(IPoliticaDeVigencia politica, DateTimeOffset ahora)
    {
        ArgumentNullException.ThrowIfNull(politica);
        CheckRule(new SoloSeRenuevaUnaLicenciaVigente(Estado));

        Vigencia = politica.CalcularVigencia(Categoria, DateOnly.FromDateTime(ahora.Date));
        Raise(new LicenciaRenovada(ahora, Id, Vigencia.Vencimiento));
    }

    public void Cancelar(string motivo, DateTimeOffset ahora)
    {
        CheckRule(new LicenciaCanceladaNoAdmiteCambios(Estado));

        MotivoEstado = Guard.Texto(motivo, "motivo de la cancelación", 300);
        Estado = EstadoLicencia.Cancelada;
        Raise(new LicenciaCancelada(ahora, Id, ConductorId, MotivoEstado));
    }

    /// <summary>Privado: la suspensión solo ocurre como consecuencia de agotar los puntos.</summary>
    private void Suspender(string motivo, DateTimeOffset ahora)
    {
        MotivoEstado = motivo;
        Estado = EstadoLicencia.Suspendida;
        Raise(new LicenciaSuspendida(ahora, Id, ConductorId, motivo));
    }

    // ---------- Memento ----------

    public LicenciaMemento CrearMemento() => new(
        Id.Valor,
        Numero.Valor,
        ConductorId.Valor,
        Categoria,
        Vigencia.Expedicion,
        Vigencia.Vencimiento,
        Saldo.Valor,
        Estado,
        MotivoEstado,
        _descuentos.Select(d => d.CrearMemento()).ToList());

    public static Licencia RestaurarDesde(LicenciaMemento memento)
    {
        ArgumentNullException.ThrowIfNull(memento);

        var licencia = new Licencia(new LicenciaId(memento.Id))
        {
            Numero = NumeroLicencia.De(memento.Numero),
            ConductorId = new ConductorId(memento.ConductorId),
            Categoria = memento.Categoria,
            Vigencia = Vigencia.Entre(memento.Expedicion, memento.Vencimiento),
            Saldo = SaldoDePuntos.De(memento.Saldo),
            Estado = memento.Estado,
            MotivoEstado = memento.MotivoEstado
        };
        licencia._descuentos.AddRange(memento.Descuentos.Select(DescuentoDePuntos.RestaurarDesde));
        return licencia;
    }
}
