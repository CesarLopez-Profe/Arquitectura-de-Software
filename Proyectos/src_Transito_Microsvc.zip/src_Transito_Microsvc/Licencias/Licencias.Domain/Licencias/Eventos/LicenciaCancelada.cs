using Licencias.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Eventos;

public sealed record LicenciaCancelada(
    DateTimeOffset OcurrioEn,
    LicenciaId LicenciaId,
    ConductorId ConductorId,
    string Motivo) : DomainEvent(OcurrioEn);
