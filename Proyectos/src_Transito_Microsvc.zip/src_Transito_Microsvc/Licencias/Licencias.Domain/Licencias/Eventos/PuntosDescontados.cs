using Licencias.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Eventos;

public sealed record PuntosDescontados(
    DateTimeOffset OcurrioEn,
    LicenciaId LicenciaId,
    ConductorId ConductorId,
    Guid SancionId,
    int PuntosAplicados,
    int SaldoRestante) : DomainEvent(OcurrioEn);
