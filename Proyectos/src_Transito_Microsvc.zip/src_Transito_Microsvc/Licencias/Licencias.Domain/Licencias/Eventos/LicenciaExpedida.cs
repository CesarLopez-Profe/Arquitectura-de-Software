using Licencias.Domain.Comun;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Eventos;

public sealed record LicenciaExpedida(
    DateTimeOffset OcurrioEn,
    LicenciaId LicenciaId,
    ConductorId ConductorId,
    string NumeroLicencia,
    CategoriaLicencia Categoria,
    DateOnly Vencimiento) : DomainEvent(OcurrioEn);
