using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Eventos;

public sealed record LicenciaRenovada(
    DateTimeOffset OcurrioEn,
    LicenciaId LicenciaId,
    DateOnly NuevoVencimiento) : DomainEvent(OcurrioEn);
