using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>Periodo durante el cual la licencia autoriza a conducir. Value object inmutable.</summary>
public sealed record Vigencia
{
    public const int AniosMaximos = 15;

    private readonly DateOnly _expedicion;
    private readonly DateOnly _vencimiento;

    private Vigencia() { }

    public DateOnly Expedicion
    {
        get => Guard.Asignado(_expedicion, nameof(Expedicion));
        private init => _expedicion = Guard.FechaValida(value, "fecha de expedición");
    }

    public DateOnly Vencimiento
    {
        get => Guard.Asignado(_vencimiento, nameof(Vencimiento));
        private init => _vencimiento = Guard.FechaValida(value, "fecha de vencimiento");
    }

    /// <summary>La regla que involucra a los dos campos (vencimiento posterior) se valida aquí.</summary>
    public static Vigencia Entre(DateOnly expedicion, DateOnly vencimiento)
    {
        if (vencimiento <= expedicion)
            throw new DomainException("La fecha de vencimiento debe ser posterior a la de expedición.");
        return new Vigencia { Expedicion = expedicion, Vencimiento = vencimiento };
    }

    public static Vigencia Desde(DateOnly expedicion, int anios) =>
        Entre(expedicion, expedicion.AddYears(Guard.EnRango(anios, 1, AniosMaximos, "años de vigencia")));

    public bool Cubre(DateOnly fecha) => fecha >= Expedicion && fecha <= Vencimiento;
}
