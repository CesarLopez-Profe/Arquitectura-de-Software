namespace Licencias.Domain.Licencias;

public enum EstadoLicencia
{
    Vigente = 1,
    Suspendida = 2,
    Cancelada = 3
}
