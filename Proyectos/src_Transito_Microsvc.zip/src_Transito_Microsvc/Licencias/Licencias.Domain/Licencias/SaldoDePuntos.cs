using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>Saldo de puntos de la licencia: nunca es negativo ni supera el máximo.</summary>
public sealed record SaldoDePuntos
{
    public const int Maximo = 30;

    private readonly int _valor;

    private SaldoDePuntos() { }

    /// <summary>Setter: el saldo debe estar entre 0 y <see cref="Maximo"/>.</summary>
    public int Valor
    {
        get => _valor;
        private init => _valor = Guard.EnRango(value, 0, Maximo, "saldo de puntos");
    }

    public bool EstaAgotado => Valor == 0;

    public static SaldoDePuntos Inicial => De(Maximo);

    public static SaldoDePuntos De(int valor) => new() { Valor = valor };

    /// <summary>Descuenta hasta llegar a cero; el exceso no genera saldo negativo.</summary>
    public SaldoDePuntos Descontar(int puntos) =>
        De(Math.Max(0, Valor - Guard.Positivo(puntos, "puntos a descontar")));
}
