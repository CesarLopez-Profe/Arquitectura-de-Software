using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>Identificador de cada descuento de puntos (entidad interna del agregado Licencia).</summary>
public readonly record struct DescuentoId
{
    private readonly Guid _valor;

    public DescuentoId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("DescuentoId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador del descuento");
    }

    public static DescuentoId Nuevo() => new(Guid.NewGuid());

    public override string ToString() => _valor.ToString();
}
