using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Reglas;

public sealed class SoloSeRenuevaUnaLicenciaVigente(EstadoLicencia estado) : IBusinessRule
{
    public bool IsBroken() => estado != EstadoLicencia.Vigente;

    public string Message => $"Una licencia {estado} no se puede renovar.";
}
