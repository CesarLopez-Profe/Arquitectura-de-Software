using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Reglas;

public sealed class LicenciaCanceladaNoAdmiteCambios(EstadoLicencia estado) : IBusinessRule
{
    public bool IsBroken() => estado == EstadoLicencia.Cancelada;

    public string Message => "La licencia está cancelada y no admite cambios.";
}
