using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias.Reglas;

public sealed class NumeroDeLicenciaDebeSerUnico(bool yaExiste, NumeroLicencia numero) : IBusinessRule
{
    public bool IsBroken() => yaExiste;

    public string Message => $"El número de licencia {numero} ya está en uso.";
}
