using Licencias.Domain.Licencias.Especificaciones;
using Transito.BuildingBlocks.Domain;
using Transito.BuildingBlocks.Domain.Especificaciones;

namespace Licencias.Domain.Licencias.Reglas;

/// <summary>
/// La regla se expresa combinando dos especificaciones reutilizables:
/// "licencia activa" Y "de la categoría pedida".
/// </summary>
public sealed class ConductorNoDebeTenerOtraLicenciaActivaDeLaCategoria(
    IEnumerable<Licencia> licenciasDelConductor,
    CategoriaLicencia categoria) : IBusinessRule
{
    private readonly Especificacion<Licencia> _activaDeLaCategoria =
        new LicenciaActiva().Y(new LicenciaDeCategoria(categoria));

    public bool IsBroken() => licenciasDelConductor.Any(_activaDeLaCategoria.EsSatisfechaPor);

    public string Message => $"El conductor ya tiene una licencia {categoria} activa.";
}
