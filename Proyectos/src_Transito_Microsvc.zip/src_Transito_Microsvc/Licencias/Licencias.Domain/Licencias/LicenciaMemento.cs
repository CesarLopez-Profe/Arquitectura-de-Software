namespace Licencias.Domain.Licencias;

/// <summary>
/// Memento del agregado Licencia: su estado completo con tipos primitivos. Es lo que la
/// infraestructura serializa a JSON; no contiene reglas ni comportamiento.
/// </summary>
public sealed record LicenciaMemento(
    Guid Id,
    string Numero,
    Guid ConductorId,
    CategoriaLicencia Categoria,
    DateOnly Expedicion,
    DateOnly Vencimiento,
    int Saldo,
    EstadoLicencia Estado,
    string? MotivoEstado,
    IReadOnlyList<DescuentoDePuntosMemento> Descuentos);
