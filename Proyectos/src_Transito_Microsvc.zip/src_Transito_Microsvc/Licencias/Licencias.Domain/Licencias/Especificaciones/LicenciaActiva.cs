using Transito.BuildingBlocks.Domain.Especificaciones;

namespace Licencias.Domain.Licencias.Especificaciones;

/// <summary>Una licencia está activa mientras no haya sido cancelada (una suspendida sigue activa).</summary>
public sealed class LicenciaActiva : Especificacion<Licencia>
{
    public override bool EsSatisfechaPor(Licencia candidato) => candidato.Estado != EstadoLicencia.Cancelada;
}
