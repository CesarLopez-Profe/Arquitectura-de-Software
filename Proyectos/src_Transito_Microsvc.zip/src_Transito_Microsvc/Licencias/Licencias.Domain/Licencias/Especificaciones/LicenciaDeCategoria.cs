using Transito.BuildingBlocks.Domain.Especificaciones;

namespace Licencias.Domain.Licencias.Especificaciones;

public sealed class LicenciaDeCategoria(CategoriaLicencia categoria) : Especificacion<Licencia>
{
    public override bool EsSatisfechaPor(Licencia candidato) => candidato.Categoria == categoria;
}
