using Licencias.Domain.Comun;

namespace Licencias.Domain.Licencias;

/// <summary>Puerto de persistencia del agregado. La implementación vive en infraestructura.</summary>
public interface ILicenciaRepository
{
    Task<Licencia?> ObtenerAsync(LicenciaId id, CancellationToken cancellationToken);
    Task<IReadOnlyList<Licencia>> ListarPorConductorAsync(ConductorId conductorId, CancellationToken cancellationToken);
    Task<bool> ExisteNumeroAsync(NumeroLicencia numero, CancellationToken cancellationToken);
    Task AgregarAsync(Licencia licencia, CancellationToken cancellationToken);
    Task ActualizarAsync(Licencia licencia, CancellationToken cancellationToken);
}
