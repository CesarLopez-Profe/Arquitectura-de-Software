namespace Licencias.Domain.Licencias;

/// <summary>Conocimiento estable sobre las categorías (no cambia con la política de vigencia).</summary>
public static class CategoriaLicenciaExtensions
{
    public static bool EsServicioPublico(this CategoriaLicencia categoria) =>
        categoria is CategoriaLicencia.C1 or CategoriaLicencia.C2 or CategoriaLicencia.C3;
}
