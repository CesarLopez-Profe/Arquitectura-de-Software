using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>
/// Entidad interna del agregado Licencia: historial de cada descuento aplicado. Guarda el
/// SancionId (un Guid, no el tipo de Sanciones) para que una sanción nunca descuente dos veces.
/// Solo la raíz puede crearla (métodos internal).
/// </summary>
public sealed class DescuentoDePuntos : Entity<DescuentoId>
{
    private Guid _sancionId;
    private int _puntosSolicitados;
    private int _puntosAplicados;
    private DateTimeOffset _fecha;

    private DescuentoDePuntos(DescuentoId id) : base(id) { }

    public Guid SancionId
    {
        get => Guard.Asignado(_sancionId, nameof(SancionId));
        private set => _sancionId = Guard.NoVacio(value, "sanción del descuento");
    }

    public int PuntosSolicitados
    {
        get => _puntosSolicitados;
        private set => _puntosSolicitados = Guard.EnRango(value, 1, SaldoDePuntos.Maximo, "puntos solicitados");
    }

    public int PuntosAplicados
    {
        get => _puntosAplicados;
        private set => _puntosAplicados = Guard.EnRango(value, 0, SaldoDePuntos.Maximo, "puntos aplicados");
    }

    public DateTimeOffset Fecha
    {
        get => Guard.Asignado(_fecha, nameof(Fecha));
        private set => _fecha = Guard.FechaValida(value, "fecha del descuento");
    }

    internal static DescuentoDePuntos Registrar(Guid sancionId, int solicitados, int aplicados, DateTimeOffset fecha)
    {
        if (aplicados > solicitados)
            throw new DomainException("No se pueden aplicar más puntos de los solicitados.");

        return new DescuentoDePuntos(DescuentoId.Nuevo())
        {
            SancionId = sancionId,
            PuntosSolicitados = solicitados,
            PuntosAplicados = aplicados,
            Fecha = fecha
        };
    }

    internal DescuentoDePuntosMemento CrearMemento() =>
        new(Id.Valor, SancionId, PuntosSolicitados, PuntosAplicados, Fecha);

    internal static DescuentoDePuntos RestaurarDesde(DescuentoDePuntosMemento memento) =>
        new(new DescuentoId(memento.Id))
        {
            SancionId = memento.SancionId,
            PuntosSolicitados = memento.PuntosSolicitados,
            PuntosAplicados = memento.PuntosAplicados,
            Fecha = memento.Fecha
        };
}
