using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Licencias;

/// <summary>Identificador fuertemente tipado de la licencia (evita mezclarlo con otros Guid).</summary>
public readonly record struct LicenciaId
{
    private readonly Guid _valor;

    public LicenciaId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("LicenciaId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador de la licencia");
    }

    public static LicenciaId Nueva() => new(Guid.NewGuid());

    public override string ToString() => _valor.ToString();
}
