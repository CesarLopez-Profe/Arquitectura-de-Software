namespace Licencias.Domain.Licencias;

/// <summary>Instantánea serializable de un descuento (parte del memento de la licencia).</summary>
public sealed record DescuentoDePuntosMemento(
    Guid Id,
    Guid SancionId,
    int PuntosSolicitados,
    int PuntosAplicados,
    DateTimeOffset Fecha);
