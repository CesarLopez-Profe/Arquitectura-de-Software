using Licencias.Domain.Licencias;

namespace Licencias.Domain.Servicios;

/// <summary>
/// Patrón Strategy: cuánto dura una licencia depende de la ley vigente (y, en la realidad, de la
/// edad del conductor). Cambiar la política no obliga a modificar el agregado Licencia.
/// </summary>
public interface IPoliticaDeVigencia
{
    Vigencia CalcularVigencia(CategoriaLicencia categoria, DateOnly desde);
}
