using Licencias.Domain.Licencias;

namespace Licencias.Domain.Servicios;

/// <summary>
/// Simplificación de la Ley 1383 de 2010 (sin considerar la edad del conductor):
/// servicio particular 10 años, servicio público 3 años.
/// </summary>
public sealed class VigenciaPorCategoria : IPoliticaDeVigencia
{
    public const int AniosServicioParticular = 10;
    public const int AniosServicioPublico = 3;

    public Vigencia CalcularVigencia(CategoriaLicencia categoria, DateOnly desde) =>
        Vigencia.Desde(desde, categoria.EsServicioPublico() ? AniosServicioPublico : AniosServicioParticular);
}
