using Licencias.Domain.Licencias;

namespace Licencias.Domain.Servicios;

/// <summary>Puerto: el consecutivo depende de un almacenamiento externo.</summary>
public interface IGeneradorNumeroLicencia
{
    Task<NumeroLicencia> SiguienteAsync(int anio, CancellationToken cancellationToken);
}
