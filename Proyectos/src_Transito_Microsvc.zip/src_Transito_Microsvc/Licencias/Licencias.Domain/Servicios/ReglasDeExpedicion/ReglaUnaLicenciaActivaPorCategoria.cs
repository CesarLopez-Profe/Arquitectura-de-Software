using Licencias.Domain.Licencias;
using Licencias.Domain.Licencias.Reglas;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Servicios.ReglasDeExpedicion;

/// <summary>Consulta las licencias del conductor y arma la regla correspondiente.</summary>
public sealed class ReglaUnaLicenciaActivaPorCategoria(ILicenciaRepository licencias) : IReglaDeExpedicion
{
    public async Task<IBusinessRule> EvaluarAsync(SolicitudDeExpedicion solicitud, CancellationToken cancellationToken)
    {
        var existentes = await licencias.ListarPorConductorAsync(solicitud.ConductorId, cancellationToken);
        return new ConductorNoDebeTenerOtraLicenciaActivaDeLaCategoria(existentes, solicitud.Categoria);
    }
}
