using Licencias.Domain.Licencias;
using Licencias.Domain.Licencias.Reglas;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Servicios.ReglasDeExpedicion;

/// <summary>Verifica en el repositorio que el número no esté usado por otra licencia.</summary>
public sealed class ReglaNumeroDeLicenciaUnico(ILicenciaRepository licencias) : IReglaDeExpedicion
{
    public async Task<IBusinessRule> EvaluarAsync(SolicitudDeExpedicion solicitud, CancellationToken cancellationToken)
    {
        var existe = await licencias.ExisteNumeroAsync(solicitud.Numero, cancellationToken);
        return new NumeroDeLicenciaDebeSerUnico(existe, solicitud.Numero);
    }
}
