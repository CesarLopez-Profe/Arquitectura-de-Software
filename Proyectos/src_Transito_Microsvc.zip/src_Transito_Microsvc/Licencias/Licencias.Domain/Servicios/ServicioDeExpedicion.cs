using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Servicios;

/// <summary>
/// Servicio de dominio: expedir una licencia exige revisar información que un agregado aislado
/// no conoce (las otras licencias del conductor, los números ya usados). Las condiciones llegan
/// inyectadas como una colección de <see cref="IReglaDeExpedicion"/>.
/// </summary>
public sealed class ServicioDeExpedicion(IEnumerable<IReglaDeExpedicion> reglas, IPoliticaDeVigencia politica)
{
    private readonly IReadOnlyList<IReglaDeExpedicion> _reglas = reglas.ToList();

    public async Task<Licencia> ExpedirAsync(
        SolicitudDeExpedicion solicitud,
        DateTimeOffset ahora,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(solicitud);

        foreach (var regla in _reglas)
            BusinessRules.Check(await regla.EvaluarAsync(solicitud, cancellationToken));

        return Licencia.Expedir(
            LicenciaId.Nueva(), solicitud.Numero, solicitud.ConductorId, solicitud.Categoria, politica, ahora);
    }
}
