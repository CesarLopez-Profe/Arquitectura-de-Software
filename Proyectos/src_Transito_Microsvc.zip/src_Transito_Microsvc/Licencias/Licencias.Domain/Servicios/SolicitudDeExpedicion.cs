using Licencias.Domain.Comun;
using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Servicios;

/// <summary>Datos que las reglas de expedición necesitan evaluar. Se valida al construirse.</summary>
public sealed record SolicitudDeExpedicion
{
    public SolicitudDeExpedicion(NumeroLicencia numero, ConductorId conductorId, CategoriaLicencia categoria)
    {
        Numero = Guard.NoNulo(numero, "número de licencia");
        ConductorId = Guard.NoPorDefecto(conductorId, "conductor");
        Categoria = Guard.Definido(categoria, "categoría");
    }

    public NumeroLicencia Numero { get; }
    public ConductorId ConductorId { get; }
    public CategoriaLicencia Categoria { get; }
}
