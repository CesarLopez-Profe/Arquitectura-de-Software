using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Servicios;

/// <summary>
/// Principio abierto/cerrado aplicado: cada condición para expedir es una clase. Agregar una
/// condición nueva (por ejemplo, "no tener sanciones pendientes") es crear una clase y
/// registrarla; <see cref="ServicioDeExpedicion"/> no se modifica.
/// </summary>
public interface IReglaDeExpedicion
{
    Task<IBusinessRule> EvaluarAsync(SolicitudDeExpedicion solicitud, CancellationToken cancellationToken);
}
