using Transito.BuildingBlocks.Domain;

namespace Licencias.Domain.Comun;

/// <summary>
/// Identidad del conductor dentro de Licencias. Se define aquí (y no se comparte con Sanciones)
/// para que cada contexto evolucione su modelo por separado; entre contextos solo coincide el valor.
/// <para>
/// Getter: detecta un identificador creado con <c>default</c> (Guid vacío), que un struct no puede
/// impedir en el constructor. Setter: rechaza el Guid vacío.
/// </para>
/// </summary>
public readonly record struct ConductorId
{
    private readonly Guid _valor;

    public ConductorId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("ConductorId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador del conductor");
    }

    public override string ToString() => _valor.ToString();
}
