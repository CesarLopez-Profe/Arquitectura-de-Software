namespace Licencias.Contracts;

/// <summary>Tópicos en los que Licencias publica. Convención: contexto.evento.version.</summary>
public static class LicenciasTopicos
{
    public const string Todos = "licencias.*";
    public const string LicenciaExpedida = "licencias.licencia-expedida.v1";
    public const string PuntosDescontados = "licencias.puntos-descontados.v1";
    public const string LicenciaSuspendida = "licencias.licencia-suspendida.v1";
    public const string LicenciaCancelada = "licencias.licencia-cancelada.v1";
}
