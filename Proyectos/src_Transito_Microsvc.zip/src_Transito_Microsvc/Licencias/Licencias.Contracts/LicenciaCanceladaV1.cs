namespace Licencias.Contracts;

/// <summary>Se publica cuando una licencia se cancela de forma definitiva.</summary>
public sealed record LicenciaCanceladaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid LicenciaId,
    Guid ConductorId,
    string Motivo);
