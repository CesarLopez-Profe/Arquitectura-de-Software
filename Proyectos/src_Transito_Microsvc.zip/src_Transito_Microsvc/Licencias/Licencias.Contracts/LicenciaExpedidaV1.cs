namespace Licencias.Contracts;

/// <summary>Se publica al expedir una licencia (lo consume, por ejemplo, el RUNT por webhook).</summary>
public sealed record LicenciaExpedidaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid LicenciaId,
    Guid ConductorId,
    string NumeroLicencia,
    string Categoria,
    DateOnly Vencimiento);
