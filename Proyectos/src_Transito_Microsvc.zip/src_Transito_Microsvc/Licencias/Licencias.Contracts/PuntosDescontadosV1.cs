namespace Licencias.Contracts;

/// <summary>Se publica cada vez que se descuentan puntos por una sanción.</summary>
public sealed record PuntosDescontadosV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid LicenciaId,
    Guid ConductorId,
    Guid SancionId,
    int PuntosAplicados,
    int SaldoRestante);
