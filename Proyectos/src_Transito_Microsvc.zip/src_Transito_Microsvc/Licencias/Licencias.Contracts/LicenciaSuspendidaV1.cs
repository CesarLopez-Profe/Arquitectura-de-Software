namespace Licencias.Contracts;

/// <summary>Se publica cuando la licencia queda suspendida (por ejemplo, por agotar los puntos).</summary>
public sealed record LicenciaSuspendidaV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid LicenciaId,
    Guid ConductorId,
    string Motivo);
