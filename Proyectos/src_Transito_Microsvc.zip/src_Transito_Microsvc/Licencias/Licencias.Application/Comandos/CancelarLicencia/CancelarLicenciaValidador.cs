using Transito.BuildingBlocks.Application.Validacion;

namespace Licencias.Application.Comandos.CancelarLicencia;

public sealed class CancelarLicenciaValidador : ValidadorBase<CancelarLicenciaComando>
{
    protected override void DefinirReglas(CancelarLicenciaComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.LicenciaId, nameof(instancia.LicenciaId))
            .Requerido(instancia.Motivo, nameof(instancia.Motivo), 300);
}
