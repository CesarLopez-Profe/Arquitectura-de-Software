using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Licencias.Application.Comandos.CancelarLicencia;

public sealed class CancelarLicenciaManejador(ILicenciaRepository licencias, IClock reloj)
    : IManejadorDeComando<CancelarLicenciaComando, Unidad>
{
    public async Task<Unidad> ManejarAsync(CancelarLicenciaComando comando, CancellationToken cancellationToken)
    {
        var licencia = await licencias.ObtenerAsync(new LicenciaId(comando.LicenciaId), cancellationToken)
                       ?? throw new RecursoNoEncontradoException("la licencia", comando.LicenciaId);

        licencia.Cancelar(comando.Motivo, reloj.Now);
        await licencias.ActualizarAsync(licencia, cancellationToken);
        return Unidad.Valor;
    }
}
