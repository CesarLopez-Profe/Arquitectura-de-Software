using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Comandos.CancelarLicencia;

public sealed record CancelarLicenciaComando(Guid LicenciaId, string Motivo) : IComando<Unidad>;
