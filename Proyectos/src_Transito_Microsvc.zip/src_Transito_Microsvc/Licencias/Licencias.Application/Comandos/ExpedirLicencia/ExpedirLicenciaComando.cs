using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Comandos.ExpedirLicencia;

/// <summary>Intención: expedir una licencia de la categoría indicada al conductor.</summary>
public sealed record ExpedirLicenciaComando(Guid ConductorId, string Categoria) : IComando<LicenciaExpedidaDto>;
