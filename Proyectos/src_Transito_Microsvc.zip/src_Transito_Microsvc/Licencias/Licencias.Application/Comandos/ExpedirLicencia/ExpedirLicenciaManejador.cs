using Licencias.Domain.Comun;
using Licencias.Domain.Licencias;
using Licencias.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Licencias.Application.Comandos.ExpedirLicencia;

/// <summary>
/// Orquesta el caso de uso: traduce primitivos a tipos del dominio, delega la decisión en el
/// servicio de dominio y entrega el agregado al repositorio. No contiene reglas de negocio.
/// La confirmación (guardar + bandeja de salida) la hace el comportamiento transaccional.
/// </summary>
public sealed class ExpedirLicenciaManejador(
    ServicioDeExpedicion servicioDeExpedicion,
    IGeneradorNumeroLicencia generadorDeNumeros,
    ILicenciaRepository licencias,
    IClock reloj) : IManejadorDeComando<ExpedirLicenciaComando, LicenciaExpedidaDto>
{
    public async Task<LicenciaExpedidaDto> ManejarAsync(ExpedirLicenciaComando comando, CancellationToken cancellationToken)
    {
        var ahora = reloj.Now;
        var categoria = Enum.Parse<CategoriaLicencia>(comando.Categoria, ignoreCase: true);
        var numero = await generadorDeNumeros.SiguienteAsync(ahora.Year, cancellationToken);

        var licencia = await servicioDeExpedicion.ExpedirAsync(
            new SolicitudDeExpedicion(numero, new ConductorId(comando.ConductorId), categoria),
            ahora,
            cancellationToken);

        await licencias.AgregarAsync(licencia, cancellationToken);

        return new LicenciaExpedidaDto(
            licencia.Id.Valor, licencia.Numero.Valor, licencia.Categoria.ToString(),
            licencia.Vigencia.Vencimiento, licencia.Saldo.Valor);
    }
}
