using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Application.Validacion;

namespace Licencias.Application.Comandos.ExpedirLicencia;

public sealed class ExpedirLicenciaValidador : ValidadorBase<ExpedirLicenciaComando>
{
    protected override void DefinirReglas(ExpedirLicenciaComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.ConductorId, nameof(instancia.ConductorId))
            .EnumValido<CategoriaLicencia>(instancia.Categoria, nameof(instancia.Categoria));
}
