namespace Licencias.Application.Comandos.ExpedirLicencia;

public sealed record LicenciaExpedidaDto(Guid LicenciaId, string Numero, string Categoria, DateOnly Vencimiento, int Saldo);
