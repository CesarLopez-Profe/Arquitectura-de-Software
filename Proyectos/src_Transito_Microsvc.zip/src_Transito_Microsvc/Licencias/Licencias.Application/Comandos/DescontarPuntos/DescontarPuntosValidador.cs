using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Application.Validacion;

namespace Licencias.Application.Comandos.DescontarPuntos;

public sealed class DescontarPuntosValidador : ValidadorBase<DescontarPuntosComando>
{
    protected override void DefinirReglas(DescontarPuntosComando instancia, ColectorDeErrores errores) =>
        errores
            .NoVacio(instancia.ConductorId, nameof(instancia.ConductorId))
            .NoVacio(instancia.SancionId, nameof(instancia.SancionId))
            .EnRango(instancia.Puntos, 1, SaldoDePuntos.Maximo, nameof(instancia.Puntos));
}
