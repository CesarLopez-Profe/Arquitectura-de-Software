using Licencias.Domain.Comun;
using Licencias.Domain.Licencias;
using Licencias.Domain.Licencias.Especificaciones;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Licencias.Application.Comandos.DescontarPuntos;

/// <summary>
/// Simplificación consciente: los puntos se descuentan de cada licencia activa del conductor
/// (el modelo original llevaba el saldo por licencia). La idempotencia la garantiza el agregado.
/// </summary>
public sealed class DescontarPuntosManejador(
    ILicenciaRepository licencias,
    IClock reloj,
    ILogger<DescontarPuntosManejador> logger) : IManejadorDeComando<DescontarPuntosComando, int>
{
    private static readonly LicenciaActiva Activa = new();

    public async Task<int> ManejarAsync(DescontarPuntosComando comando, CancellationToken cancellationToken)
    {
        var delConductor = await licencias.ListarPorConductorAsync(new ConductorId(comando.ConductorId), cancellationToken);
        var activas = delConductor.Where(Activa.EsSatisfechaPor).ToList();

        if (activas.Count == 0)
            logger.LogWarning("El conductor {Conductor} no tiene licencias activas; no hay puntos que descontar",
                comando.ConductorId);

        foreach (var licencia in activas)
        {
            licencia.DescontarPuntos(comando.SancionId, comando.Puntos, reloj.Now);
            await licencias.ActualizarAsync(licencia, cancellationToken);
        }

        return activas.Count;
    }
}
