using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Comandos.DescontarPuntos;

/// <summary>Descontar los puntos de una sanción a las licencias activas del conductor.</summary>
/// <returns>Cantidad de licencias afectadas.</returns>
public sealed record DescontarPuntosComando(Guid ConductorId, Guid SancionId, int Puntos) : IComando<int>;
