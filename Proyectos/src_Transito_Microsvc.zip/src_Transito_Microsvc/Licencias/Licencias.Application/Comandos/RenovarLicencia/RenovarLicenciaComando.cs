using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Comandos.RenovarLicencia;

/// <summary>Renueva la vigencia de una licencia. Devuelve la nueva fecha de vencimiento.</summary>
public sealed record RenovarLicenciaComando(Guid LicenciaId) : IComando<DateOnly>;
