using Licencias.Domain.Licencias;
using Licencias.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Licencias.Application.Comandos.RenovarLicencia;

public sealed class RenovarLicenciaManejador(
    ILicenciaRepository licencias,
    IPoliticaDeVigencia politica,
    IClock reloj) : IManejadorDeComando<RenovarLicenciaComando, DateOnly>
{
    public async Task<DateOnly> ManejarAsync(RenovarLicenciaComando comando, CancellationToken cancellationToken)
    {
        var licencia = await licencias.ObtenerAsync(new LicenciaId(comando.LicenciaId), cancellationToken)
                       ?? throw new RecursoNoEncontradoException("la licencia", comando.LicenciaId);

        licencia.Renovar(politica, reloj.Now);
        await licencias.ActualizarAsync(licencia, cancellationToken);
        return licencia.Vigencia.Vencimiento;
    }
}
