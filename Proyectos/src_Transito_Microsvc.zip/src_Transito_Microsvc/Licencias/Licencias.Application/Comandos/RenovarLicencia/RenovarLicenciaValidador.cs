using Transito.BuildingBlocks.Application.Validacion;

namespace Licencias.Application.Comandos.RenovarLicencia;

public sealed class RenovarLicenciaValidador : ValidadorBase<RenovarLicenciaComando>
{
    protected override void DefinirReglas(RenovarLicenciaComando instancia, ColectorDeErrores errores) =>
        errores.NoVacio(instancia.LicenciaId, nameof(instancia.LicenciaId));
}
