using Licencias.Contracts;
using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Licencias.Application.Integracion.Traductores;

/// <summary>Traduce el evento de dominio (tipos ricos) al contrato publicado (primitivos, versionado).</summary>
public sealed class LicenciaExpedidaTraductor : TraductorDeEventoDeDominio<LicenciaExpedida>
{
    protected override string Topico => LicenciasTopicos.LicenciaExpedida;

    protected override object CrearContrato(LicenciaExpedida evento) => new LicenciaExpedidaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.LicenciaId.Valor,
        evento.ConductorId.Valor,
        evento.NumeroLicencia,
        evento.Categoria.ToString(),
        evento.Vencimiento);
}
