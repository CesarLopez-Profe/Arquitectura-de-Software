using Licencias.Contracts;
using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Licencias.Application.Integracion.Traductores;

public sealed class LicenciaSuspendidaTraductor : TraductorDeEventoDeDominio<LicenciaSuspendida>
{
    protected override string Topico => LicenciasTopicos.LicenciaSuspendida;

    protected override object CrearContrato(LicenciaSuspendida evento) => new LicenciaSuspendidaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.LicenciaId.Valor,
        evento.ConductorId.Valor,
        evento.Motivo);
}
