using Licencias.Contracts;
using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Licencias.Application.Integracion.Traductores;

public sealed class LicenciaCanceladaTraductor : TraductorDeEventoDeDominio<LicenciaCancelada>
{
    protected override string Topico => LicenciasTopicos.LicenciaCancelada;

    protected override object CrearContrato(LicenciaCancelada evento) => new LicenciaCanceladaV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.LicenciaId.Valor,
        evento.ConductorId.Valor,
        evento.Motivo);
}
