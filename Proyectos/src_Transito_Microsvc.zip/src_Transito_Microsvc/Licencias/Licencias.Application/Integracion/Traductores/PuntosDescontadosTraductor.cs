using Licencias.Contracts;
using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Licencias.Application.Integracion.Traductores;

public sealed class PuntosDescontadosTraductor : TraductorDeEventoDeDominio<PuntosDescontados>
{
    protected override string Topico => LicenciasTopicos.PuntosDescontados;

    protected override object CrearContrato(PuntosDescontados evento) => new PuntosDescontadosV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.LicenciaId.Valor,
        evento.ConductorId.Valor,
        evento.SancionId,
        evento.PuntosAplicados,
        evento.SaldoRestante);
}
