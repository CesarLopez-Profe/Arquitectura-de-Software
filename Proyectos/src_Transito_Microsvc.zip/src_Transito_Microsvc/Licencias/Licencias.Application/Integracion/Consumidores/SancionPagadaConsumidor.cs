using Licencias.Application.Comandos.DescontarPuntos;
using Sanciones.Contracts;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Integracion;

namespace Licencias.Application.Integracion.Consumidores;

/// <summary>
/// Consume el hecho publicado por Sanciones y lo traduce a una intención propia de Licencias
/// (DescontarPuntosComando). Licencias decide qué hacer: Sanciones solo informó.
/// </summary>
public sealed class SancionPagadaConsumidor(IMediador mediador) : IManejadorDeEventoDeIntegracion<SancionPagadaV1>
{
    public async Task ManejarAsync(SancionPagadaV1 mensaje, ContextoDeMensaje contexto, CancellationToken cancellationToken)
    {
        if (mensaje.PuntosADescontar <= 0)
            return;

        await mediador.EnviarAsync(
            new DescontarPuntosComando(mensaje.ConductorId, mensaje.SancionId, mensaje.PuntosADescontar),
            cancellationToken);
    }
}
