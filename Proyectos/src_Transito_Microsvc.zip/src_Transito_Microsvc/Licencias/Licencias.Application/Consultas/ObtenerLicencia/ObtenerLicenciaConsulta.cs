using Licencias.Application.Consultas.Dtos;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Consultas.ObtenerLicencia;

public sealed record ObtenerLicenciaConsulta(Guid LicenciaId) : IConsulta<LicenciaDto>;
