using Licencias.Application.Consultas.Dtos;
using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;

namespace Licencias.Application.Consultas.ObtenerLicencia;

public sealed class ObtenerLicenciaManejador(ILicenciaRepository licencias)
    : IManejadorDeConsulta<ObtenerLicenciaConsulta, LicenciaDto>
{
    public async Task<LicenciaDto> ManejarAsync(ObtenerLicenciaConsulta consulta, CancellationToken cancellationToken)
    {
        if (consulta.LicenciaId == Guid.Empty)
            throw new RecursoNoEncontradoException("la licencia", consulta.LicenciaId);

        var licencia = await licencias.ObtenerAsync(new LicenciaId(consulta.LicenciaId), cancellationToken)
                       ?? throw new RecursoNoEncontradoException("la licencia", consulta.LicenciaId);
        return licencia.ADto();
    }
}
