namespace Licencias.Application.Consultas.Dtos;

/// <summary>Modelo de lectura de una licencia: datos planos pensados para quien consulta.</summary>
public sealed record LicenciaDto(
    Guid Id,
    string Numero,
    Guid ConductorId,
    string Categoria,
    string Estado,
    string? MotivoEstado,
    DateOnly Expedicion,
    DateOnly Vencimiento,
    int Saldo,
    IReadOnlyList<DescuentoDto> Descuentos);
