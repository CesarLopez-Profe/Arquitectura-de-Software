namespace Licencias.Application.Consultas.Dtos;

public sealed record DescuentoDto(Guid SancionId, int PuntosSolicitados, int PuntosAplicados, DateTimeOffset Fecha);
