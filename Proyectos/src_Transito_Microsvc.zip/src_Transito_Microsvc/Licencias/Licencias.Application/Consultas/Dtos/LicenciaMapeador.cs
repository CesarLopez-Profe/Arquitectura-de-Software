using Licencias.Domain.Licencias;

namespace Licencias.Application.Consultas.Dtos;

/// <summary>Convierte el agregado en su modelo de lectura. El dominio nunca sale de la aplicación.</summary>
public static class LicenciaMapeador
{
    public static LicenciaDto ADto(this Licencia licencia) => new(
        licencia.Id.Valor,
        licencia.Numero.Valor,
        licencia.ConductorId.Valor,
        licencia.Categoria.ToString(),
        licencia.Estado.ToString(),
        licencia.MotivoEstado,
        licencia.Vigencia.Expedicion,
        licencia.Vigencia.Vencimiento,
        licencia.Saldo.Valor,
        licencia.Descuentos
            .OrderBy(d => d.Fecha)
            .Select(d => new DescuentoDto(d.SancionId, d.PuntosSolicitados, d.PuntosAplicados, d.Fecha))
            .ToList());
}
