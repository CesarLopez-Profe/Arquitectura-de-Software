using Licencias.Application.Consultas.Dtos;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Consultas.ListarLicenciasDelConductor;

public sealed record ListarLicenciasDelConductorConsulta(Guid ConductorId) : IConsulta<IReadOnlyList<LicenciaDto>>;
