using Licencias.Application.Consultas.Dtos;
using Licencias.Domain.Comun;
using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Application.Cqrs;

namespace Licencias.Application.Consultas.ListarLicenciasDelConductor;

public sealed class ListarLicenciasDelConductorManejador(ILicenciaRepository licencias)
    : IManejadorDeConsulta<ListarLicenciasDelConductorConsulta, IReadOnlyList<LicenciaDto>>
{
    public async Task<IReadOnlyList<LicenciaDto>> ManejarAsync(
        ListarLicenciasDelConductorConsulta consulta,
        CancellationToken cancellationToken)
    {
        if (consulta.ConductorId == Guid.Empty)
            return [];

        var delConductor = await licencias.ListarPorConductorAsync(new ConductorId(consulta.ConductorId), cancellationToken);
        return delConductor.Select(l => l.ADto()).ToList();
    }
}
