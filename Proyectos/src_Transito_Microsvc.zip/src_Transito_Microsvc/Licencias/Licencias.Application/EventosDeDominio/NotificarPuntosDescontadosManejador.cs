using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Licencias.Application.EventosDeDominio;

/// <summary>Observador local: informa por SMS y push cuántos puntos quedan.</summary>
public sealed class NotificarPuntosDescontadosManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PuntosDescontados>
{
    protected override Task AlOcurrirAsync(PuntosDescontados evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            $"Se descontaron {evento.PuntosAplicados} puntos",
            $"Se descontaron {evento.PuntosAplicados} puntos de su licencia. Saldo actual: {evento.SaldoRestante}.",
            CanalDeNotificacion.Sms | CanalDeNotificacion.Push),
            cancellationToken);
}
