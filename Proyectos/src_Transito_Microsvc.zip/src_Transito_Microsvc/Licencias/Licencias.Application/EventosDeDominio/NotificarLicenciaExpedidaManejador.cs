using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Licencias.Application.EventosDeDominio;

/// <summary>Observador local: avisa al conductor que su licencia fue expedida.</summary>
public sealed class NotificarLicenciaExpedidaManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<LicenciaExpedida>
{
    protected override Task AlOcurrirAsync(LicenciaExpedida evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            "Licencia expedida",
            $"Su licencia {evento.NumeroLicencia} ({evento.Categoria}) vence el {evento.Vencimiento:dd/MM/yyyy}.",
            CanalDeNotificacion.Email),
            cancellationToken);
}
