using Licencias.Domain.Licencias.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Licencias.Application.EventosDeDominio;

/// <summary>Observador local: la suspensión es grave, se avisa por todos los canales.</summary>
public sealed class NotificarLicenciaSuspendidaManejador(IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<LicenciaSuspendida>
{
    protected override Task AlOcurrirAsync(LicenciaSuspendida evento, CancellationToken cancellationToken) =>
        notificaciones.NotificarAsync(new Notificacion(
            $"conductor:{evento.ConductorId}",
            "LICENCIA SUSPENDIDA",
            $"Su licencia fue suspendida: {evento.Motivo}. No puede conducir hasta resolver su situación.",
            CanalDeNotificacion.Email | CanalDeNotificacion.Sms | CanalDeNotificacion.Push),
            cancellationToken);
}
