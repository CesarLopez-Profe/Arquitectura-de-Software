using Licencias.Domain.Servicios;
using Licencias.Domain.Servicios.ReglasDeExpedicion;
using Microsoft.Extensions.DependencyInjection;
using Transito.BuildingBlocks.Application.DependencyInjection;

namespace Licencias.Application.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>Casos de uso de Licencias + servicios y políticas del dominio.</summary>
    public static IServiceCollection AgregarAplicacionLicencias(this IServiceCollection services)
    {
        services.AgregarBloquesDeAplicacion(typeof(ServiceCollectionExtensions).Assembly);

        // Servicios y estrategias del dominio
        services.AddSingleton<IPoliticaDeVigencia, VigenciaPorCategoria>();
        services.AddScoped<ServicioDeExpedicion>();

        // Reglas de expedición: agregar una nueva = una línea más aquí (el servicio no cambia)
        services.AddScoped<IReglaDeExpedicion, ReglaUnaLicenciaActivaPorCategoria>();
        services.AddScoped<IReglaDeExpedicion, ReglaNumeroDeLicenciaUnico>();

        return services;
    }
}
