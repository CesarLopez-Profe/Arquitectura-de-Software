using Licencias.Api.Endpoints;
using Licencias.Application.DependencyInjection;
using Licencias.Infrastructure.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Api.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Licencias.Api;

/// <summary>
/// Composition root del microservicio: el ÚNICO lugar donde se conocen todas las capas y se
/// conectan las abstracciones con sus implementaciones. Cada microservicio tiene su propio
/// contenedor, su propia base de datos y sus propios procesos en segundo plano.
/// </summary>
public static class MicroservicioLicencias
{
    public const string Nombre = "licencias";

    public static IHost Construir(EntornoDeSimulacion entorno, Action<ILoggingBuilder>? configurarRegistro = null)
    {
        ArgumentNullException.ThrowIfNull(entorno);

        var constructor = Host.CreateEmptyApplicationBuilder(new HostApplicationBuilderSettings { ApplicationName = Nombre });
        constructor.ConfigureContainer(new DefaultServiceProviderFactory(
            new ServiceProviderOptions { ValidateOnBuild = true, ValidateScopes = true }));

        constructor.Services.AddLogging(registro => configurarRegistro?.Invoke(registro));
        constructor.Services
            .AgregarAplicacionLicencias()
            .AgregarInfraestructuraLicencias(entorno, new OpcionesDeMicroservicio { Nombre = Nombre })
            .AgregarApiSimulada()
            .AgregarModuloDeEndpoints<LicenciasEndpoints>();

        return constructor.Build();
    }
}
