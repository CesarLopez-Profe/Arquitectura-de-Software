namespace Licencias.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/licencias. Es el contrato HTTP, distinto del comando interno.</summary>
public sealed record ExpedirLicenciaSolicitud(Guid ConductorId, string Categoria);
