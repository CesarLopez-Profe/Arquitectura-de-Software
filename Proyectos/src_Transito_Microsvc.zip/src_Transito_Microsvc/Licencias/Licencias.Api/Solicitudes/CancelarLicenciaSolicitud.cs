namespace Licencias.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/licencias/{id}/cancelacion.</summary>
public sealed record CancelarLicenciaSolicitud(string Motivo);
