using Licencias.Api.Solicitudes;
using Licencias.Application.Comandos.CancelarLicencia;
using Licencias.Application.Comandos.ExpedirLicencia;
using Licencias.Application.Comandos.RenovarLicencia;
using Licencias.Application.Consultas.ListarLicenciasDelConductor;
using Licencias.Application.Consultas.ObtenerLicencia;
using Transito.BuildingBlocks.Api;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Licencias.Api.Endpoints;

/// <summary>
/// Adaptador primario (de entrada): traduce HTTP a comandos/consultas y la respuesta a JSON.
/// No contiene lógica de negocio; todo pasa por el mediador.
/// </summary>
public sealed class LicenciasEndpoints : IModuloDeEndpoints
{
    public void Mapear(EnrutadorHttp enrutador) => enrutador
        .MapearPost("/api/licencias", ExpedirAsync)
        .MapearGet("/api/licencias/{id}", ObtenerAsync)
        .MapearPost("/api/licencias/{id}/renovacion", RenovarAsync)
        .MapearPost("/api/licencias/{id}/cancelacion", CancelarAsync)
        .MapearGet("/api/conductores/{conductorId}/licencias", ListarDelConductorAsync);

    private static async Task<RespuestaHttp> ExpedirAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var solicitud = contexto.LeerCuerpo<ExpedirLicenciaSolicitud>();
        var expedida = await contexto.Mediador.EnviarAsync(
            new ExpedirLicenciaComando(solicitud.ConductorId, solicitud.Categoria), cancellationToken);
        return Resultados.Creado($"/api/licencias/{expedida.LicenciaId}", expedida);
    }

    private static async Task<RespuestaHttp> ObtenerAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ObtenerLicenciaConsulta(contexto.ParametroGuid("id")), cancellationToken));

    private static async Task<RespuestaHttp> RenovarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var vencimiento = await contexto.Mediador.EnviarAsync(
            new RenovarLicenciaComando(contexto.ParametroGuid("id")), cancellationToken);
        return Resultados.Ok(new { nuevoVencimiento = vencimiento });
    }

    private static async Task<RespuestaHttp> CancelarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var solicitud = contexto.LeerCuerpo<CancelarLicenciaSolicitud>();
        await contexto.Mediador.EnviarAsync(
            new CancelarLicenciaComando(contexto.ParametroGuid("id"), solicitud.Motivo), cancellationToken);
        return Resultados.SinContenido();
    }

    private static async Task<RespuestaHttp> ListarDelConductorAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ListarLicenciasDelConductorConsulta(contexto.ParametroGuid("conductorId")), cancellationToken));
}
