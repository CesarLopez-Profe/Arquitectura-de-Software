using Licencias.Application.Integracion.Consumidores;
using Licencias.Contracts;
using Licencias.Domain.Licencias;
using Licencias.Domain.Servicios;
using Licencias.Infrastructure.Persistencia;
using Microsoft.Extensions.DependencyInjection;
using Sanciones.Contracts;
using Transito.BuildingBlocks.Infrastructure.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Licencias.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AgregarInfraestructuraLicencias(
        this IServiceCollection services,
        EntornoDeSimulacion entorno,
        OpcionesDeMicroservicio opciones)
    {
        services.AgregarBloquesDeInfraestructura(entorno, opciones);

        // Adaptadores de los puertos del dominio
        services.AddScoped<ILicenciaRepository, RepositorioDeLicencias>();
        services.AddScoped<IGeneradorNumeroLicencia, GeneradorNumeroLicenciaDocumental>();

        // Canales por los que salen los eventos de Licencias (Builder + Composite + Decorator)
        services.AgregarCanalesDeSalida(canales => canales
            .ConBusDeEventos()
            .ConBitacoraDeAuditoria()
            .ConBuzonDeArchivos()
            .ConWebhook("runt", "/webhooks/licencias", LicenciasTopicos.Todos));

        // Lo que Licencias escucha de otros contextos
        services.AgregarConsumidor<SancionPagadaV1, SancionPagadaConsumidor>(SancionesTopicos.SancionPagada);

        return services;
    }
}
