using Licencias.Domain.Comun;
using Licencias.Domain.Licencias;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Licencias.Infrastructure.Persistencia;

/// <summary>
/// Adaptador del puerto <see cref="ILicenciaRepository"/> sobre la base documental JSON.
/// Hereda el algoritmo común (Template Method) y solo define colección, clave y consultas.
/// </summary>
public sealed class RepositorioDeLicencias(
    BaseDeDatosDocumental baseDeDatos,
    UnidadDeTrabajoDocumental unidadDeTrabajo,
    ISerializador serializador)
    : RepositorioDocumentalBase<Licencia, LicenciaId, LicenciaMemento>(baseDeDatos, unidadDeTrabajo, serializador),
      ILicenciaRepository
{
    protected override string Coleccion => "licencias";

    protected override string ClaveDe(LicenciaId id) => id.Valor.ToString();

    public Task<Licencia?> ObtenerAsync(LicenciaId id, CancellationToken cancellationToken) =>
        ObtenerPorIdAsync(id, cancellationToken);

    public Task<IReadOnlyList<Licencia>> ListarPorConductorAsync(ConductorId conductorId, CancellationToken cancellationToken) =>
        BuscarAsync(m => m.ConductorId == conductorId.Valor, cancellationToken);

    public async Task<bool> ExisteNumeroAsync(NumeroLicencia numero, CancellationToken cancellationToken) =>
        (await BuscarAsync(m => m.Numero == numero.Valor, cancellationToken)).Count > 0;
}
