using Licencias.Domain.Licencias;
using Licencias.Domain.Servicios;
using Transito.BuildingBlocks.Infrastructure.Persistencia;

namespace Licencias.Infrastructure.Persistencia;

/// <summary>Adaptador: un consecutivo por año guardado como documento JSON.</summary>
public sealed class GeneradorNumeroLicenciaDocumental(GeneradorDeConsecutivos consecutivos) : IGeneradorNumeroLicencia
{
    public Task<NumeroLicencia> SiguienteAsync(int anio, CancellationToken cancellationToken) =>
        Task.FromResult(NumeroLicencia.Generar(anio, consecutivos.Siguiente($"licencias-{anio}")));
}
