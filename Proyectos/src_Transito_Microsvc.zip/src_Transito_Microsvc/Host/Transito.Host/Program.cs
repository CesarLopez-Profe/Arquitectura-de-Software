using System.Text;
using Transito.Host.Demostracion;
using Transito.Host.Demostracion.Escenarios;
using Transito.Host.Plataforma;

// Punto de entrada de la simulación. Ejecutar desde la carpeta Transito_DDD_V2:
//   dotnet run --project src/Host/Transito.Host
// Los archivos JSON (bases de datos, buzones, notificaciones, auditoría) quedan en ./simulacion

Console.OutputEncoding = Encoding.UTF8;

var narrador = new Narrador();
var carpeta = Path.Combine(Directory.GetCurrentDirectory(), "simulacion");

narrador.Portada();
await using var plataforma = await PlataformaDeTransito.IniciarAsync(carpeta, narrador);

var guion = new GuionDeDemostracion(
[
    new Escenario01ExpedirLicencia(),
    new Escenario02RegistrarComparendo(),
    new Escenario03PagarConDescuento(),
    new Escenario04EntregaDuplicada(),
    new Escenario05PasarelaRechaza(),
    new Escenario06PlazoDeApelacion(),
    new Escenario07CompensacionDeLaSaga(),
    new Escenario08SuspensionDeLicencia(),
    new Escenario09MensajeVenenoso(),
    new Escenario10Resumen()
]);

await guion.EjecutarAsync(new ContextoDeDemo(plataforma, narrador));
