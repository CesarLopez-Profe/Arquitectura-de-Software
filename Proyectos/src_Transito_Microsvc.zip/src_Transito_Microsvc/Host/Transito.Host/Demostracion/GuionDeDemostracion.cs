namespace Transito.Host.Demostracion;

/// <summary>Invocador de los comandos-escenario: los ejecuta en orden y reporta fallos sin detenerse.</summary>
public sealed class GuionDeDemostracion(IReadOnlyList<IEscenario> escenarios)
{
    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        for (var i = 0; i < escenarios.Count; i++)
        {
            var escenario = escenarios[i];
            contexto.Narrador.Titulo(i + 1, escenario.Titulo);
            contexto.Narrador.Explicacion(escenario.Proposito);
            try
            {
                await escenario.EjecutarAsync(contexto);
            }
            catch (Exception ex)
            {
                contexto.Narrador.Fallo($"El escenario falló: {ex.GetType().Name}: {ex.Message}");
            }
        }
    }
}
