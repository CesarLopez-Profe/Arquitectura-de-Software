using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Tiempo;
using Transito.Host.Plataforma;

namespace Transito.Host.Demostracion;

/// <summary>
/// Estado compartido entre escenarios (el conductor de la historia, su licencia, sus sanciones) y
/// atajos para las operaciones que se repiten. Todo pasa por las APIs HTTP públicas.
/// </summary>
public sealed class ContextoDeDemo(PlataformaDeTransito plataforma, Narrador narrador)
{
    /// <summary>Ana, la conductora protagonista de la historia.</summary>
    public static readonly Guid ConductoraAna = Guid.Parse("a0a0a0a0-0000-4000-8000-000000000001");

    public const string PlacaDeAna = "abc-123";
    public const string CorreoDeAna = "ana.gomez@correo.co";

    private readonly Dictionary<string, Guid> _sanciones = new(StringComparer.OrdinalIgnoreCase);

    public PlataformaDeTransito Plataforma { get; } = plataforma;
    public Narrador Narrador { get; } = narrador;
    public ClienteDeLaPlataforma Cliente => Plataforma.Cliente;
    public RelojSimulado Reloj => Plataforma.Entorno.Reloj;

    public Guid LicenciaDeAna { get; set; }

    public Guid Sancion(string alias) =>
        _sanciones.TryGetValue(alias, out var id) ? id : throw new KeyNotFoundException($"No se registró la sanción '{alias}'.");

    public async Task<Guid> RegistrarComparendoAsync(string alias, string codigoInfraccion, string lugar)
    {
        var respuesta = await Cliente.PostAsync("sanciones", "/api/sanciones", new
        {
            conductorId = ConductoraAna,
            placa = PlacaDeAna,
            codigoInfraccion,
            lugar,
            fechaInfraccion = Reloj.Now
        });
        var id = respuesta.LeerGuid("sancionId");
        _sanciones[alias] = id;
        return id;
    }

    public async Task<decimal> ConsultarValorAPagarAsync(Guid sancionId)
    {
        var fecha = Uri.EscapeDataString(Reloj.Now.ToString("O"));
        var respuesta = await Cliente.GetAsync("sanciones", $"/api/sanciones/{sancionId}/obligacion?fechaPago={fecha}");
        return respuesta.LeerDecimal("valorAPagar");
    }

    public Task<RespuestaHttp> PagarAsync(Guid sancionId, decimal monto, string token) =>
        Cliente.PostAsync("pagos", "/api/pagos", new
        {
            tipoObligacion = "Sancion",
            obligacionId = sancionId,
            monto,
            moneda = "COP",
            metodoPago = "TarjetaCredito",
            tokenMedioDePago = token,
            correoPagador = CorreoDeAna
        });

    public async Task<int> ConsultarSaldoAsync()
    {
        var respuesta = await Cliente.GetAsync("licencias", $"/api/licencias/{LicenciaDeAna}");
        return respuesta.LeerEntero("saldo");
    }

    public Task EsperarAsync() => Plataforma.EsperarPropagacionAsync();
}
