namespace Transito.Host.Demostracion;

/// <summary>
/// Patrón Command: cada escenario de la demostración es un objeto con una acción ejecutable.
/// El guion los ejecuta en orden sin conocer su contenido; agregar uno no modifica el guion.
/// </summary>
public interface IEscenario
{
    string Titulo { get; }
    string Proposito { get; }
    Task EjecutarAsync(ContextoDeDemo contexto);
}
