using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Registro;

namespace Transito.Host.Demostracion;

/// <summary>Da formato a la salida de la demostración (títulos, peticiones, respuestas, JSON).</summary>
public sealed class Narrador
{
    private const int Ancho = 100;

    public void Portada()
    {
        Linea(new string('═', Ancho), ConsoleColor.Blue);
        Linea("  TRÁNSITO DDD V2 — Microservicios Sanciones · Pagos · Licencias (Clean Architecture)", ConsoleColor.White);
        Linea("  Simulación: BD documental JSON por servicio, bus de eventos, outbox/inbox, webhooks y notificaciones", ConsoleColor.Gray);
        Linea(new string('═', Ancho), ConsoleColor.Blue);
    }

    public void Titulo(int numero, string titulo)
    {
        ConsolaSincronizada.EscribirLinea();
        Linea(new string('─', Ancho), ConsoleColor.Blue);
        Linea($" ESCENARIO {numero}: {titulo}", ConsoleColor.White);
        Linea(new string('─', Ancho), ConsoleColor.Blue);
    }

    public void Paso(string texto) => Linea($"▶ {texto}", ConsoleColor.White);

    public void Explicacion(string texto) => Linea($"  ℹ {texto}", ConsoleColor.DarkGray);

    public void Exito(string texto) => Linea($"  ✔ {texto}", ConsoleColor.Green);

    public void Fallo(string texto) => Linea($"  ✘ {texto}", ConsoleColor.Red);

    public void Peticion(string metodo, string host, string ruta, string? cuerpo)
    {
        ConsolaSincronizada.EscribirLinea(
            ("  → ", ConsoleColor.Blue),
            ($"{metodo} http://{host}{ruta}", ConsoleColor.Blue),
            (cuerpo is null ? "" : $"  {cuerpo}", ConsoleColor.Gray));
    }

    public void Respuesta(RespuestaHttp respuesta)
    {
        var color = respuesta.EsExitosa ? ConsoleColor.Green : respuesta.Codigo >= 500 ? ConsoleColor.Red : ConsoleColor.DarkYellow;
        ConsolaSincronizada.EscribirLinea(("  ← ", color), ($"{respuesta.Codigo} {TextoDeEstado(respuesta.Codigo)}", color));
        if (!string.IsNullOrWhiteSpace(respuesta.Cuerpo))
            Bloque(respuesta.Cuerpo, ConsoleColor.Gray);
    }

    public void Json(string titulo, string json)
    {
        Linea($"  ┌ {titulo}", ConsoleColor.DarkCyan);
        Bloque(json, ConsoleColor.DarkCyan);
    }

    private static void Bloque(string texto, ConsoleColor color)
    {
        foreach (var linea in texto.Split('\n'))
            Linea("    " + linea.TrimEnd('\r'), color);
    }

    private static void Linea(string texto, ConsoleColor color) => ConsolaSincronizada.EscribirLinea((texto, color));

    private static string TextoDeEstado(int codigo) => codigo switch
    {
        200 => "OK",
        201 => "Created",
        202 => "Accepted",
        204 => "No Content",
        400 => "Bad Request",
        402 => "Payment Required",
        404 => "Not Found",
        409 => "Conflict",
        422 => "Unprocessable Entity",
        503 => "Service Unavailable",
        _ => ""
    };
}
