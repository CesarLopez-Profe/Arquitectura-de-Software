using Transito.BuildingBlocks.Infrastructure.Persistencia;

namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario02RegistrarComparendo : IEscenario
{
    public string Titulo => "Sanciones registra un comparendo C29 (exceso de velocidad)";

    public string Proposito =>
        "El evento SancionRegistrada se traduce a SancionRegistradaV1, se guarda en la bandeja de salida y sale " +
        "por VARIOS canales: bus, auditoría (JSONL), buzón de archivos y webhook a la Policía. Además, " +
        "los observadores locales notifican a Ana por correo y SMS.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        contexto.Narrador.Paso("Consultar el catálogo de infracciones (cada infracción es una instancia compartida: Flyweight)");
        await contexto.Cliente.GetAsync("sanciones", "/api/infracciones");

        contexto.Narrador.Paso("El agente registra el comparendo: solo indica el código; valor y puntos salen del catálogo");
        await contexto.RegistrarComparendoAsync("velocidad", "C29", "Av. Las Vegas con Calle 10, Medellín");

        var bd = contexto.Plataforma.BaseDeDatosDe(contexto.Plataforma.Sanciones);
        var enBandeja = bd.Listar(Colecciones.BandejaDeSalida).LastOrDefault();
        if (enBandeja is not null)
            contexto.Narrador.Json("Mensaje en la bandeja de salida (guardado en la MISMA transacción que la sanción)", enBandeja.Json);

        await contexto.EsperarAsync();
        contexto.Narrador.Exito("El relay de la bandeja de salida publicó el evento por todos los canales configurados.");
    }
}
