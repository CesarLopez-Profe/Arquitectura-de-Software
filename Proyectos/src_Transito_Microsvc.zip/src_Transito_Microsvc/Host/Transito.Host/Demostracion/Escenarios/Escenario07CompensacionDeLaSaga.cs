using Transito.Host.Plataforma;

namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario07CompensacionDeLaSaga : IEscenario
{
    public string Titulo => "Sanciones está caído mientras Ana paga, y la sanción se anula (compensación)";

    public string Proposito =>
        "Resiliencia y saga: el bus retiene PagoConfirmadoV1 mientras el consumidor de Sanciones no está. Entre " +
        "tanto, una apelación anula la sanción. Al volver, Sanciones rechaza el pago (PagoDeSancionRechazadoV1) " +
        "y Pagos lo reversa (PagoReversadoV1). Nadie orquesta: cada servicio reacciona a hechos.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        var broker = contexto.Plataforma.Entorno.Broker;

        contexto.Narrador.Paso("Registrar un comparendo B01 (conducir sin portar la licencia)");
        var sancion = await contexto.RegistrarComparendoAsync("sin-licencia", "B01", "Autopista Sur, Itagüí");
        await contexto.EsperarAsync();
        var valor = await contexto.ConsultarValorAPagarAsync(sancion);

        contexto.Narrador.Paso("Simular la caída del CONSUMIDOR de Sanciones (su API HTTP sigue respondiendo)");
        broker.Pausar("sanciones/");

        contexto.Narrador.Paso("Ana paga; Pagos confirma y publica PagoConfirmadoV1, que queda en cola");
        var pago = await contexto.PagarAsync(sancion, valor, "tok_visa_4242");
        var pagoId = pago.LeerGuid("pagoId");
        await contexto.EsperarAsync();
        contexto.Narrador.Explicacion($"Mensajes retenidos para Sanciones: {broker.PendientesDe("sanciones/")}");

        contexto.Narrador.Paso("Mientras tanto, Ana apela y la autoridad acepta la apelación: la sanción queda ANULADA");
        await contexto.Cliente.PostAsync("sanciones", $"/api/sanciones/{sancion}/apelacion",
            new { motivo = "Portaba la licencia digital en la app oficial" });
        await contexto.Cliente.PostAsync("sanciones", $"/api/sanciones/{sancion}/apelacion/resolucion",
            new { aceptada = true, fundamento = "La licencia digital es válida según la Resolución 20203040015845" });
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("El consumidor de Sanciones vuelve a la vida y procesa la cola");
        broker.Reanudar("sanciones/");
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("Estado final del pago en Pagos");
        await contexto.Cliente.GetAsync("pagos", $"/api/pagos/{pagoId}");
    }
}
