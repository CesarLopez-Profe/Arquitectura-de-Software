namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario03PagarConDescuento : IEscenario
{
    public string Titulo => "Ana paga el comparendo con 50 % de descuento (saga coreografiada)";

    public string Proposito =>
        "Pagos consulta a Sanciones por HTTP a través de la capa anticorrupción, la pasarela (Adapter) aprueba, " +
        "y la cadena de eventos PagoConfirmadoV1 → SancionPagadaV1 → PuntosDescontadosV1 recorre los tres servicios.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        var sancion = contexto.Sancion("velocidad");

        contexto.Narrador.Paso("Consultar cuánto debe pagar hoy (estrategia DescuentoPorProntoPago: 50 % dentro de 5 días)");
        var valor = await contexto.ConsultarValorAPagarAsync(sancion);

        contexto.Narrador.Paso("Intentar pagar el valor SIN descuento: la regla MontoDebeCoincidirConLaObligacion lo impide (422)");
        await contexto.PagarAsync(sancion, valor * 2, "tok_visa_4242");

        contexto.Narrador.Paso($"Pagar el valor correcto ({valor:N0} COP)");
        await contexto.PagarAsync(sancion, valor, "tok_visa_4242");
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("Verificar el efecto final en Licencias (consistencia eventual)");
        var saldo = await contexto.ConsultarSaldoAsync();
        contexto.Narrador.Exito($"Saldo de puntos de Ana: {saldo} (30 − 8 por la infracción C29)");
    }
}
