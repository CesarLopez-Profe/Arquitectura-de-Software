namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario08SuspensionDeLicencia : IEscenario
{
    public string Titulo => "Ana conduce en estado de embriaguez: se agotan los puntos y la licencia queda suspendida";

    public string Proposito =>
        "Invariante del agregado Licencia: si el saldo llega a 0, la suspensión ocurre en la MISMA operación " +
        "(Suspender es privado). LicenciaSuspendidaV1 sale por webhook al RUNT y Ana recibe correo, SMS y push.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        contexto.Narrador.Paso("Registrar un comparendo F (30 puntos)");
        var sancion = await contexto.RegistrarComparendoAsync("embriaguez", "F", "Vía Las Palmas km 5");
        await contexto.EsperarAsync();

        var valor = await contexto.ConsultarValorAPagarAsync(sancion);
        contexto.Narrador.Paso("Pagar la sanción");
        await contexto.PagarAsync(sancion, valor, "tok_visa_4242");
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("Consultar la licencia");
        await contexto.Cliente.GetAsync("licencias", $"/api/licencias/{contexto.LicenciaDeAna}");

        contexto.Narrador.Paso("Intentar renovarla: SoloSeRenuevaUnaLicenciaVigente lo impide (422)");
        await contexto.Cliente.PostAsync("licencias", $"/api/licencias/{contexto.LicenciaDeAna}/renovacion", new { });
    }
}
