namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario10Resumen : IEscenario
{
    public string Titulo => "Resumen: qué quedó en cada base de datos y en cada canal";

    public string Proposito =>
        "Cada microservicio tiene SU base de datos (nadie comparte tablas). Todo lo persistido y todo lo enviado " +
        "por los canales quedó como JSON en la carpeta de la simulación para inspeccionarlo.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        var plataforma = contexto.Plataforma;

        foreach (var (nombre, host) in plataforma.Microservicios)
        {
            var conteo = plataforma.BaseDeDatosDe(host).ContarPorColeccion();
            contexto.Narrador.Paso($"BD de {nombre}: " +
                                   string.Join(", ", conteo.OrderBy(c => c.Key).Select(c => $"{c.Key}={c.Value}")));
        }

        var broker = plataforma.Entorno.Broker;
        contexto.Narrador.Paso($"Bus: {broker.Historial.Count} mensajes publicados, {broker.MensajesMuertos.Count} en la cola de mensajes muertos");

        foreach (var sistema in plataforma.SistemasExternos)
            contexto.Narrador.Paso($"Webhooks recibidos por {sistema.NombreVisible}: {sistema.Recibidos}");

        var carpeta = plataforma.Entorno.CarpetaRaiz;
        var auditoria = Path.Combine(carpeta, "auditoria", "eventos.jsonl");
        var lineasDeAuditoria = File.Exists(auditoria) ? (await File.ReadAllLinesAsync(auditoria)).Length : 0;
        contexto.Narrador.Paso($"Bitácora de auditoría (JSON Lines): {lineasDeAuditoria} eventos");

        contexto.Narrador.Paso("Archivos JSON generados por carpeta:");
        foreach (var subcarpeta in Directory.GetDirectories(carpeta).Order())
        {
            var archivos = Directory.GetFiles(subcarpeta, "*.*", SearchOption.AllDirectories).Length;
            contexto.Narrador.Explicacion($"{Path.GetFileName(subcarpeta),-16} {archivos,4} archivo(s)");
        }

        contexto.Narrador.Exito($"Explore la carpeta: {carpeta}");
    }
}
