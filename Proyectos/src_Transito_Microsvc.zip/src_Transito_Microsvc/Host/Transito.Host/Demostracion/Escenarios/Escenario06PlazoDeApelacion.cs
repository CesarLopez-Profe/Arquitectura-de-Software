namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario06PlazoDeApelacion : IEscenario
{
    public string Titulo => "Pasan 12 días: el plazo para apelar venció y el descuento bajó al 25 %";

    public string Proposito =>
        "El dominio nunca consulta la hora: la recibe como parámetro. Por eso un reloj simulado permite " +
        "probar reglas de tiempo (plazo de apelación, descuento por pronto pago) sin esperar días reales.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        contexto.Narrador.Paso("Registrar un comparendo C02 (estacionar en sitio prohibido)");
        var sancion = await contexto.RegistrarComparendoAsync("parqueo", "C02", "Calle 10 con Cra. 37, El Poblado");
        await contexto.EsperarAsync();

        contexto.Reloj.Avanzar(TimeSpan.FromDays(12));
        contexto.Narrador.Explicacion($"Reloj simulado adelantado 12 días → {contexto.Reloj.Now:dd/MM/yyyy}");

        contexto.Narrador.Paso("Apelar ahora: la regla ApelacionDebePresentarseDentroDelPlazo (11 días) lo impide");
        await contexto.Cliente.PostAsync("sanciones", $"/api/sanciones/{sancion}/apelacion",
            new { motivo = "La señal de prohibido estaba tapada por un árbol" });

        contexto.Narrador.Paso("Consultar el valor a pagar: ya no hay 50 %, ahora es 25 % (días 6 a 20)");
        await contexto.ConsultarValorAPagarAsync(sancion);
    }
}
