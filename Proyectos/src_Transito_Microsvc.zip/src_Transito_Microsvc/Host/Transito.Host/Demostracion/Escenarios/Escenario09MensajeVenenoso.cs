using Pagos.Contracts;
using Transito.BuildingBlocks.Infrastructure.Mensajeria;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario09MensajeVenenoso : IEscenario
{
    public string Titulo => "Un productor defectuoso publica un pago de una sanción que no existe (mensaje venenoso)";

    public string Proposito =>
        "El consumidor falla, el broker reintenta con espera exponencial y, al agotar los intentos, mueve el " +
        "mensaje a la cola de mensajes muertos (dead letter queue) para revisión manual. Nada se corrompe.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        var broker = contexto.Plataforma.Entorno.Broker;
        var contrato = new PagoConfirmadoV1(
            Guid.NewGuid(), contexto.Reloj.Now, Guid.NewGuid(), "REC-2026-999", "Sancion",
            ObligacionId: Guid.NewGuid(), Monto: 1000m, Moneda: "COP", MetodoPago: "Efectivo");

        var mensaje = new ConstructorDeMensaje()
            .ConId(contrato.EventoId)
            .DeTipo(nameof(PagoConfirmadoV1))
            .EnTopico(PagosTopicos.PagoConfirmado)
            .DesdeOrigen("productor-defectuoso")
            .ConCorrelacion(Guid.NewGuid())
            .OcurridoEn(contrato.OcurrioEn)
            .ConContenido(SerializadorJson.Instancia.ConvertirAElemento(contrato, typeof(PagoConfirmadoV1)))
            .Construir();

        contexto.Narrador.Paso("Publicar directamente en el bus el mensaje defectuoso");
        await broker.PublicarAsync(mensaje, CancellationToken.None);
        await contexto.EsperarAsync();

        foreach (var muerto in broker.MensajesMuertos)
            contexto.Narrador.Fallo($"Cola de mensajes muertos: {muerto.Mensaje.Tipo} para {muerto.Suscriptor} " +
                                    $"tras {muerto.Intentos} intentos — {muerto.Error}");
    }
}
