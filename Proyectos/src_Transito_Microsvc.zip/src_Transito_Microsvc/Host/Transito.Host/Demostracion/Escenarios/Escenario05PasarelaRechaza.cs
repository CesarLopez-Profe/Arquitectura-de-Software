namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario05PasarelaRechaza : IEscenario
{
    public string Titulo => "La pasarela rechaza la tarjeta y Ana reintenta con otra";

    public string Proposito =>
        "Patrón State en el agregado Pago: Pendiente → Rechazado. Un pago rechazado no queda 'activo', así que " +
        "no bloquea un nuevo intento. El rechazo no viaja a otros servicios (no hay traductor para PagoRechazado).";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        contexto.Narrador.Paso("Registrar un comparendo D04 (pasar el semáforo en rojo, 10 puntos)");
        var sancion = await contexto.RegistrarComparendoAsync("semaforo", "D04", "Cra. 43A con Calle 1Sur, Medellín");
        await contexto.EsperarAsync();

        var valor = await contexto.ConsultarValorAPagarAsync(sancion);

        contexto.Narrador.Paso("Pagar con una tarjeta sin fondos (token 'tok_decline'): 402 Payment Required");
        await contexto.PagarAsync(sancion, valor, "tok_decline");
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("Reintentar con otra tarjeta");
        await contexto.PagarAsync(sancion, valor, "tok_mastercard_5555");
        await contexto.EsperarAsync();

        var saldo = await contexto.ConsultarSaldoAsync();
        contexto.Narrador.Exito($"Saldo de puntos de Ana: {saldo} (22 − 10)");
    }
}
