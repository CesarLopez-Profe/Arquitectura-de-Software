using Transito.Host.Plataforma;

namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario01ExpedirLicencia : IEscenario
{
    public string Titulo => "Licencias expide una licencia B1 a Ana";

    public string Proposito =>
        "Caso de uso completo: HTTP → middlewares → mediador → validación → servicio de dominio con reglas " +
        "abiertas a extensión → agregado → unidad de trabajo (JSON + bandeja de salida) → eventos.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        contexto.Narrador.Paso("Expedir licencia B1");
        var expedida = await contexto.Cliente.PostAsync("licencias", "/api/licencias",
            new { conductorId = ContextoDeDemo.ConductoraAna, categoria = "B1" });
        contexto.LicenciaDeAna = expedida.LeerGuid("licenciaId");
        await contexto.EsperarAsync();

        contexto.Narrador.Paso("Pedir OTRA licencia B1: la regla ConductorNoDebeTenerOtraLicenciaActivaDeLaCategoria la rechaza (422)");
        await contexto.Cliente.PostAsync("licencias", "/api/licencias",
            new { conductorId = ContextoDeDemo.ConductoraAna, categoria = "B1" });

        contexto.Narrador.Paso("Enviar datos mal formados: el validador de la capa de aplicación responde 400 con todos los errores");
        await contexto.Cliente.PostAsync("licencias", "/api/licencias", new { conductorId = Guid.Empty, categoria = "Z9" });

        var documento = contexto.Plataforma.BaseDeDatosDe(contexto.Plataforma.Licencias)
            .Obtener("licencias", contexto.LicenciaDeAna.ToString());
        contexto.Narrador.Json($"Documento JSON guardado en la BD de Licencias (versión {documento?.Version})", documento?.Json ?? "(no encontrado)");
    }
}
