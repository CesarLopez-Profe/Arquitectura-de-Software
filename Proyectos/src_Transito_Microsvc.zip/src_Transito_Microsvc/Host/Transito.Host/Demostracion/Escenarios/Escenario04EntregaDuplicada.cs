using Sanciones.Contracts;

namespace Transito.Host.Demostracion.Escenarios;

public sealed class Escenario04EntregaDuplicada : IEscenario
{
    public string Titulo => "El bus entrega DOS veces SancionPagadaV1 (idempotencia)";

    public string Proposito =>
        "Los brokers garantizan entrega 'al menos una vez'. La bandeja de entrada (inbox) de Licencias detecta " +
        "el duplicado y lo descarta; aun si pasara, el agregado Licencia no descuenta dos veces la misma sanción.";

    public async Task EjecutarAsync(ContextoDeDemo contexto)
    {
        var mensaje = contexto.Plataforma.Entorno.Broker.Historial
            .Last(m => m.Topico == SancionesTopicos.SancionPagada);

        contexto.Narrador.Paso($"Reentregar el mensaje {mensaje.Tipo} {mensaje.Id.ToString()[..8]}… al bus");
        await contexto.Plataforma.Entorno.Broker.ReentregarAsync(mensaje.Id);
        await contexto.EsperarAsync();

        var saldo = await contexto.ConsultarSaldoAsync();
        contexto.Narrador.Exito($"El saldo sigue en {saldo}: el duplicado no tuvo efecto.");
    }
}
