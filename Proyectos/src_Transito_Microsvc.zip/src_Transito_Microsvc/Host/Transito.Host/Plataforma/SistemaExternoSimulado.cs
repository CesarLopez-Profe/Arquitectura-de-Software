using System.Text.Json;
using Microsoft.Extensions.Logging;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.Host.Plataforma;

/// <summary>
/// Sistema de terceros que recibe webhooks (RUNT, Policía). Solo registra lo que le llega y
/// responde 200, como haría un receptor real que encola el aviso para procesarlo después.
/// </summary>
public sealed class SistemaExternoSimulado(string host, string nombreVisible, ILogger logger)
{
    private int _recibidos;

    public string Host { get; } = host;
    public string NombreVisible { get; } = nombreVisible;
    public int Recibidos => Volatile.Read(ref _recibidos);

    public void Conectar(RedHttpSimulada red) => red.RegistrarHost(Host, AtenderAsync);

    private Task<RespuestaHttp> AtenderAsync(SolicitudHttp solicitud, CancellationToken cancellationToken)
    {
        Interlocked.Increment(ref _recibidos);

        var tipo = "?";
        if (solicitud.Cuerpo is not null)
        {
            using var documento = JsonDocument.Parse(solicitud.Cuerpo);
            if (documento.RootElement.TryGetProperty("tipo", out var valor))
                tipo = valor.GetString() ?? "?";
        }

        logger.LogInformation("{Sistema} recibió webhook {Tipo} en {Ruta}", NombreVisible, tipo, solicitud.Ruta);
        return Task.FromResult(new RespuestaHttp(200, """{"recibido":true}"""));
    }
}
