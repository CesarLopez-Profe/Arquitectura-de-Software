using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.Host.Demostracion;

namespace Transito.Host.Plataforma;

/// <summary>
/// Cliente externo (la app ciudadana, el agente de tránsito, el portal de pagos). Solo conoce
/// las APIs HTTP públicas: envía JSON y recibe JSON, igual que un navegador o una app móvil.
/// </summary>
public sealed class ClienteDeLaPlataforma(RedHttpSimulada red, Narrador narrador)
{
    public Task<RespuestaHttp> GetAsync(string host, string ruta) =>
        EnviarAsync(host, SolicitudHttp.Get(ruta), cuerpoMostrado: null);

    public Task<RespuestaHttp> PostAsync(string host, string ruta, object cuerpo)
    {
        var json = SerializadorJson.Instancia.Serializar(cuerpo, cuerpo.GetType(), indentado: false);
        return EnviarAsync(host, SolicitudHttp.Post(ruta, json), json);
    }

    private async Task<RespuestaHttp> EnviarAsync(string host, SolicitudHttp solicitud, string? cuerpoMostrado)
    {
        narrador.Peticion(solicitud.Metodo, host, solicitud.Ruta, cuerpoMostrado);
        var respuesta = await red.EnviarAsync(
            host, solicitud.ConEncabezado(EncabezadosHttp.Correlacion, Guid.NewGuid().ToString()), CancellationToken.None);
        narrador.Respuesta(respuesta);
        return respuesta;
    }
}
