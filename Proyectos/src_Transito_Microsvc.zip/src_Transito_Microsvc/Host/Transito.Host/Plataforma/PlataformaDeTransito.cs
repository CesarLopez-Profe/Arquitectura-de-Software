using Licencias.Api;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Pagos.Api;
using Sanciones.Api;
using Transito.BuildingBlocks.Infrastructure.Notificaciones;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Persistencia.Bandejas;
using Transito.BuildingBlocks.Infrastructure.Registro;
using Transito.BuildingBlocks.Infrastructure.Serializacion;
using Transito.BuildingBlocks.Infrastructure.Simulacion;
using Transito.Host.Demostracion;

namespace Transito.Host.Plataforma;

/// <summary>
/// Patrón Facade (estructural): una sola clase oculta todo lo necesario para levantar el sistema
/// (entorno compartido, tres microservicios con sus contenedores, sistemas externos, cliente HTTP).
/// El programa principal solo llama a <see cref="IniciarAsync"/> y usa el cliente.
/// </summary>
public sealed class PlataformaDeTransito : IAsyncDisposable
{
    public static readonly DateTimeOffset InicioDeLaSimulacion = new(2026, 10, 5, 8, 0, 0, TimeSpan.FromHours(-5));

    private readonly IReadOnlyList<ILoggerFactory> _fabricasDeRegistro;

    private PlataformaDeTransito(
        EntornoDeSimulacion entorno,
        IHost sanciones,
        IHost pagos,
        IHost licencias,
        IReadOnlyList<SistemaExternoSimulado> sistemasExternos,
        ClienteDeLaPlataforma cliente,
        IReadOnlyList<ILoggerFactory> fabricasDeRegistro)
    {
        Entorno = entorno;
        Sanciones = sanciones;
        Pagos = pagos;
        Licencias = licencias;
        SistemasExternos = sistemasExternos;
        Cliente = cliente;
        _fabricasDeRegistro = fabricasDeRegistro;
    }

    public EntornoDeSimulacion Entorno { get; }
    public IHost Sanciones { get; }
    public IHost Pagos { get; }
    public IHost Licencias { get; }
    public IReadOnlyList<SistemaExternoSimulado> SistemasExternos { get; }
    public ClienteDeLaPlataforma Cliente { get; }

    public IEnumerable<(string Nombre, IHost Host)> Microservicios =>
    [
        (MicroservicioSanciones.Nombre, Sanciones),
        (MicroservicioPagos.Nombre, Pagos),
        (MicroservicioLicencias.Nombre, Licencias)
    ];

    public static async Task<PlataformaDeTransito> IniciarAsync(string carpeta, Narrador narrador)
    {
        var registroDelBus = Fabrica("BUS", ConsoleColor.Magenta);
        var registroDeNotificaciones = Fabrica("NOTIFICA", ConsoleColor.White);
        var registroExterno = Fabrica("EXTERNO", ConsoleColor.DarkCyan);

        var entorno = EntornoDeSimulacion.Crear(
            carpeta,
            InicioDeLaSimulacion,
            registroDelBus,
            carpetaDeNotificaciones => new FabricaDeCanalesSimulados(
                carpetaDeNotificaciones, SerializadorJson.Instancia, registroDeNotificaciones));

        var sanciones = MicroservicioSanciones.Construir(entorno, Consola("SANCIONES", ConsoleColor.Yellow));
        var pagos = MicroservicioPagos.Construir(entorno, Consola("PAGOS", ConsoleColor.Green));
        var licencias = MicroservicioLicencias.Construir(entorno, Consola("LICENCIAS", ConsoleColor.Cyan));

        var sistemasExternos = new List<SistemaExternoSimulado>
        {
            new("runt", "RUNT (Registro Único Nacional de Tránsito)", registroExterno.CreateLogger("RUNT")),
            new("policia", "Policía de Tránsito", registroExterno.CreateLogger("Policia"))
        };

        narrador.Paso("Arrancando microservicios (cada uno con su contenedor, su BD y sus procesos en segundo plano)…");
        foreach (var host in new[] { sanciones, pagos, licencias })
            await host.StartAsync();
        foreach (var sistema in sistemasExternos)
            sistema.Conectar(entorno.Red);

        narrador.Explicacion($"Hosts en la red simulada: {string.Join(", ", entorno.Red.Hosts.Order())}");
        narrador.Explicacion($"Reloj simulado: {entorno.Reloj.Now:dd/MM/yyyy HH:mm} — Carpeta de la simulación: {entorno.CarpetaRaiz}");

        return new PlataformaDeTransito(
            entorno, sanciones, pagos, licencias, sistemasExternos,
            new ClienteDeLaPlataforma(entorno.Red, narrador),
            [registroDelBus, registroDeNotificaciones, registroExterno]);
    }

    /// <summary>
    /// Espera a que no queden eventos en ninguna bandeja de salida ni mensajes en vuelo en el bus
    /// (sin contar los suscriptores pausados). Así cada escenario muestra la cadena completa.
    /// </summary>
    public async Task EsperarPropagacionAsync(TimeSpan? limite = null)
    {
        var hasta = DateTime.UtcNow + (limite ?? TimeSpan.FromSeconds(15));
        var lecturasEnCero = 0;
        while (DateTime.UtcNow < hasta)
        {
            var pendientes = Entorno.Broker.PendientesActivos
                             + Microservicios.Sum(m => m.Host.Services.GetRequiredService<MonitorDeBandejaDeSalida>().Pendientes());
            lecturasEnCero = pendientes == 0 ? lecturasEnCero + 1 : 0;
            if (lecturasEnCero >= 4)
                return;
            await Task.Delay(50);
        }
    }

    public BaseDeDatosDocumental BaseDeDatosDe(IHost microservicio) =>
        microservicio.Services.GetRequiredService<BaseDeDatosDocumental>();

    public async ValueTask DisposeAsync()
    {
        foreach (var (_, host) in Microservicios)
        {
            await host.StopAsync();
            host.Dispose();
        }
        Entorno.Dispose();
        foreach (var fabrica in _fabricasDeRegistro)
            fabrica.Dispose();
    }

    private static ILoggerFactory Fabrica(string prefijo, ConsoleColor color) =>
        LoggerFactory.Create(registro => registro.AddProvider(new ProveedorDeConsolaCompacta(prefijo, color)));

    private static Action<ILoggingBuilder> Consola(string prefijo, ConsoleColor color) =>
        registro => registro.AddProvider(new ProveedorDeConsolaCompacta(prefijo, color));
}
