using System.Text.Json;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Transito.Host.Plataforma;

/// <summary>Lectura cómoda de propiedades del cuerpo JSON de una respuesta.</summary>
public static class RespuestaHttpExtensiones
{
    public static Guid LeerGuid(this RespuestaHttp respuesta, string propiedad) =>
        Leer(respuesta, propiedad).GetGuid();

    public static decimal LeerDecimal(this RespuestaHttp respuesta, string propiedad) =>
        Leer(respuesta, propiedad).GetDecimal();

    public static int LeerEntero(this RespuestaHttp respuesta, string propiedad) =>
        Leer(respuesta, propiedad).GetInt32();

    public static string LeerTexto(this RespuestaHttp respuesta, string propiedad) =>
        Leer(respuesta, propiedad).ToString();

    private static JsonElement Leer(RespuestaHttp respuesta, string propiedad)
    {
        if (respuesta.Cuerpo is null)
            throw new InvalidOperationException($"La respuesta {respuesta.Codigo} no tiene cuerpo.");
        using var documento = JsonDocument.Parse(respuesta.Cuerpo);
        return documento.RootElement.GetProperty(propiedad).Clone();
    }
}
