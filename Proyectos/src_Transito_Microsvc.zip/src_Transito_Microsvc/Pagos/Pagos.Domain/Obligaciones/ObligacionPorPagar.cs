using Pagos.Domain.Pagos;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Obligaciones;

/// <summary>
/// La "parte" de una sanción que le importa a Pagos: cuánto se debe y si se puede pagar.
/// Es un modelo propio de este contexto; no es la entidad Sancion ni el contrato de Sanciones.
/// </summary>
public sealed record ObligacionPorPagar
{
    public ObligacionPorPagar(ReferenciaObligacion referencia, Dinero valorAPagar, bool admitePago, string descripcion)
    {
        Referencia = Guard.NoNulo(referencia, "referencia de la obligación");
        ValorAPagar = Guard.NoNulo(valorAPagar, "valor a pagar");
        AdmitePago = admitePago;
        Descripcion = Guard.Texto(descripcion, "descripción de la obligación", 300);
    }

    public ReferenciaObligacion Referencia { get; }
    public Dinero ValorAPagar { get; }
    public bool AdmitePago { get; }
    public string Descripcion { get; }
}
