using Pagos.Domain.Pagos;

namespace Pagos.Domain.Obligaciones;

/// <summary>
/// Puerto hacia el contexto dueño de la obligación (hoy Sanciones). La implementación en
/// infraestructura es la capa anticorrupción: llama al servicio remoto y traduce su contrato a
/// <see cref="ObligacionPorPagar"/>.
/// </summary>
public interface IConsultaDeObligaciones
{
    Task<ObligacionPorPagar?> ObtenerAsync(
        ReferenciaObligacion referencia,
        DateTimeOffset fechaPago,
        CancellationToken cancellationToken);
}
