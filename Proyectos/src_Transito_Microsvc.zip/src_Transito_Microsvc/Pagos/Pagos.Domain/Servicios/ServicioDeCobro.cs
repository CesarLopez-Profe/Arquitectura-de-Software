using Pagos.Domain.Obligaciones;
using Pagos.Domain.Pagos;
using Pagos.Domain.Pagos.Reglas;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Servicios;

/// <summary>
/// Servicio de dominio: iniciar un pago exige reglas que no caben en un solo agregado (la
/// obligación vive en otro contexto y la unicidad depende de otros pagos). Solo depende de
/// puertos, así que se prueba sin infraestructura.
/// </summary>
public sealed class ServicioDeCobro(
    IConsultaDeObligaciones obligaciones,
    IPagoRepository pagos,
    IGeneradorNumeroRecibo generadorRecibo)
{
    public async Task<Pago> IniciarPagoAsync(
        ReferenciaObligacion referencia,
        Dinero monto,
        MetodoPago metodo,
        CorreoElectronico correoPagador,
        DateTimeOffset ahora,
        CancellationToken cancellationToken)
    {
        var obligacion = await obligaciones.ObtenerAsync(referencia, ahora, cancellationToken);

        BusinessRules.Check(new ObligacionDebeExistir(obligacion, referencia));
        BusinessRules.Check(new ObligacionDebeAdmitirPago(obligacion!));
        BusinessRules.Check(new MontoDebeCoincidirConLaObligacion(monto, obligacion!));

        var existeActivo = await pagos.ExistePagoActivoParaAsync(referencia, cancellationToken);
        BusinessRules.Check(new NoDebeExistirOtroPagoActivo(existeActivo, referencia));

        var recibo = await generadorRecibo.SiguienteAsync(ahora.Year, cancellationToken);

        return Pago.Iniciar(PagoId.Nuevo(), recibo, referencia, monto, metodo, correoPagador, ahora);
    }
}
