using Pagos.Domain.Pagos;

namespace Pagos.Domain.Servicios;

/// <summary>Puerto: el consecutivo depende de un almacenamiento externo.</summary>
public interface IGeneradorNumeroRecibo
{
    Task<NumeroRecibo> SiguienteAsync(int anio, CancellationToken cancellationToken);
}
