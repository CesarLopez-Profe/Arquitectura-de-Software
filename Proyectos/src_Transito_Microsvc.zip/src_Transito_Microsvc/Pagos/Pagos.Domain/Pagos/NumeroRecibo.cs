using System.Text.RegularExpressions;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos;

/// <summary>Número de recibo con formato REC-AAAA-NNN.</summary>
public sealed partial record NumeroRecibo
{
    private readonly string? _valor;

    private NumeroRecibo() { }

    public string Valor
    {
        get => Guard.Inicializado(_valor, nameof(Valor));
        private init
        {
            var normalizado = Guard.Texto(value, "número de recibo", 20).ToUpperInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un número de recibo válido (REC-AAAA-NNN).");
            _valor = normalizado;
        }
    }

    public static NumeroRecibo De(string valor) => new() { Valor = valor };

    public static NumeroRecibo Generar(int anio, long consecutivo) => De($"REC-{anio}-{consecutivo:D3}");

    public override string ToString() => Valor;

    [GeneratedRegex(@"^REC-\d{4}-\d{3,}$")]
    private static partial Regex Formato();
}
