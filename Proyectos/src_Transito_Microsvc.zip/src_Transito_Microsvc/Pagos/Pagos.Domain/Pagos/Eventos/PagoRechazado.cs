using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Eventos;

public sealed record PagoRechazado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    ReferenciaObligacion Obligacion,
    string Motivo) : DomainEvent(OcurrioEn);
