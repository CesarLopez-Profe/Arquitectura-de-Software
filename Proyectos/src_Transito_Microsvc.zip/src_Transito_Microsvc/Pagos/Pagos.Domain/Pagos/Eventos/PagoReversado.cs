using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Eventos;

public sealed record PagoReversado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    ReferenciaObligacion Obligacion,
    Dinero Monto,
    string Motivo) : DomainEvent(OcurrioEn);
