using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Eventos;

public sealed record PagoConfirmado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    string NumeroRecibo,
    ReferenciaObligacion Obligacion,
    Dinero Monto,
    MetodoPago Metodo) : DomainEvent(OcurrioEn);
