using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Eventos;

public sealed record PagoIniciado(
    DateTimeOffset OcurrioEn,
    PagoId PagoId,
    ReferenciaObligacion Obligacion,
    Dinero Monto,
    MetodoPago Metodo) : DomainEvent(OcurrioEn);
