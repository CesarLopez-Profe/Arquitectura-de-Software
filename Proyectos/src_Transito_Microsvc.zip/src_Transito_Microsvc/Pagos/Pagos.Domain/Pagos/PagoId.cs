using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos;

/// <summary>Identificador fuertemente tipado del pago.</summary>
public readonly record struct PagoId
{
    private readonly Guid _valor;

    public PagoId(Guid valor) => Valor = valor;

    public Guid Valor
    {
        get => _valor != Guid.Empty
            ? _valor
            : throw new InvalidOperationException("PagoId sin valor: se creó con default.");
        init => _valor = Guard.NoVacio(value, "identificador del pago");
    }

    public static PagoId Nuevo() => new(Guid.NewGuid());

    public override string ToString() => _valor.ToString();
}
