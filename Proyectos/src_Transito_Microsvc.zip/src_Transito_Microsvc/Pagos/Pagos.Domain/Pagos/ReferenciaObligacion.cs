using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos;

/// <summary>
/// Qué se está pagando. Pagos no conoce el agregado Sancion: solo su tipo e identificador.
/// Esto permite cobrar otros conceptos en el futuro sin cambiar el agregado Pago.
/// </summary>
public sealed record ReferenciaObligacion
{
    private readonly TipoObligacion _tipo;
    private readonly Guid _obligacionId;

    public ReferenciaObligacion(TipoObligacion tipo, Guid obligacionId)
    {
        Tipo = tipo;
        ObligacionId = obligacionId;
    }

    public TipoObligacion Tipo
    {
        get => _tipo;
        private init => _tipo = Guard.Definido(value, "tipo de obligación");
    }

    public Guid ObligacionId
    {
        get => Guard.Asignado(_obligacionId, nameof(ObligacionId));
        private init => _obligacionId = Guard.NoVacio(value, "obligación a pagar");
    }

    public static ReferenciaObligacion DeSancion(Guid sancionId) => new(TipoObligacion.Sancion, sancionId);

    public override string ToString() => $"{Tipo}:{ObligacionId}";
}
