namespace Pagos.Domain.Pagos;

/// <summary>Transiciones posibles en el ciclo de vida de un pago.</summary>
public enum OperacionDePago
{
    Confirmar = 1,
    Rechazar = 2,
    Reversar = 3
}
