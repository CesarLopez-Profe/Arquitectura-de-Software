using System.Text.RegularExpressions;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos;

/// <summary>Correo del pagador, donde se envía el recibo. Value object con validación de formato.</summary>
public sealed partial record CorreoElectronico
{
    private readonly string? _valor;

    private CorreoElectronico() { }

    /// <summary>Setter: normaliza a minúsculas y valida un formato básico usuario@dominio.ext.</summary>
    public string Valor
    {
        get => Guard.Inicializado(_valor, nameof(Valor));
        private init
        {
            var normalizado = Guard.Texto(value, "correo electrónico", 120).ToLowerInvariant();
            if (!Formato().IsMatch(normalizado))
                throw new DomainException($"'{value}' no es un correo electrónico válido.");
            _valor = normalizado;
        }
    }

    public static CorreoElectronico De(string valor) => new() { Valor = valor };

    public override string ToString() => Valor;

    [GeneratedRegex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$")]
    private static partial Regex Formato();
}
