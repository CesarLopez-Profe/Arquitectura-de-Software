namespace Pagos.Domain.Pagos;

public enum MetodoPago
{
    Efectivo = 1,
    TarjetaCredito = 2,
    TarjetaDebito = 3,
    Transferencia = 4,
    Pse = 5
}
