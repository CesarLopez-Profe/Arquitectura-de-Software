using System.Diagnostics;

namespace Pagos.Domain.Pagos.Estados;

/// <summary>Estado final: la pasarela no autorizó el cobro.</summary>
internal sealed class EstadoRechazado : EstadoDePago
{
    public override EstadoPago Codigo => EstadoPago.Rechazado;

    public override bool Permite(OperacionDePago operacion) => false;

    protected override EstadoDePago Siguiente(OperacionDePago operacion) => throw new UnreachableException();
}
