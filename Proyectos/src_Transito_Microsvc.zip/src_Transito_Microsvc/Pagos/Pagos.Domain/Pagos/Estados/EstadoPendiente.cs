namespace Pagos.Domain.Pagos.Estados;

/// <summary>Esperando respuesta de la pasarela: se puede confirmar o rechazar.</summary>
internal sealed class EstadoPendiente : EstadoDePago
{
    public override EstadoPago Codigo => EstadoPago.Pendiente;

    public override bool EstaActivo => true;

    public override bool Permite(OperacionDePago operacion) =>
        operacion is OperacionDePago.Confirmar or OperacionDePago.Rechazar;

    protected override EstadoDePago Siguiente(OperacionDePago operacion) =>
        operacion == OperacionDePago.Confirmar ? Confirmado : Rechazado;
}
