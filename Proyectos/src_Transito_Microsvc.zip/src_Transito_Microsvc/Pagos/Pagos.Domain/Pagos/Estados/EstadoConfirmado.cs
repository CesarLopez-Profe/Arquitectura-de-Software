namespace Pagos.Domain.Pagos.Estados;

/// <summary>El dinero ingresó. Solo admite la compensación (reversar).</summary>
internal sealed class EstadoConfirmado : EstadoDePago
{
    public override EstadoPago Codigo => EstadoPago.Confirmado;

    public override bool EstaActivo => true;

    public override bool Permite(OperacionDePago operacion) => operacion == OperacionDePago.Reversar;

    protected override EstadoDePago Siguiente(OperacionDePago operacion) => Reversado;
}
