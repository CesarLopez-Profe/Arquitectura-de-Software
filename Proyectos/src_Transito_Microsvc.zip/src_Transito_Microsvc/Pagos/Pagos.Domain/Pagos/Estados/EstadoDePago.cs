using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Estados;

/// <summary>
/// Patrón State (comportamiento): cada estado del pago es un objeto que sabe qué operaciones
/// permite y a qué estado lleva cada una. El agregado Pago delega en su estado actual en lugar
/// de llenarse de <c>if/switch</c> sobre un enum.
/// <code>
/// Pendiente ──Confirmar──► Confirmado ──Reversar──► Reversado
///     └──────Rechazar───► Rechazado
/// </code>
/// Los estados no guardan datos, así que hay una única instancia de cada uno (Singleton/Flyweight).
/// El constructor <c>private protected</c> impide crear estados fuera de este ensamblado.
/// </summary>
public abstract class EstadoDePago
{
    public static readonly EstadoDePago Pendiente = new EstadoPendiente();
    public static readonly EstadoDePago Confirmado = new EstadoConfirmado();
    public static readonly EstadoDePago Rechazado = new EstadoRechazado();
    public static readonly EstadoDePago Reversado = new EstadoReversado();

    private protected EstadoDePago() { }

    public abstract EstadoPago Codigo { get; }

    /// <summary>Un pago activo bloquea que se inicie otro pago para la misma obligación.</summary>
    public virtual bool EstaActivo => false;

    public abstract bool Permite(OperacionDePago operacion);

    public EstadoDePago Aplicar(OperacionDePago operacion) =>
        Permite(operacion)
            ? Siguiente(operacion)
            : throw new InvalidOperationException($"El estado {Codigo} no permite {operacion}.");

    protected abstract EstadoDePago Siguiente(OperacionDePago operacion);

    /// <summary>Método fábrica: reconstruye el objeto estado a partir del código persistido.</summary>
    public static EstadoDePago Desde(EstadoPago codigo) => codigo switch
    {
        EstadoPago.Pendiente => Pendiente,
        EstadoPago.Confirmado => Confirmado,
        EstadoPago.Rechazado => Rechazado,
        EstadoPago.Reversado => Reversado,
        _ => throw new DomainException($"Estado de pago desconocido: {codigo}.")
    };

    public override string ToString() => Codigo.ToString();
}
