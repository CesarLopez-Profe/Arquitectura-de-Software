using System.Diagnostics;

namespace Pagos.Domain.Pagos.Estados;

/// <summary>Estado final: el dinero se devolvió al pagador.</summary>
internal sealed class EstadoReversado : EstadoDePago
{
    public override EstadoPago Codigo => EstadoPago.Reversado;

    public override bool Permite(OperacionDePago operacion) => false;

    protected override EstadoDePago Siguiente(OperacionDePago operacion) => throw new UnreachableException();
}
