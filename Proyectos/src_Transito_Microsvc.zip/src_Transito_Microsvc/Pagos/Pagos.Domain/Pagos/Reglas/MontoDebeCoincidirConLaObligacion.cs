using Pagos.Domain.Obligaciones;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Reglas;

public sealed class MontoDebeCoincidirConLaObligacion(Dinero monto, ObligacionPorPagar obligacion) : IBusinessRule
{
    public bool IsBroken() => monto != obligacion.ValorAPagar;

    public string Message => $"El monto {monto} no coincide con el valor a pagar {obligacion.ValorAPagar}.";
}
