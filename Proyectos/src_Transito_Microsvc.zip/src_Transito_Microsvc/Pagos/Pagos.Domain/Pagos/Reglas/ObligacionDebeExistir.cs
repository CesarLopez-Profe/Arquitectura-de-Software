using Pagos.Domain.Obligaciones;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Reglas;

public sealed class ObligacionDebeExistir(ObligacionPorPagar? obligacion, ReferenciaObligacion referencia) : IBusinessRule
{
    public bool IsBroken() => obligacion is null;

    public string Message => $"No existe la obligación {referencia}.";
}
