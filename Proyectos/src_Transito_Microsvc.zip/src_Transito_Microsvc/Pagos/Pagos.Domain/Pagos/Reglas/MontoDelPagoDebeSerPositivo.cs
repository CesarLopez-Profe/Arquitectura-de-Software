using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Reglas;

public sealed class MontoDelPagoDebeSerPositivo(Dinero monto) : IBusinessRule
{
    public bool IsBroken() => monto.EsCero;

    public string Message => "El monto del pago debe ser mayor que cero.";
}
