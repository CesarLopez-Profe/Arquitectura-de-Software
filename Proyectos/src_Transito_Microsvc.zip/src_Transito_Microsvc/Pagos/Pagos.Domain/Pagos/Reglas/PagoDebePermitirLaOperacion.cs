using Pagos.Domain.Pagos.Estados;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Reglas;

/// <summary>La regla consulta al objeto estado (patrón State) si la operación está permitida.</summary>
public sealed class PagoDebePermitirLaOperacion(EstadoDePago estado, OperacionDePago operacion) : IBusinessRule
{
    public bool IsBroken() => !estado.Permite(operacion);

    public string Message => $"No se puede {operacion.ToString().ToLowerInvariant()} un pago en estado {estado.Codigo}.";
}
