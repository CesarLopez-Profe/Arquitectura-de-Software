using Pagos.Domain.Obligaciones;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos.Reglas;

public sealed class ObligacionDebeAdmitirPago(ObligacionPorPagar obligacion) : IBusinessRule
{
    public bool IsBroken() => !obligacion.AdmitePago;

    public string Message => $"La obligación {obligacion.Referencia} no admite pagos en este momento.";
}
