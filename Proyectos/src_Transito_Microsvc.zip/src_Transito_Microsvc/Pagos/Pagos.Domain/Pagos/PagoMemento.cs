namespace Pagos.Domain.Pagos;

/// <summary>Memento del agregado Pago: su estado completo con tipos primitivos.</summary>
public sealed record PagoMemento(
    Guid Id,
    string Recibo,
    TipoObligacion TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    MetodoPago Metodo,
    string CorreoPagador,
    EstadoPago Estado,
    DateTimeOffset FechaCreacion,
    DateTimeOffset? FechaConfirmacion,
    string? ReferenciaTransaccion,
    string? Observacion);
