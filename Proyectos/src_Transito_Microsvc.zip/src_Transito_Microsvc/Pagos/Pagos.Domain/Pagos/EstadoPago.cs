namespace Pagos.Domain.Pagos;

/// <summary>
/// Código del estado para mostrar y persistir. El COMPORTAMIENTO de cada estado vive en las
/// clases del patrón State (carpeta Estados).
/// </summary>
public enum EstadoPago
{
    Pendiente = 1,
    Confirmado = 2,
    Rechazado = 3,
    Reversado = 4
}
