namespace Pagos.Domain.Pagos;

/// <summary>Conceptos que Pagos sabe cobrar. Hoy solo sanciones; mañana, por ejemplo, trámites.</summary>
public enum TipoObligacion
{
    Sancion = 1
}
