namespace Pagos.Domain.Pagos;

/// <summary>Puerto de persistencia del agregado. La implementación vive en infraestructura.</summary>
public interface IPagoRepository
{
    Task<Pago?> ObtenerAsync(PagoId id, CancellationToken cancellationToken);
    Task<bool> ExistePagoActivoParaAsync(ReferenciaObligacion obligacion, CancellationToken cancellationToken);
    Task AgregarAsync(Pago pago, CancellationToken cancellationToken);
    Task ActualizarAsync(Pago pago, CancellationToken cancellationToken);
}
