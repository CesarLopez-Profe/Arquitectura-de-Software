using Pagos.Domain.Pagos.Estados;
using Pagos.Domain.Pagos.Eventos;
using Pagos.Domain.Pagos.Reglas;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Domain.Pagos;

/// <summary>
/// Raíz del agregado Pago. Su ciclo de vida lo gobierna el patrón State
/// (<see cref="EstadoDePago"/>): el agregado pregunta al estado actual si permite la operación
/// y le pide el siguiente estado. Así agregar un estado nuevo no obliga a reescribir los métodos.
/// </summary>
public sealed class Pago : AggregateRoot<PagoId>, IOriginador<Pago, PagoMemento>
{
    private NumeroRecibo? _recibo;
    private ReferenciaObligacion? _obligacion;
    private Dinero? _monto;
    private MetodoPago _metodo;
    private CorreoElectronico? _correoPagador;
    private EstadoDePago _estado = EstadoDePago.Pendiente;
    private DateTimeOffset _fechaCreacion;
    private DateTimeOffset? _fechaConfirmacion;
    private string? _referenciaTransaccion;
    private string? _observacion;

    private Pago(PagoId id) : base(id) { }

    public NumeroRecibo Recibo
    {
        get => Guard.Inicializado(_recibo, nameof(Recibo));
        private set => _recibo = Guard.NoNulo(value, "recibo");
    }

    public ReferenciaObligacion Obligacion
    {
        get => Guard.Inicializado(_obligacion, nameof(Obligacion));
        private set => _obligacion = Guard.NoNulo(value, "obligación");
    }

    public Dinero Monto
    {
        get => Guard.Inicializado(_monto, nameof(Monto));
        private set => _monto = Guard.NoNulo(value, "monto");
    }

    public MetodoPago Metodo
    {
        get => _metodo;
        private set => _metodo = Guard.Definido(value, "método de pago");
    }

    public CorreoElectronico CorreoPagador
    {
        get => Guard.Inicializado(_correoPagador, nameof(CorreoPagador));
        private set => _correoPagador = Guard.NoNulo(value, "correo del pagador");
    }

    public DateTimeOffset FechaCreacion
    {
        get => Guard.Asignado(_fechaCreacion, nameof(FechaCreacion));
        private set => _fechaCreacion = Guard.FechaValida(value, "fecha de creación");
    }

    /// <summary>Setter: si hay fecha, no puede ser anterior a la creación del pago.</summary>
    public DateTimeOffset? FechaConfirmacion
    {
        get => _fechaConfirmacion;
        private set
        {
            if (value is { } fecha && fecha < FechaCreacion)
                throw new DomainException("La confirmación no puede ser anterior a la creación del pago.");
            _fechaConfirmacion = value;
        }
    }

    public string? ReferenciaTransaccion
    {
        get => _referenciaTransaccion;
        private set => _referenciaTransaccion = Guard.TextoOpcional(value, "referencia de la transacción", 60);
    }

    public string? Observacion
    {
        get => _observacion;
        private set => _observacion = Guard.TextoOpcional(value, "observación", 300);
    }

    public EstadoPago Estado => _estado.Codigo;

    public bool EstaActivo => _estado.EstaActivo;

    /// <summary>
    /// Internal: un pago solo nace a través de <see cref="Servicios.ServicioDeCobro"/>, que valida
    /// las reglas que involucran a la obligación (otro contexto) y a otros pagos.
    /// </summary>
    internal static Pago Iniciar(
        PagoId id,
        NumeroRecibo recibo,
        ReferenciaObligacion obligacion,
        Dinero monto,
        MetodoPago metodo,
        CorreoElectronico correoPagador,
        DateTimeOffset ahora)
    {
        CheckRule(new MontoDelPagoDebeSerPositivo(monto));

        var pago = new Pago(id)
        {
            Recibo = recibo,
            Obligacion = obligacion,
            Monto = monto,
            Metodo = metodo,
            CorreoPagador = correoPagador,
            FechaCreacion = ahora
        };
        pago.Raise(new PagoIniciado(ahora, id, obligacion, monto, metodo));
        return pago;
    }

    public void Confirmar(string referenciaTransaccion, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Confirmar);

        ReferenciaTransaccion = Guard.Texto(referenciaTransaccion, "referencia de la transacción", 60);
        FechaConfirmacion = ahora;
        TransicionarCon(OperacionDePago.Confirmar);

        Raise(new PagoConfirmado(ahora, Id, Recibo.Valor, Obligacion, Monto, Metodo));
    }

    public void Rechazar(string motivo, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Rechazar);

        Observacion = Guard.Texto(motivo, "motivo del rechazo", 300);
        TransicionarCon(OperacionDePago.Rechazar);

        Raise(new PagoRechazado(ahora, Id, Obligacion, Observacion));
    }

    /// <summary>Compensación: devuelve un pago confirmado (por ejemplo, la sanción ya no admitía pago).</summary>
    public void Reversar(string motivo, DateTimeOffset ahora)
    {
        VerificarQuePermite(OperacionDePago.Reversar);

        Observacion = Guard.Texto(motivo, "motivo de la reversión", 300);
        TransicionarCon(OperacionDePago.Reversar);

        Raise(new PagoReversado(ahora, Id, Obligacion, Monto, Observacion));
    }

    private void VerificarQuePermite(OperacionDePago operacion) =>
        CheckRule(new PagoDebePermitirLaOperacion(_estado, operacion));

    private void TransicionarCon(OperacionDePago operacion) => _estado = _estado.Aplicar(operacion);

    // ---------- Memento ----------

    public PagoMemento CrearMemento() => new(
        Id.Valor,
        Recibo.Valor,
        Obligacion.Tipo,
        Obligacion.ObligacionId,
        Monto.Monto,
        Monto.Moneda,
        Metodo,
        CorreoPagador.Valor,
        Estado,
        FechaCreacion,
        FechaConfirmacion,
        ReferenciaTransaccion,
        Observacion);

    public static Pago RestaurarDesde(PagoMemento memento)
    {
        ArgumentNullException.ThrowIfNull(memento);

        return new Pago(new PagoId(memento.Id))
        {
            Recibo = NumeroRecibo.De(memento.Recibo),
            Obligacion = new ReferenciaObligacion(memento.TipoObligacion, memento.ObligacionId),
            Monto = Dinero.De(memento.Monto, memento.Moneda),
            Metodo = memento.Metodo,
            CorreoPagador = CorreoElectronico.De(memento.CorreoPagador),
            FechaCreacion = memento.FechaCreacion,
            FechaConfirmacion = memento.FechaConfirmacion,
            ReferenciaTransaccion = memento.ReferenciaTransaccion,
            Observacion = memento.Observacion,
            _estado = EstadoDePago.Desde(memento.Estado)
        };
    }
}
