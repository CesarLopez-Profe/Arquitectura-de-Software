namespace Pagos.Contracts;

/// <summary>
/// Se publica cuando la pasarela confirma el dinero. Sanciones lo consume cuando
/// TipoObligacion = "Sancion".
/// </summary>
public sealed record PagoConfirmadoV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid PagoId,
    string NumeroRecibo,
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string MetodoPago);
