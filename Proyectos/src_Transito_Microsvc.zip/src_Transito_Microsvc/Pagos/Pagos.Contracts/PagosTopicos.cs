namespace Pagos.Contracts;

/// <summary>Tópicos en los que Pagos publica. Convención: contexto.evento.version.</summary>
public static class PagosTopicos
{
    public const string Todos = "pagos.*";
    public const string PagoConfirmado = "pagos.pago-confirmado.v1";
    public const string PagoReversado = "pagos.pago-reversado.v1";
}
