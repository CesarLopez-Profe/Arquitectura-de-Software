namespace Pagos.Contracts;

/// <summary>Se publica cuando un pago confirmado se devuelve (compensación de la saga).</summary>
public sealed record PagoReversadoV1(
    Guid EventoId,
    DateTimeOffset OcurrioEn,
    Guid PagoId,
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string Motivo);
