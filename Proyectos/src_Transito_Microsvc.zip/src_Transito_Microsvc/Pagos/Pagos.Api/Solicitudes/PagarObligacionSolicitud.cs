namespace Pagos.Api.Solicitudes;

/// <summary>Cuerpo JSON de POST /api/pagos.</summary>
public sealed record PagarObligacionSolicitud(
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string MetodoPago,
    string TokenMedioDePago,
    string CorreoPagador);
