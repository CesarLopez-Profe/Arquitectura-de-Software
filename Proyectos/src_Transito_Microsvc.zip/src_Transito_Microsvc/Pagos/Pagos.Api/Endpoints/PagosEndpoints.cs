using Pagos.Api.Solicitudes;
using Pagos.Application.Comandos.PagarObligacion;
using Pagos.Application.Consultas.ObtenerPago;
using Transito.BuildingBlocks.Api;
using Transito.BuildingBlocks.Infrastructure.Http;

namespace Pagos.Api.Endpoints;

/// <summary>Adaptador primario: endpoints HTTP del recurso pago.</summary>
public sealed class PagosEndpoints : IModuloDeEndpoints
{
    public void Mapear(EnrutadorHttp enrutador) => enrutador
        .MapearPost("/api/pagos", PagarAsync)
        .MapearGet("/api/pagos/{id}", ObtenerAsync);

    /// <summary>201 si la pasarela aprueba; 402 (Payment Required) si la pasarela rechaza.</summary>
    private static async Task<RespuestaHttp> PagarAsync(ContextoHttp contexto, CancellationToken cancellationToken)
    {
        var s = contexto.LeerCuerpo<PagarObligacionSolicitud>();
        var resultado = await contexto.Mediador.EnviarAsync(
            new PagarObligacionComando(
                s.TipoObligacion, s.ObligacionId, s.Monto, s.Moneda, s.MetodoPago, s.TokenMedioDePago, s.CorreoPagador),
            cancellationToken);

        return resultado.Estado == "Confirmado"
            ? Resultados.Creado($"/api/pagos/{resultado.PagoId}", resultado)
            : Resultados.Problema(402, "Pago rechazado", resultado.Motivo);
    }

    private static async Task<RespuestaHttp> ObtenerAsync(ContextoHttp contexto, CancellationToken cancellationToken) =>
        Resultados.Ok(await contexto.Mediador.EnviarAsync(
            new ObtenerPagoConsulta(contexto.ParametroGuid("id")), cancellationToken));
}
