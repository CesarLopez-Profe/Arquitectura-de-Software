using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Pagos.Api.Endpoints;
using Pagos.Application.DependencyInjection;
using Pagos.Infrastructure.DependencyInjection;
using Transito.BuildingBlocks.Api.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Pagos.Api;

/// <summary>Composition root del microservicio Pagos.</summary>
public static class MicroservicioPagos
{
    public const string Nombre = "pagos";

    public static IHost Construir(EntornoDeSimulacion entorno, Action<ILoggingBuilder>? configurarRegistro = null)
    {
        ArgumentNullException.ThrowIfNull(entorno);

        var constructor = Host.CreateEmptyApplicationBuilder(new HostApplicationBuilderSettings { ApplicationName = Nombre });
        constructor.ConfigureContainer(new DefaultServiceProviderFactory(
            new ServiceProviderOptions { ValidateOnBuild = true, ValidateScopes = true }));

        constructor.Services.AddLogging(registro => configurarRegistro?.Invoke(registro));
        constructor.Services
            .AgregarAplicacionPagos()
            .AgregarInfraestructuraPagos(entorno, new OpcionesDeMicroservicio { Nombre = Nombre })
            .AgregarApiSimulada()
            .AgregarModuloDeEndpoints<PagosEndpoints>();

        return constructor.Build();
    }
}
