using Pagos.Domain.Pagos;
using Transito.BuildingBlocks.Application.Validacion;

namespace Pagos.Application.Comandos.PagarObligacion;

public sealed class PagarObligacionValidador : ValidadorBase<PagarObligacionComando>
{
    protected override void DefinirReglas(PagarObligacionComando instancia, ColectorDeErrores errores) =>
        errores
            .EnumValido<TipoObligacion>(instancia.TipoObligacion, nameof(instancia.TipoObligacion))
            .NoVacio(instancia.ObligacionId, nameof(instancia.ObligacionId))
            .Positivo(instancia.Monto, nameof(instancia.Monto))
            .Cumple(instancia.Moneda?.Trim().Length == 3, nameof(instancia.Moneda), "Debe ser un código ISO de 3 letras.")
            .EnumValido<MetodoPago>(instancia.MetodoPago, nameof(instancia.MetodoPago))
            .Requerido(instancia.TokenMedioDePago, nameof(instancia.TokenMedioDePago), 100)
            .Requerido(instancia.CorreoPagador, nameof(instancia.CorreoPagador), 120);
}
