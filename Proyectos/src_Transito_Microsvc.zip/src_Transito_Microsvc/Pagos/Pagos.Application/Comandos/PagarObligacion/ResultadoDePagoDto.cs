namespace Pagos.Application.Comandos.PagarObligacion;

public sealed record ResultadoDePagoDto(
    Guid PagoId,
    string NumeroRecibo,
    string Estado,
    decimal Monto,
    string Moneda,
    string? ReferenciaTransaccion,
    string? Motivo);
