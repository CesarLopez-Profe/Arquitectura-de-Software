using Pagos.Application.Puertos;
using Pagos.Domain.Pagos;
using Pagos.Domain.Servicios;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Tiempo;
using Transito.BuildingBlocks.Domain;

namespace Pagos.Application.Comandos.PagarObligacion;

/// <summary>
/// Caso de uso completo de cobro: el servicio de dominio valida e inicia el pago, la pasarela
/// autoriza y el agregado pasa a Confirmado o Rechazado. Todo se confirma en una transacción
/// (comportamiento transaccional), incluido el evento PagoConfirmado en la bandeja de salida.
/// </summary>
public sealed class PagarObligacionManejador(
    ServicioDeCobro servicioDeCobro,
    IPagoRepository pagos,
    IPasarelaDePagos pasarela,
    IClock reloj) : IManejadorDeComando<PagarObligacionComando, ResultadoDePagoDto>
{
    public async Task<ResultadoDePagoDto> ManejarAsync(PagarObligacionComando comando, CancellationToken cancellationToken)
    {
        var referencia = new ReferenciaObligacion(
            Enum.Parse<TipoObligacion>(comando.TipoObligacion, ignoreCase: true), comando.ObligacionId);
        var metodo = Enum.Parse<MetodoPago>(comando.MetodoPago, ignoreCase: true);

        var pago = await servicioDeCobro.IniciarPagoAsync(
            referencia,
            Dinero.De(comando.Monto, comando.Moneda),
            metodo,
            CorreoElectronico.De(comando.CorreoPagador),
            reloj.Now,
            cancellationToken);
        await pagos.AgregarAsync(pago, cancellationToken);

        var autorizacion = await pasarela.AutorizarAsync(
            new SolicitudDeAutorizacion(
                pago.Id.Valor, pago.Monto.Monto, pago.Monto.Moneda, metodo.ToString(),
                comando.TokenMedioDePago, $"Recibo {pago.Recibo}"),
            cancellationToken);

        if (autorizacion.Aprobada)
            pago.Confirmar(autorizacion.ReferenciaTransaccion!, reloj.Now);
        else
            pago.Rechazar(autorizacion.Motivo ?? "Rechazado por la pasarela", reloj.Now);

        return new ResultadoDePagoDto(
            pago.Id.Valor, pago.Recibo.Valor, pago.Estado.ToString(), pago.Monto.Monto, pago.Monto.Moneda,
            pago.ReferenciaTransaccion, pago.Observacion);
    }
}
