using Transito.BuildingBlocks.Application.Cqrs;

namespace Pagos.Application.Comandos.PagarObligacion;

/// <summary>Pagar una obligación (hoy, una sanción) con un medio de pago tokenizado.</summary>
public sealed record PagarObligacionComando(
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string MetodoPago,
    string TokenMedioDePago,
    string CorreoPagador) : IComando<ResultadoDePagoDto>;
