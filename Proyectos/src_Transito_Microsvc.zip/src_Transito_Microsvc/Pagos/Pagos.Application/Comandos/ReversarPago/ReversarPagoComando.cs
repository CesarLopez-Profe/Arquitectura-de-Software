using Transito.BuildingBlocks.Application.Cqrs;

namespace Pagos.Application.Comandos.ReversarPago;

/// <summary>Compensación: devolver un pago confirmado.</summary>
public sealed record ReversarPagoComando(Guid PagoId, string Motivo) : IComando<Unidad>;
