using Pagos.Domain.Pagos;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;
using Transito.BuildingBlocks.Application.Tiempo;

namespace Pagos.Application.Comandos.ReversarPago;

/// <summary>Idempotente: si el pago ya estaba reversado, no hace nada.</summary>
public sealed class ReversarPagoManejador(IPagoRepository pagos, IClock reloj)
    : IManejadorDeComando<ReversarPagoComando, Unidad>
{
    public async Task<Unidad> ManejarAsync(ReversarPagoComando comando, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(new PagoId(comando.PagoId), cancellationToken)
                   ?? throw new RecursoNoEncontradoException("el pago", comando.PagoId);

        if (pago.Estado == EstadoPago.Reversado)
            return Unidad.Valor;

        pago.Reversar(comando.Motivo, reloj.Now);
        await pagos.ActualizarAsync(pago, cancellationToken);
        return Unidad.Valor;
    }
}
