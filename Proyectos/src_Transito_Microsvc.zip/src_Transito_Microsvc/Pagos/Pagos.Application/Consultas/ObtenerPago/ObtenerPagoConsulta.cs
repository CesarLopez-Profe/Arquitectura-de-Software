using Transito.BuildingBlocks.Application.Cqrs;

namespace Pagos.Application.Consultas.ObtenerPago;

public sealed record ObtenerPagoConsulta(Guid PagoId) : IConsulta<PagoDto>;
