using Pagos.Domain.Pagos;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Excepciones;

namespace Pagos.Application.Consultas.ObtenerPago;

public sealed class ObtenerPagoManejador(IPagoRepository pagos) : IManejadorDeConsulta<ObtenerPagoConsulta, PagoDto>
{
    public async Task<PagoDto> ManejarAsync(ObtenerPagoConsulta consulta, CancellationToken cancellationToken)
    {
        if (consulta.PagoId == Guid.Empty)
            throw new RecursoNoEncontradoException("el pago", consulta.PagoId);

        var pago = await pagos.ObtenerAsync(new PagoId(consulta.PagoId), cancellationToken)
                   ?? throw new RecursoNoEncontradoException("el pago", consulta.PagoId);

        return new PagoDto(
            pago.Id.Valor, pago.Recibo.Valor, pago.Obligacion.Tipo.ToString(), pago.Obligacion.ObligacionId,
            pago.Monto.Monto, pago.Monto.Moneda, pago.Metodo.ToString(), pago.Estado.ToString(),
            pago.FechaCreacion, pago.FechaConfirmacion, pago.ReferenciaTransaccion, pago.Observacion);
    }
}
