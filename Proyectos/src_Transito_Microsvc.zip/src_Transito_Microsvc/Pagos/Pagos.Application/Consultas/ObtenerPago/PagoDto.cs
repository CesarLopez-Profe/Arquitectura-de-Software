namespace Pagos.Application.Consultas.ObtenerPago;

/// <summary>Modelo de lectura de un pago.</summary>
public sealed record PagoDto(
    Guid Id,
    string NumeroRecibo,
    string TipoObligacion,
    Guid ObligacionId,
    decimal Monto,
    string Moneda,
    string Metodo,
    string Estado,
    DateTimeOffset FechaCreacion,
    DateTimeOffset? FechaConfirmacion,
    string? ReferenciaTransaccion,
    string? Observacion);
