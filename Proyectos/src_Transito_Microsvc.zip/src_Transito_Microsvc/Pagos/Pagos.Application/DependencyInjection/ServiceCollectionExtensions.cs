using Microsoft.Extensions.DependencyInjection;
using Pagos.Domain.Servicios;
using Transito.BuildingBlocks.Application.DependencyInjection;

namespace Pagos.Application.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>Casos de uso de Pagos + servicio de dominio de cobro.</summary>
    public static IServiceCollection AgregarAplicacionPagos(this IServiceCollection services)
    {
        services.AgregarBloquesDeAplicacion(typeof(ServiceCollectionExtensions).Assembly);
        services.AddScoped<ServicioDeCobro>();
        return services;
    }
}
