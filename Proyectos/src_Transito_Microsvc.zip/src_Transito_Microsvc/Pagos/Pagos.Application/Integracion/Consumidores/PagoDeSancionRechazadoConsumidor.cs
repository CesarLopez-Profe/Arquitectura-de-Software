using Pagos.Application.Comandos.ReversarPago;
using Sanciones.Contracts;
using Transito.BuildingBlocks.Application.Cqrs;
using Transito.BuildingBlocks.Application.Integracion;

namespace Pagos.Application.Integracion.Consumidores;

/// <summary>
/// Paso de compensación de la saga coreografiada: Sanciones no pudo aplicar el pago, así que
/// Pagos lo reversa. Nadie orquesta; cada contexto reacciona a hechos.
/// </summary>
public sealed class PagoDeSancionRechazadoConsumidor(IMediador mediador)
    : IManejadorDeEventoDeIntegracion<PagoDeSancionRechazadoV1>
{
    public async Task ManejarAsync(
        PagoDeSancionRechazadoV1 mensaje,
        ContextoDeMensaje contexto,
        CancellationToken cancellationToken) =>
        await mediador.EnviarAsync(
            new ReversarPagoComando(mensaje.PagoId, $"Sanciones rechazó el pago: {mensaje.Motivo}"),
            cancellationToken);
}
