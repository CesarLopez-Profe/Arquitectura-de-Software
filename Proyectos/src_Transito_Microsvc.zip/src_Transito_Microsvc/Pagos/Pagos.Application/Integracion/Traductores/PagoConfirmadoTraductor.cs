using Pagos.Contracts;
using Pagos.Domain.Pagos.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Pagos.Application.Integracion.Traductores;

public sealed class PagoConfirmadoTraductor : TraductorDeEventoDeDominio<PagoConfirmado>
{
    protected override string Topico => PagosTopicos.PagoConfirmado;

    protected override object CrearContrato(PagoConfirmado evento) => new PagoConfirmadoV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.PagoId.Valor,
        evento.NumeroRecibo,
        evento.Obligacion.Tipo.ToString(),
        evento.Obligacion.ObligacionId,
        evento.Monto.Monto,
        evento.Monto.Moneda,
        evento.Metodo.ToString());
}
