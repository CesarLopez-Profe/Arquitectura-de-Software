using Pagos.Contracts;
using Pagos.Domain.Pagos.Eventos;
using Transito.BuildingBlocks.Application.Integracion;

namespace Pagos.Application.Integracion.Traductores;

public sealed class PagoReversadoTraductor : TraductorDeEventoDeDominio<PagoReversado>
{
    protected override string Topico => PagosTopicos.PagoReversado;

    protected override object CrearContrato(PagoReversado evento) => new PagoReversadoV1(
        evento.EventoId,
        evento.OcurrioEn,
        evento.PagoId.Valor,
        evento.Obligacion.Tipo.ToString(),
        evento.Obligacion.ObligacionId,
        evento.Monto.Monto,
        evento.Monto.Moneda,
        evento.Motivo);
}
