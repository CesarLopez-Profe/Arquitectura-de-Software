using Pagos.Domain.Pagos;
using Pagos.Domain.Pagos.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Pagos.Application.EventosDeDominio;

/// <summary>Observador local: informa la devolución del dinero.</summary>
public sealed class NotificarPagoReversadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoReversado>
{
    protected override async Task AlOcurrirAsync(PagoReversado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null) return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            "Devolución de pago",
            $"Se reversó su pago de {evento.Monto}. Motivo: {evento.Motivo}",
            CanalDeNotificacion.Email),
            cancellationToken);
    }
}
