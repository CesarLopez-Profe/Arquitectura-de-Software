using Pagos.Domain.Pagos;
using Pagos.Domain.Pagos.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Pagos.Application.EventosDeDominio;

/// <summary>Observador local: avisa que la pasarela no aprobó el cobro.</summary>
public sealed class NotificarPagoRechazadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoRechazado>
{
    protected override async Task AlOcurrirAsync(PagoRechazado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null) return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            "Pago no aprobado",
            $"La pasarela rechazó el pago: {evento.Motivo}. Puede intentarlo de nuevo.",
            CanalDeNotificacion.Email),
            cancellationToken);
    }
}
