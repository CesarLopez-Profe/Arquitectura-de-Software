using Pagos.Domain.Pagos;
using Pagos.Domain.Pagos.Eventos;
using Transito.BuildingBlocks.Application.EventosDeDominio;
using Transito.BuildingBlocks.Application.Notificaciones;

namespace Pagos.Application.EventosDeDominio;

/// <summary>Observador local: envía el recibo al correo del pagador.</summary>
public sealed class NotificarPagoConfirmadoManejador(IPagoRepository pagos, IServicioDeNotificaciones notificaciones)
    : ManejadorDeEventoDeDominio<PagoConfirmado>
{
    protected override async Task AlOcurrirAsync(PagoConfirmado evento, CancellationToken cancellationToken)
    {
        var pago = await pagos.ObtenerAsync(evento.PagoId, cancellationToken);
        if (pago is null) return;

        await notificaciones.NotificarAsync(new Notificacion(
            pago.CorreoPagador.Valor,
            $"Recibo {evento.NumeroRecibo}",
            $"Pago aprobado por {evento.Monto} ({evento.Metodo}) para {evento.Obligacion}.",
            CanalDeNotificacion.Email),
            cancellationToken);
    }
}
