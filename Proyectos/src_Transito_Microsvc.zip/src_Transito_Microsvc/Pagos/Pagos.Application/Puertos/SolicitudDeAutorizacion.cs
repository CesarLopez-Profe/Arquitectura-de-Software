namespace Pagos.Application.Puertos;

/// <summary>Lo que la aplicación le pide a la pasarela, en términos propios.</summary>
public sealed record SolicitudDeAutorizacion(
    Guid PagoId,
    decimal Monto,
    string Moneda,
    string Metodo,
    string TokenMedioDePago,
    string Descripcion);
