namespace Pagos.Application.Puertos;

/// <summary>
/// Puerto de salida hacia la pasarela de pagos (proveedor externo). La aplicación habla en su
/// propio idioma; el adaptador de infraestructura traduce al SDK del proveedor (patrón Adapter).
/// </summary>
public interface IPasarelaDePagos
{
    Task<ResultadoDeAutorizacion> AutorizarAsync(SolicitudDeAutorizacion solicitud, CancellationToken cancellationToken);
}
