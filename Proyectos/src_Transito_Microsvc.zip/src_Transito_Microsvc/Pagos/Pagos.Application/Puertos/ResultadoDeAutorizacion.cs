namespace Pagos.Application.Puertos;

/// <summary>Respuesta de la pasarela traducida al idioma de la aplicación.</summary>
public sealed record ResultadoDeAutorizacion(bool Aprobada, string? ReferenciaTransaccion, string? Motivo)
{
    public static ResultadoDeAutorizacion Aprobar(string referencia) => new(true, referencia, null);

    public static ResultadoDeAutorizacion Rechazar(string motivo) => new(false, null, motivo);
}
