namespace Pagos.Infrastructure.Pasarela.ProveedorFicticio;

/// <summary>
/// Cliente del proveedor de pagos simulado ("FakePay"). Reglas de la simulación:
/// tokens que contienen "decline" o "rechaz" se rechazan por fondos insuficientes; cargos de más
/// de 10 millones se rechazan por límite; el resto se aprueba.
/// </summary>
public sealed class FakePayClient
{
    public const long LimiteEnCentavos = 10_000_000_00;

    public Task<FakePayChargeResponse> ChargeAsync(FakePayChargeRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);

        var token = request.CardToken.ToLowerInvariant();
        FakePayChargeResponse response = token.Contains("decline") || token.Contains("rechaz")
            ? new("declined", null, "insufficient_funds")
            : request.AmountInCents > LimiteEnCentavos
                ? new("declined", null, "amount_limit_exceeded")
                : new("approved", $"FP-{Guid.NewGuid().ToString("N")[..10].ToUpperInvariant()}", null);

        return Task.FromResult(response);
    }
}
