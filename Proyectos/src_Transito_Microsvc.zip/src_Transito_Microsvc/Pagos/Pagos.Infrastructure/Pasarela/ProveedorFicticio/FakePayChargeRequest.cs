namespace Pagos.Infrastructure.Pasarela.ProveedorFicticio;

/// <summary>
/// Clase del "SDK de terceros" simulado. Está en inglés y usa centavos a propósito: así se ve
/// que el proveedor tiene su propio modelo, distinto al nuestro, y que hace falta un Adapter.
/// </summary>
public sealed record FakePayChargeRequest(string IdempotencyKey, long AmountInCents, string Currency, string CardToken, string Description);
