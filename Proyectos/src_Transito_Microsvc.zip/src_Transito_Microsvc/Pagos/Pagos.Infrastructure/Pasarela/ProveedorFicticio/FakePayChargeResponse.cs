namespace Pagos.Infrastructure.Pasarela.ProveedorFicticio;

/// <summary>Respuesta del SDK simulado: "approved" o "declined" y un código de error.</summary>
public sealed record FakePayChargeResponse(string Status, string? TransactionId, string? DeclineCode);
