using Microsoft.Extensions.Logging;
using Pagos.Application.Puertos;
using Pagos.Infrastructure.Pasarela.ProveedorFicticio;

namespace Pagos.Infrastructure.Pasarela;

/// <summary>
/// Patrón Adapter (estructural): implementa nuestro puerto <see cref="IPasarelaDePagos"/> usando el
/// SDK del proveedor (<see cref="FakePayClient"/>), cuya interfaz es incompatible (inglés, centavos,
/// estados en texto). Cambiar de proveedor = escribir otro adaptador; la aplicación no se entera.
/// </summary>
public sealed class PasarelaFakePayAdapter(FakePayClient cliente, ILogger<PasarelaFakePayAdapter> logger) : IPasarelaDePagos
{
    public async Task<ResultadoDeAutorizacion> AutorizarAsync(SolicitudDeAutorizacion solicitud, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(solicitud);

        var respuesta = await cliente.ChargeAsync(
            new FakePayChargeRequest(
                IdempotencyKey: solicitud.PagoId.ToString(),
                AmountInCents: (long)decimal.Round(solicitud.Monto * 100),
                Currency: solicitud.Moneda,
                CardToken: solicitud.TokenMedioDePago,
                Description: solicitud.Descripcion),
            cancellationToken);

        logger.LogInformation("Pasarela FakePay respondió '{Estado}' ({Detalle})",
            respuesta.Status, respuesta.TransactionId ?? respuesta.DeclineCode);

        return respuesta.Status == "approved"
            ? ResultadoDeAutorizacion.Aprobar(respuesta.TransactionId!)
            : ResultadoDeAutorizacion.Rechazar(TraducirCodigo(respuesta.DeclineCode));
    }

    private static string TraducirCodigo(string? codigo) => codigo switch
    {
        "insufficient_funds" => "Fondos insuficientes",
        "amount_limit_exceeded" => "El monto supera el límite permitido",
        _ => "Transacción rechazada por la entidad"
    };
}
