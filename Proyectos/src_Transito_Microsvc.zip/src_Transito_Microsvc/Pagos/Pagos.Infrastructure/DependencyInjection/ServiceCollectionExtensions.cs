using Microsoft.Extensions.DependencyInjection;
using Pagos.Application.Integracion.Consumidores;
using Pagos.Application.Puertos;
using Pagos.Contracts;
using Pagos.Domain.Obligaciones;
using Pagos.Domain.Pagos;
using Pagos.Domain.Servicios;
using Pagos.Infrastructure.AntiCorrupcion;
using Pagos.Infrastructure.Pasarela;
using Pagos.Infrastructure.Pasarela.ProveedorFicticio;
using Pagos.Infrastructure.Persistencia;
using Sanciones.Contracts;
using Transito.BuildingBlocks.Infrastructure.DependencyInjection;
using Transito.BuildingBlocks.Infrastructure.Simulacion;

namespace Pagos.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AgregarInfraestructuraPagos(
        this IServiceCollection services,
        EntornoDeSimulacion entorno,
        OpcionesDeMicroservicio opciones)
    {
        services.AgregarBloquesDeInfraestructura(entorno, opciones);

        // Adaptadores de los puertos del dominio y de la aplicación
        services.AddScoped<IPagoRepository, RepositorioDePagos>();
        services.AddScoped<IGeneradorNumeroRecibo, GeneradorNumeroReciboDocumental>();
        services.AddScoped<IConsultaDeObligaciones, ConsultaDeObligacionesDeSanciones>();
        services.AddSingleton<FakePayClient>();
        services.AddSingleton<IPasarelaDePagos, PasarelaFakePayAdapter>();

        // Canales de salida (sin webhooks externos: Pagos solo habla con el bus, la auditoría y el buzón)
        services.AgregarCanalesDeSalida(canales => canales
            .ConBusDeEventos()
            .ConBitacoraDeAuditoria()
            .ConBuzonDeArchivos(PagosTopicos.Todos));

        // Lo que Pagos escucha de otros contextos
        services.AgregarConsumidor<PagoDeSancionRechazadoV1, PagoDeSancionRechazadoConsumidor>(
            SancionesTopicos.PagoDeSancionRechazado);

        return services;
    }
}
