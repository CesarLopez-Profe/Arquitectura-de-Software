using Pagos.Domain.Obligaciones;
using Pagos.Domain.Pagos;
using Sanciones.Contracts;
using Transito.BuildingBlocks.Domain;
using Transito.BuildingBlocks.Infrastructure.Http;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Pagos.Infrastructure.AntiCorrupcion;

/// <summary>
/// Capa anticorrupción (ACL, patrón DDD) implementada como Adapter: llama por HTTP al
/// microservicio Sanciones y traduce su contrato (<see cref="ObligacionDeSancionV1"/>) al modelo
/// propio de Pagos (<see cref="ObligacionPorPagar"/>). Si Sanciones cambia su contrato, solo
/// cambia esta clase: el dominio de Pagos queda protegido.
/// </summary>
public sealed class ConsultaDeObligacionesDeSanciones(IClienteHttp http, ISerializador serializador)
    : IConsultaDeObligaciones
{
    public const string HostSanciones = "sanciones";

    public async Task<ObligacionPorPagar?> ObtenerAsync(
        ReferenciaObligacion referencia,
        DateTimeOffset fechaPago,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(referencia);
        if (referencia.Tipo != TipoObligacion.Sancion)
            return null;

        var ruta = $"/api/sanciones/{referencia.ObligacionId}/obligacion?fechaPago={Uri.EscapeDataString(fechaPago.ToString("O"))}";
        var respuesta = await http.EnviarAsync(HostSanciones, SolicitudHttp.Get(ruta), cancellationToken);

        if (respuesta.Codigo == 404)
            return null;
        if (!respuesta.EsExitosa || respuesta.Cuerpo is null)
            throw new InvalidOperationException($"Sanciones respondió {respuesta.Codigo} al consultar la obligación.");

        var contrato = serializador.Deserializar<ObligacionDeSancionV1>(respuesta.Cuerpo);
        return new ObligacionPorPagar(
            referencia,
            Dinero.De(contrato.ValorAPagar, contrato.Moneda),
            contrato.AdmitePago,
            $"Comparendo {contrato.NumeroComparendo}: {contrato.Descripcion}");
    }
}
