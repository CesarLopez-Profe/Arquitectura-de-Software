using Pagos.Domain.Pagos;
using Pagos.Domain.Pagos.Estados;
using Transito.BuildingBlocks.Infrastructure.Persistencia;
using Transito.BuildingBlocks.Infrastructure.Serializacion;

namespace Pagos.Infrastructure.Persistencia;

/// <summary>Adaptador del puerto <see cref="IPagoRepository"/> sobre la base documental JSON.</summary>
public sealed class RepositorioDePagos(
    BaseDeDatosDocumental baseDeDatos,
    UnidadDeTrabajoDocumental unidadDeTrabajo,
    ISerializador serializador)
    : RepositorioDocumentalBase<Pago, PagoId, PagoMemento>(baseDeDatos, unidadDeTrabajo, serializador),
      IPagoRepository
{
    protected override string Coleccion => "pagos";

    protected override string ClaveDe(PagoId id) => id.Valor.ToString();

    public Task<Pago?> ObtenerAsync(PagoId id, CancellationToken cancellationToken) =>
        ObtenerPorIdAsync(id, cancellationToken);

    /// <summary>La pregunta "¿está activo?" se delega al objeto estado (patrón State).</summary>
    public async Task<bool> ExistePagoActivoParaAsync(ReferenciaObligacion obligacion, CancellationToken cancellationToken) =>
        (await BuscarAsync(
            m => m.TipoObligacion == obligacion.Tipo
                 && m.ObligacionId == obligacion.ObligacionId
                 && EstadoDePago.Desde(m.Estado).EstaActivo,
            cancellationToken)).Count > 0;
}
