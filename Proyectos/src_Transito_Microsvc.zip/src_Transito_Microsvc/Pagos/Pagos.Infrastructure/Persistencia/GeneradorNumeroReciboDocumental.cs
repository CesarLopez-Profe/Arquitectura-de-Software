using Pagos.Domain.Pagos;
using Pagos.Domain.Servicios;
using Transito.BuildingBlocks.Infrastructure.Persistencia;

namespace Pagos.Infrastructure.Persistencia;

/// <summary>Adaptador: un consecutivo por año guardado como documento JSON.</summary>
public sealed class GeneradorNumeroReciboDocumental(GeneradorDeConsecutivos consecutivos) : IGeneradorNumeroRecibo
{
    public Task<NumeroRecibo> SiguienteAsync(int anio, CancellationToken cancellationToken) =>
        Task.FromResult(NumeroRecibo.Generar(anio, consecutivos.Siguiente($"recibos-{anio}")));
}
