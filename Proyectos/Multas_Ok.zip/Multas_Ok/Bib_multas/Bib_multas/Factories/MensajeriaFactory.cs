﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bib_multas.Clases.Mensajes;
using Bib_multas.Interfaces;
using Bib_multas.Aspectos;
using Castle.DynamicProxy;

namespace Bib_multas.Factories
{
    public class MensajeriaFactory
    {
        private readonly ProxyGenerator _proxyGenerator;
        private readonly Interceptor_Envio_Mensajes _interceptor;

        public MensajeriaFactory(Interceptor_Envio_Mensajes interceptor)
        {
            _proxyGenerator = new ProxyGenerator();
            _interceptor = interceptor;
        }

        /// <summary>
        /// Crea un medio de Email con el interceptor aplicado
        /// </summary>
        public IMensajeria CrearEmail()
        {
            var email = new Email();
            return _proxyGenerator.CreateInterfaceProxyWithTarget<IMensajeria>(
                email,
                _interceptor
            );
        }

        /// <summary>
        /// Crea un medio de SMS con el interceptor aplicado
        /// </summary>
        public IMensajeria CrearSMS()
        {
            var sms = new SMS();
            return _proxyGenerator.CreateInterfaceProxyWithTarget<IMensajeria>(
                sms,
                _interceptor
            );
        }

        /// <summary>
        /// Crea un medio de WhatsApp con el interceptor aplicado
        /// </summary>
        public IMensajeria CrearWhatsApp()
        {
            var whatsApp = new WhatsApp();
            return _proxyGenerator.CreateInterfaceProxyWithTarget<IMensajeria>(
                whatsApp,
                _interceptor
            );
        }

        /*// <summary>
        /// Crea un medio de mensajería según el tipo especificado
        /// </summary>
        /// <param name="tipo">Tipo de medio: "email", "sms" o "whatsapp"</param>
        /// <returns>Instancia del medio con interceptor aplicado</returns>
        /// */
        /// 
        public IMensajeria CrearMensajePorTipo(string tipo)
        {

            if (string.IsNullOrWhiteSpace(tipo))
            {
                throw new ArgumentException("El tipo de mensaje no puede estar vacío", nameof(tipo));
            }

            string tipoNormalizado = tipo.ToLower().Trim();

            switch (tipoNormalizado)
            {
                case "email":
                    return CrearEmail();
                case "sms":
                    return CrearSMS();
                case "whatsapp":
                    return CrearWhatsApp();
                default:
                    throw new ArgumentException(
                        $"Tipo de medio desconocido: '{tipo}'. " +
                        $"Tipos válidos: email, sms, whatsapp",
                        nameof(tipo));
            }
        }
    }

}
    

