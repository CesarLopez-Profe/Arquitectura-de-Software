﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bib_multas.Clases;

namespace Bib_multas.Interfaces
{
    public interface IMensajeria
    {
        void EnviarMensajeMulta(Conductor conductor);
    }
}
