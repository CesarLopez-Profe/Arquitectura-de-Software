﻿/*
 
    Este es un ejemplo del un interceptor de aspectos para el proyecto consola...
    Ojo con los console, el reto acá es que usted envíe el mensaje y sea capturado en la consola

 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bib_multas.Clases;
using Castle.DynamicProxy;

namespace Bib_multas.Aspectos
{
    public class Interceptor_Envio_Mensajes_Consola
    {
        public void Intercept(IInvocation llamado)
        {
            // Nombre del medio: Email, SMS o WhatsApp
            string tipoMensaje = llamado.TargetType.Name;
            
            //Si el mensaje es email, acá irá el correo sino, irá el telefono
            string destinatario = "";

            // Obtener el conductor del primer argumento del llamado
            Conductor conductor = (Conductor)llamado.Arguments[0];

            if (tipoMensaje == "Email")
                destinatario = conductor.Correo;
            else
                destinatario = conductor.Telefono.ToString();

            Console.WriteLine($"Enviando {tipoMensaje} a {destinatario}...");

            llamado.Proceed();

            Console.WriteLine($"✅ {tipoMensaje} enviado correctamente a {destinatario}");
        }
    }
}
