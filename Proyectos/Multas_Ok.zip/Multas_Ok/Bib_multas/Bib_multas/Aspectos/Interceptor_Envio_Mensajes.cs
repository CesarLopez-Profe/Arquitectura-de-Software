﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.DynamicProxy;
using Microsoft.AspNetCore.Http;//NuGet:Microsoft.AspNetCore.Http


namespace Bib_multas.Aspectos
{
    public class Interceptor_Envio_Mensajes:IInterceptor
    {
        private readonly IHttpContextAccessor _contextAccessor;

        //constructor
        public Interceptor_Envio_Mensajes(IHttpContextAccessor contextAccessor)
        {
            _contextAccessor = contextAccessor ?? throw new ArgumentNullException(nameof(contextAccessor));
        }

        public void Intercept(IInvocation invocation)
        {
            string tipoMensaje = invocation.TargetType.Name; // Email, SMS, WhatsApp
            string destinatario = invocation.Arguments[0]?.ToString() ?? "Desconocido";

            try
            {
                // Guardar contexto en HttpContext.Items para uso posterior, no se captura la excepción que genera las clases de mensajes
                if (_contextAccessor.HttpContext != null)
                {
                    _contextAccessor.HttpContext.Items["UltimoTipoMensaje"] = tipoMensaje;
                    _contextAccessor.HttpContext.Items["UltimoDestinatario"] = destinatario;
                }

                // Ejecutar el método original (lanzará la excepción)
                // La excepción se propagará al Controller para que la capture
                invocation.Proceed();
            }
            catch (Exception ex)
            {
                // Capturar el error del envío (tus clases lanzan excepciones)
                if (_contextAccessor.HttpContext != null)
                {
                    _contextAccessor.HttpContext.Items["MensajeEnviado"] = ex.Message;
                    _contextAccessor.HttpContext.Items["MensajeTipo"] = "info";
                }

                // Se debe Re-lanzar para capturar y manejar en el interceptor 
                // y que llegue al controller y en el catch de este también se atrape y se maneje
                
                throw; 
            }
        }


    }

}
