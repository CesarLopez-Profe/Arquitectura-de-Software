﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_multas.Clases.Mensajes
{
    internal class Email:Medio
    {
        public override void EnviarMensajeMulta(Conductor conductor)
        {
            throw new Exception ($"Correo electrónico con multa enviado a {conductor.Correo}");
        }
    }
}
