﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_multas.Clases.Mensajes
{
    internal abstract class Medio : Interfaces.IMensajeria
    {
        public abstract void EnviarMensajeMulta(Conductor conductor);
        
    }
}
