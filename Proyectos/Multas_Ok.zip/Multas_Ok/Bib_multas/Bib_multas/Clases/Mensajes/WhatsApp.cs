﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bib_multas.Clases.Mensajes
{
    internal class WhatsApp : Medio
    {
        public override void EnviarMensajeMulta(Conductor conductor)
        {
            throw new Exception($"Mensaje de WhatsApp enviado a {conductor.Telefono}");
        }
    }
}