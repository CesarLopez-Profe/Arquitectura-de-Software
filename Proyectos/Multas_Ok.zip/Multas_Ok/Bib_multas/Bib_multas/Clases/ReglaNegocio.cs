﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Bib_multas.Clases
{
    public static class ReglaNegocio
    {
        public static readonly ulong valor_sal_min = 1423500;
        public static readonly byte edad_min = 18;
        public static readonly ushort tot_ptos = 5000;
        public static readonly byte cant_sal_menor = 3;
        public static readonly ushort ptos_restar_menor = 1000;
        public static readonly byte cant_sal_mayor = 5;
        public static readonly byte long_min_id = 3;
        
    }
}
