﻿using AppMultas.web.Servicios;
using Bib_multas.Clases;
using Bib_multas.Factories;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Globalization;
using static Bib_multas.Clases.Mayor;
using static Bib_multas.Clases.Menor;

namespace AppMultas.web.Controllers
{
    public class MultasController : Controller
    {
        private static ConductorService _cService = new();
        private static VehiculoService _vService = new();
        private static MultaService _mService = new();
        private static MensajeriaFactory _mensajeriaFactory;


        public MultasController(ConductorService cService, VehiculoService vService, MultaService mService,
            MensajeriaFactory mensajeriaFactory)
        {
            _cService = cService;
            _vService = vService;
            _mService = mService;
            _mensajeriaFactory = mensajeriaFactory; //inyección de interfaces
        }
        public IActionResult Index()
        {
            return View(_mService.ObtenerTodas());
        }

        public IActionResult Crear() //get
        {
            ViewBag.Conductores = _cService.ObtenerTodos();
            ViewBag.Vehiculos = _vService.ObtenerTodos();
            // Para pasar los enums a la vista
            ViewBag.InfMenores = Enum.GetValues(typeof(inf_menores));
            ViewBag.InfMayores = Enum.GetValues(typeof(inf_mayores));
            
            return View();
        }

        [HttpPost]
        public IActionResult Crear(string idConductor, string placaVehiculo, string tipoMulta, string infraccion, 
            uint telefono, string correo, string tipoMensaje)
        {
            try
            {
                            
                var conductor = _cService.BuscarPorId(idConductor);
                var vehiculo = _vService.BuscarPorPlaca(placaVehiculo);
                
                Random aleat;
                Array arr_multas;
                Multa multa;
                string mensaje_anulacion;

                // Validar selección
                if (string.IsNullOrEmpty(idConductor) || string.IsNullOrEmpty(placaVehiculo) || string.IsNullOrEmpty(tipoMulta))
                {
                    ViewBag.Error = "Debe seleccionar un conductor, vehículo y tipo de multa.";
                    ViewBag.Conductores = _cService.ObtenerTodos();
                    ViewBag.Vehiculos = _vService.ObtenerTodos();
                    ViewBag.InfMenores = Enum.GetValues(typeof(inf_menores));
                    ViewBag.InfMayores = Enum.GetValues(typeof(inf_mayores));
                    return View();
                }

                if (conductor == null || vehiculo == null)
                {
                    ViewBag.Error = "Conductor o Vehículo no encontrados.";
                    ViewBag.Conductores = _cService.ObtenerTodos();
                    ViewBag.Vehiculos = _vService.ObtenerTodos();
                    ViewBag.InfMenores = Enum.GetValues(typeof(inf_menores));
                    ViewBag.InfMayores = Enum.GetValues(typeof(inf_mayores));
                    return View();
                }

                
                aleat = new Random();
                

                if (tipoMulta.Equals("Mayor"))
                {

                    // Usar la infracción seleccionada por el usuario
                    if (!string.IsNullOrEmpty(infraccion) && Enum.TryParse<inf_mayores>(infraccion, out var infMayor))
                    {
                        multa = new Mayor(conductor, vehiculo, infMayor);

                        // Anular licencia para multas mayores
                        var multaMayor = (Mayor)multa;
                        try
                        {
                            mensaje_anulacion = multaMayor.Anular_licencia();
                            
                            // Guardar el mensaje de anulación para mostrarlo
                            TempData["MensajeAnulacion"] = mensaje_anulacion;
                            TempData["TipoAnulacion"] = "warning";
                        }
                        catch (Exception exEvento)
                        {
                            TempData["MensajeAnulacion"] = exEvento.Message;
                        }
                    }
                    else
                    {
                        // Fallback al método aleatorio si no se seleccionó infracción
                        arr_multas = Enum.GetValues(typeof(inf_mayores));
                        aleat = new Random();
                        multa = new Mayor(conductor, vehiculo, (inf_mayores)arr_multas.GetValue(aleat.Next(arr_multas.Length)));
                    }
                }

                else
                {

                    // Usar la infracción seleccionada por el usuario
                    if (!string.IsNullOrEmpty(infraccion) && Enum.TryParse<inf_menores>(infraccion, out var infMenor))
                    {
                        multa = new Menor(conductor, vehiculo, infMenor);
                    }
                    else
                    {
                        // Fallback al método aleatorio si no se seleccionó infracción
                        arr_multas = Enum.GetValues(typeof(inf_menores));
                        aleat = new Random();
                        multa = new Menor(conductor, vehiculo, (inf_menores)arr_multas.GetValue(aleat.Next(arr_multas.Length)));
                    }
                }
                
                _mService.Agregar(multa);

                // ============= APLICAR ASPECTO DE MENSAJERÍA =============
                // Enviar notificación usando el medio seleccionado
                if (!string.IsNullOrEmpty(tipoMensaje))
                {
                    try
                    {
                        var medio = _mensajeriaFactory.CrearMensajePorTipo(tipoMensaje);

                        /*
                         * /// Construir el destinatario con información del conductor
                        string destinatario = string.Format("{0} (ID: {1})",
                            conductor.Nombre,
                            conductor.Id);*/

                        // Enviar mensaje (lanzará excepción con el mensaje de confirmación)
                        medio.EnviarMensajeMulta(conductor);
                    }
                    catch (Exception exMensaje)
                    {
                        // Capturar el mensaje que viene de la biblioteca
                        // Usar TempData para que el mensaje sobreviva la redirección
                        TempData["MensajeNotificacion"] = exMensaje.Message;
                        TempData["TipoMensaje"] = "success";
                    }
                }
                // =========================================================


                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                ViewBag.Conductores = _cService.ObtenerTodos();
                ViewBag.Vehiculos = _vService.ObtenerTodos();
                ViewBag.InfMenores = Enum.GetValues(typeof(inf_menores));
                ViewBag.InfMayores = Enum.GetValues(typeof(inf_mayores));
                return View();
            }
        }
    }
}
