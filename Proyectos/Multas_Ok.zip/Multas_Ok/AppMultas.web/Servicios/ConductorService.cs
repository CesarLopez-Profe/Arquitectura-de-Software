﻿using Bib_multas.Clases;
using System.IO;

namespace AppMultas.web.Servicios
{
    public class ConductorService
    {
        private readonly List<Conductor> _conductores = new();

        public void Agregar(Conductor conductor)
        {
            _conductores.Add(conductor);
        }

        public void Cargar(string rutaArchivo)
        {
            if (!File.Exists(rutaArchivo))
            {
                throw new FileNotFoundException($"No se encontró el archivo: {rutaArchivo}");
            }

            var lineas = File.ReadAllLines(rutaArchivo);

            foreach (var linea in lineas)
            {
                // Saltar líneas vacías o comentarios
                if (string.IsNullOrWhiteSpace(linea) || linea.StartsWith("#"))
                    continue;

                var datos = linea.Split('|');

                if (datos.Length != 6)
                {
                    throw new Exception($"Línea con formato incorrecto (se esperan 6 campos): {linea}");
                }

                try
                {
                    // Convertir el tipo de ID desde string
                    Conductor.tipos_id tipoId;
                    if (Enum.TryParse(datos[0].Trim(), out tipoId))
                    {
                        Agregar(new Bib_multas.Clases.Conductor(
                            tipoId,
                            datos[1].Trim(),                    // NumeroID
                            datos[2].Trim(),                    // Nombre
                            byte.Parse(datos[3].Trim()),         // Edad
                            ulong.Parse(datos[4].Trim()),        // Telefono
                            datos[5].Trim()                     // Email
                        ));
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception ($"Error procesando línea '{linea}': {ex.Message}");
                }
            }
            
        }

        public IEnumerable<Conductor> ObtenerTodos()
        {
            return _conductores;
        }

        public Conductor? BuscarPorId(string id)
        {
            return _conductores.FirstOrDefault(c => c.Id == id);
        }
    }
}



