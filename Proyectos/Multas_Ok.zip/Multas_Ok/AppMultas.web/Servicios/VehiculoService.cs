﻿using Bib_multas.Clases;
using System.IO;

namespace AppMultas.web.Servicios
{
    public class VehiculoService
    {
        private readonly List<Vehiculo> _vehiculos = new();

        public void Agregar(Vehiculo vehiculo)
        {
            _vehiculos.Add(vehiculo);
        }

        public void Cargar(string rutaArchivo)
        {
            try
            {
                if (!File.Exists(rutaArchivo))
                {
                    throw new FileNotFoundException($"No se encontró el archivo: {rutaArchivo}");
                }

                var lineas = File.ReadAllLines(rutaArchivo);

                foreach (var linea in lineas)
                {
                    // Saltar líneas vacías o comentarios
                    if (string.IsNullOrWhiteSpace(linea) || linea.StartsWith("#"))
                        continue;

                    var datos = linea.Split('|');

                    if (datos.Length != 4)
                    {
                        throw new Exception($"Línea con formato incorrecto (se esperan 4 campos): {linea}");
                        
                    }

                    try
                    {
                        _vehiculos.Add(new Vehiculo(
                            datos[0].Trim(),                    // Placa
                            datos[1].Trim(),                    // Marca
                            datos[2].Trim(),                    // Modelo
                            DateTime.Parse(datos[3].Trim())     // FechaMatricula
                        ));
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"Error procesando línea '{linea}': {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error leyendo archivo de vehículos: {ex.Message}");
                throw;
            }

        }

        public IEnumerable<Vehiculo> ObtenerTodos()
        {
            return _vehiculos;
        }

        public Vehiculo? BuscarPorPlaca(string placa)
        {
            return _vehiculos.FirstOrDefault(v => v.Placa == placa);
        }

        public bool Existe(string placa)
        {
            return _vehiculos.Any(v => v.Placa == placa);
        }
    }
}
