var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

Console.WriteLine("========================================");
Console.WriteLine("SERVICIO DE PAGOS INICIADO");
Console.WriteLine("========================================");
Console.WriteLine($"URL: http://localhost:5003");
Console.WriteLine($"Swagger: http://localhost:5003/swagger");
Console.WriteLine("========================================");

app.Run();