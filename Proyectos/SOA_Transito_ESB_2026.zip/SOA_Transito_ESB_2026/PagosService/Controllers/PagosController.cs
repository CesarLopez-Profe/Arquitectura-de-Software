﻿using Contracts.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace PagosService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PagosController : ControllerBase
{
    private static List<PagoDTO> _pagos = new List<PagoDTO>();
    private readonly ILogger<PagosController> _logger;

    public PagosController(ILogger<PagosController> logger)
    {
        _logger = logger;

        if (!_pagos.Any())
        {
            _pagos = new List<PagoDTO>
            {
                new PagoDTO {
                    Id = 1,
                    NumeroRecibo = "REC-2024-001",
                    SancionId = 1,
                    Concepto = "Multa",
                    Monto = 350000,
                    FechaPago = DateTime.Now,
                    MetodoPago = "Tarjeta",
                    Estado = "Confirmado"
                }
            };
        }
    }

    [HttpGet]
    public ActionResult<IEnumerable<PagoDTO>> GetAll() => Ok(_pagos);

    [HttpGet("{id}")]
    public ActionResult<PagoDTO> GetById(int id)
    {
        var pago = _pagos.FirstOrDefault(p => p.Id == id);
        if (pago == null) return NotFound();
        return Ok(pago);
    }

    [HttpPost]
    public ActionResult<PagoDTO> Create(PagoDTO pago)
    {
        pago.Id = _pagos.Max(p => p.Id) + 1;
        pago.NumeroRecibo = $"REC-{DateTime.Now.Year}-{pago.Id:D3}";
        pago.FechaPago = DateTime.Now;
        pago.Estado = "Confirmado";
        _pagos.Add(pago);
        return CreatedAtAction(nameof(GetById), new { id = pago.Id }, pago);
    }
}