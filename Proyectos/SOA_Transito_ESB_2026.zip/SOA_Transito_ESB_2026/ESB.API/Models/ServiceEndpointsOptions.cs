namespace ESB.API.Models;

public class ServiceEndpointsOptions
{
    public const string SectionName = "ServiceEndpoints";

    public string Licencias { get; set; } = string.Empty;
    public string Sanciones { get; set; } = string.Empty;
    public string Pagos { get; set; } = string.Empty;
}