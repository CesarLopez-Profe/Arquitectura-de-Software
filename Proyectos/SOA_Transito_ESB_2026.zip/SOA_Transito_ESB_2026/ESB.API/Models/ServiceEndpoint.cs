﻿namespace ESB.API.Models
{
    public class ServiceEndpoint
    {
        public string ServiceName { get; set; } = string.Empty;
        public string BaseUrl { get; set; } = string.Empty;
        public bool IsAvailable { get; set; } = true;
    }
}
