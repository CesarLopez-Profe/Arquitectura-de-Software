﻿namespace ESB.API.Models
{
    public class RoutingRule
    {
        public string FromPath { get; set; } = string.Empty;
        public string ToService { get; set; } = string.Empty;
        public string ToPath { get; set; } = string.Empty;
    }
}
