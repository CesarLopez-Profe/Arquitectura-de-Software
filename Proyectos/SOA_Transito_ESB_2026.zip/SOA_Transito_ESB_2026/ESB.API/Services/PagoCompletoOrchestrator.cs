using Contracts.DTOs;
using ESB.API.Services.Clients;

namespace ESB.API.Services;

public class PagoCompletoOrchestrator(
    IPagosClient pagosClient,
    ISancionesClient sancionesClient,
    ILicenciasClient licenciasClient,
    ILogger<PagoCompletoOrchestrator> logger) : IPagoCompletoOrchestrator
{
    public async Task<PagoDTO> ProcesarAsync(
        PagoCompletoRequest request,
        CancellationToken cancellationToken)
    {
        var pago = await pagosClient.RegistrarAsync(
            new PagoDTO
            {
                SancionId = request.SancionId,
                Monto = request.Monto,
                MetodoPago = request.MetodoPago,
                Concepto = "Pago de multa"
            },
            cancellationToken);

        await sancionesClient.PagarAsync(request.SancionId, cancellationToken);

        if (request.LicenciaId.HasValue && request.Puntos > 0)
        {
            await licenciasClient.DescontarPuntosAsync(
                request.LicenciaId.Value,
                request.Puntos,
                cancellationToken);
        }

        logger.LogInformation(
            "Pago completo procesado para la sanción {SancionId}",
            request.SancionId);

        return pago;
    }
}