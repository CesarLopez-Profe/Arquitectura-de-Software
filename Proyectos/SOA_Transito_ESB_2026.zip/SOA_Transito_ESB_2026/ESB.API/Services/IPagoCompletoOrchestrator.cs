using Contracts.DTOs;

namespace ESB.API.Services;

public interface IPagoCompletoOrchestrator
{
    Task<PagoDTO> ProcesarAsync(
        PagoCompletoRequest request,
        CancellationToken cancellationToken);
}

public class PagoCompletoRequest
{
    public int SancionId { get; set; }
    public decimal Monto { get; set; }
    public string MetodoPago { get; set; } = string.Empty;
    public int? LicenciaId { get; set; }
    public int Puntos { get; set; }
}