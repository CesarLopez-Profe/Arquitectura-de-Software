﻿using System.Text;
using ESB.API.Models;
using Microsoft.Extensions.Options;

namespace ESB.API.Services
{
    public class RoutingService : IRoutingService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<RoutingService> _logger;
        private readonly Dictionary<string, ServiceEndpoint> _serviceRegistry;

        public RoutingService(
            IHttpClientFactory httpClientFactory,
            ILogger<RoutingService> logger,
            IOptions<ServiceEndpointsOptions> options)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            var endpoints = options.Value;

            _serviceRegistry = new Dictionary<string, ServiceEndpoint>
            {
                ["licencias"] = new ServiceEndpoint
                {
                    ServiceName = "licencias",
                    BaseUrl = endpoints.Licencias
                },
                ["sanciones"] = new ServiceEndpoint
                {
                    ServiceName = "sanciones",
                    BaseUrl = endpoints.Sanciones
                },
                ["pagos"] = new ServiceEndpoint
                {
                    ServiceName = "pagos",
                    BaseUrl = endpoints.Pagos
                }
            };
        }

        public async Task<HttpResponseMessage> RouteRequestAsync(
            HttpRequest originalRequest,
            string serviceName,
            string path)
        {
            try
            {
                if (!_serviceRegistry.ContainsKey(serviceName.ToLower()))
                {
                    _logger.LogWarning($"Servicio {serviceName} no encontrado");
                    return new HttpResponseMessage(System.Net.HttpStatusCode.NotFound);
                }

                var endpoint = _serviceRegistry[serviceName.ToLower()];
                var targetUrl = $"{endpoint.BaseUrl}{path}";

                _logger.LogInformation($"ESB enrutando a: {targetUrl}");

                var client = _httpClientFactory.CreateClient();
                var requestMessage = new HttpRequestMessage(
                    new HttpMethod(originalRequest.Method),
                    targetUrl);

                if (originalRequest.Body != null)
                {
                    var body = await new StreamReader(originalRequest.Body).ReadToEndAsync();
                    requestMessage.Content = new StringContent(body, Encoding.UTF8, "application/json");
                }

                return await client.SendAsync(requestMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en enrutamiento");
                return new HttpResponseMessage(System.Net.HttpStatusCode.InternalServerError);
            }
        }

    }
}
