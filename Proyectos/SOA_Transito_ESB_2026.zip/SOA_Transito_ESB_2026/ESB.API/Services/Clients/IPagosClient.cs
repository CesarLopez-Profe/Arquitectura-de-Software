using Contracts.DTOs;

namespace ESB.API.Services.Clients;

public interface IPagosClient
{
    Task<PagoDTO> RegistrarAsync(
        PagoDTO pago,
        CancellationToken cancellationToken);
}