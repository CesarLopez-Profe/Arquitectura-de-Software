namespace ESB.API.Services.Clients;

public interface ILicenciasClient
{
    Task DescontarPuntosAsync(
        int licenciaId,
        int puntos,
        CancellationToken cancellationToken);
}