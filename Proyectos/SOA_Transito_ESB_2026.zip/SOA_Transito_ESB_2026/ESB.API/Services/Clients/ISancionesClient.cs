namespace ESB.API.Services.Clients;

public interface ISancionesClient
{
    Task PagarAsync(int sancionId, CancellationToken cancellationToken);
}