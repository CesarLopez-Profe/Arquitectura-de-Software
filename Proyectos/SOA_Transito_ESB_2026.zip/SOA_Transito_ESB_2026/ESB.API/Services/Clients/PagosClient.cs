using System.Net.Http.Json;
using Contracts.DTOs;

namespace ESB.API.Services.Clients;

public class PagosClient(HttpClient httpClient) : IPagosClient
{
    public async Task<PagoDTO> RegistrarAsync(
        PagoDTO pago,
        CancellationToken cancellationToken)
    {
        using var response = await httpClient.PostAsJsonAsync(
            "api/pagos",
            pago,
            cancellationToken);

        await EnsureSuccessAsync(response);
        return await response.Content.ReadFromJsonAsync<PagoDTO>(cancellationToken)
            ?? throw new HttpRequestException("El servicio de pagos devolvió una respuesta vacía.");
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
            return;

        var detail = await response.Content.ReadAsStringAsync();
        throw new HttpRequestException(
            $"El servicio de pagos respondió {(int)response.StatusCode}: {detail}");
    }
}