namespace ESB.API.Services.Clients;

public class SancionesClient(HttpClient httpClient) : ISancionesClient
{
    public async Task PagarAsync(int sancionId, CancellationToken cancellationToken)
    {
        using var response = await httpClient.PutAsync(
            $"api/sanciones/{sancionId}/pagar",
            null,
            cancellationToken);

        await EnsureSuccessAsync(response);
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
            return;

        var detail = await response.Content.ReadAsStringAsync();
        throw new HttpRequestException(
            $"El servicio de sanciones respondió {(int)response.StatusCode}: {detail}");
    }
}