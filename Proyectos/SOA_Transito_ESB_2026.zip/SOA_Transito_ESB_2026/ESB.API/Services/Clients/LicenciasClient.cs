namespace ESB.API.Services.Clients;

public class LicenciasClient(HttpClient httpClient) : ILicenciasClient
{
    public async Task DescontarPuntosAsync(
        int licenciaId,
        int puntos,
        CancellationToken cancellationToken)
    {
        using var response = await httpClient.PutAsync(
            $"api/licencias/{licenciaId}/descontar-puntos/{puntos}",
            null,
            cancellationToken);

        await EnsureSuccessAsync(response);
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
            return;

        var detail = await response.Content.ReadAsStringAsync();
        throw new HttpRequestException(
            $"El servicio de licencias respondió {(int)response.StatusCode}: {detail}");
    }
}