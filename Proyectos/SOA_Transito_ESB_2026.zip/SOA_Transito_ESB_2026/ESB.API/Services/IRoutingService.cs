﻿using ESB.API.Models;
namespace ESB.API.Services
{
    public interface IRoutingService
    {
        Task<HttpResponseMessage> RouteRequestAsync(
            HttpRequest originalRequest,
            string serviceName,
            string path);

    }
}
