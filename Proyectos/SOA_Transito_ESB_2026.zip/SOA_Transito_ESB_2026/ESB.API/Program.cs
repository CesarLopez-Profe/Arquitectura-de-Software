﻿using ESB.API.Services;
using ESB.API.Services.Clients;
using ESB.API.Models;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "ESB - Oficina de Tránsito", Version = "v1" });
});

builder.Services.Configure<ServiceEndpointsOptions>(
    builder.Configuration.GetSection(ServiceEndpointsOptions.SectionName));
builder.Services.AddHttpClient();
builder.Services.AddSingleton<IRoutingService, RoutingService>();
builder.Services.AddHttpClient<IPagosClient, PagosClient>((serviceProvider, client) =>
{
    var endpoints = serviceProvider.GetRequiredService<IOptions<ServiceEndpointsOptions>>().Value;
    client.BaseAddress = new Uri($"{endpoints.Pagos.TrimEnd('/')}/");
});
builder.Services.AddHttpClient<ISancionesClient, SancionesClient>((serviceProvider, client) =>
{
    var endpoints = serviceProvider.GetRequiredService<IOptions<ServiceEndpointsOptions>>().Value;
    client.BaseAddress = new Uri($"{endpoints.Sanciones.TrimEnd('/')}/");
});
builder.Services.AddHttpClient<ILicenciasClient, LicenciasClient>((serviceProvider, client) =>
{
    var endpoints = serviceProvider.GetRequiredService<IOptions<ServiceEndpointsOptions>>().Value;
    client.BaseAddress = new Uri($"{endpoints.Licencias.TrimEnd('/')}/");
});
builder.Services.AddScoped<IPagoCompletoOrchestrator, PagoCompletoOrchestrator>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

Console.WriteLine("========================================");
Console.WriteLine("ESB - ENTERPRISE SERVICE BUS");
Console.WriteLine("========================================");
Console.WriteLine($"URL: http://localhost:5010");
Console.WriteLine($"Swagger: http://localhost:5010/swagger");
Console.WriteLine("========================================");
Console.WriteLine("Servicios registrados:");
Console.WriteLine("  - Licencias → http://localhost:5001");
Console.WriteLine("  - Sanciones → http://localhost:5002");
Console.WriteLine("  - Pagos     → http://localhost:5003");
Console.WriteLine("========================================");

app.Run();