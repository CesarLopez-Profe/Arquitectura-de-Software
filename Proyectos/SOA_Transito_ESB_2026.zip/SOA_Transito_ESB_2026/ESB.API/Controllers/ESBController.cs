﻿using ESB.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace ESB.API.Controllers;

[ApiController]
[Route("api/v1/esb")]
public class ESBController : ControllerBase
{
    private readonly IRoutingService _routingService;
    private readonly IPagoCompletoOrchestrator _orchestrator;
    private readonly ILogger<ESBController> _logger;

    public ESBController(
        IRoutingService routingService,
        IPagoCompletoOrchestrator orchestrator,
        ILogger<ESBController> logger)
    {
        _routingService = routingService;
        _orchestrator = orchestrator;
        _logger = logger;
    }

    [Route("{service}/{**catchAll}")]
    public async Task<IActionResult> RouteToService(string service, string? catchAll)
    {
        _logger.LogInformation($"ESB recibió: {service}/{catchAll}");

        var path = $"/{catchAll ?? ""}";
        var response = await _routingService.RouteRequestAsync(Request, service, path);

        var content = await response.Content.ReadAsStringAsync();
        return StatusCode((int)response.StatusCode, content);
    }

    [HttpPost("orquestar/pago-completo")]
    public async Task<IActionResult> OrquestarPagoCompleto(
        [FromBody] PagoCompletoRequest request,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Orquestando pago completo");

        try
        {
            var pago = await _orchestrator.ProcesarAsync(request, cancellationToken);

            return Ok(new
            {
                Mensaje = "Pago procesado exitosamente vía ESB",
                Fecha = DateTime.Now,
                TransaccionId = Guid.NewGuid(),
                Pago = pago
            });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Un servicio remoto rechazó el pago completo");
            return StatusCode(502, new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en orquestación");
            return StatusCode(500, new { error = "Error en proceso de pago" });
        }
    }
}
