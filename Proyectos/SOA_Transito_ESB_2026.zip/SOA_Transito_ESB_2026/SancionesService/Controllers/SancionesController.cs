﻿using Contracts.DTOs;
using Microsoft.AspNetCore.Mvc;
namespace SancionesService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SancionesController : ControllerBase
    {
        private static List<SancionDTO> _sanciones = new List<SancionDTO>();
        private readonly ILogger<SancionesController> _logger;

        public SancionesController(ILogger<SancionesController> logger)
        {
            _logger = logger;

            if (!_sanciones.Any())
            {
                _sanciones = new List<SancionDTO>
            {
                new SancionDTO {
                    Id = 1,
                    NumeroComparendo = "COM-2024-001",
                    ConductorId = 1,
                    PlacaVehiculo = "ABC123",
                    FechaInfraccion = new DateTime(2024, 1, 15),
                    TipoInfraccion = "Exceso de velocidad",
                    ValorMulta = 350000,
                    PuntosDescontar = 5,
                    Estado = "Pendiente"
                },
                new SancionDTO {
                    Id = 2,
                    NumeroComparendo = "COM-2024-002",
                    ConductorId = 2,
                    PlacaVehiculo = "DEF456",
                    FechaInfraccion = new DateTime(2024, 2, 20),
                    TipoInfraccion = "SOAT vencido",
                    ValorMulta = 450000,
                    PuntosDescontar = 0,
                    Estado = "Pendiente"
                }
            };
            }
        }

        [HttpGet]
        public ActionResult<IEnumerable<SancionDTO>> GetAll() => Ok(_sanciones);

        [HttpGet("{id}")]
        public ActionResult<SancionDTO> GetById(int id)
        {
            var sancion = _sanciones.FirstOrDefault(s => s.Id == id);
            if (sancion == null) return NotFound();
            return Ok(sancion);
        }

        [HttpGet("conductor/{conductorId}")]
        public ActionResult<IEnumerable<SancionDTO>> GetByConductor(int conductorId)
        {
            var sanciones = _sanciones.Where(s => s.ConductorId == conductorId).ToList();
            return Ok(sanciones);
        }

        [HttpPost]
        public ActionResult<SancionDTO> Create(SancionDTO sancion)
        {
            sancion.Id = _sanciones.Max(s => s.Id) + 1;
            sancion.NumeroComparendo = $"COM-{DateTime.Now.Year}-{sancion.Id:D3}";
            sancion.FechaInfraccion = DateTime.Now;
            sancion.Estado = "Pendiente";
            _sanciones.Add(sancion);
            return CreatedAtAction(nameof(GetById), new { id = sancion.Id }, sancion);
        }

        [HttpPut("{id}/pagar")]
        public IActionResult Pagar(int id)
        {
            var sancion = _sanciones.FirstOrDefault(s => s.Id == id);
            if (sancion == null) return NotFound();
            sancion.Estado = "Pagada";
            return Ok(sancion);
        }
    }
}
