﻿using Contracts.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace LicenciasService.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class LicenciasController : ControllerBase
    {
        private static List<LicenciaDTO> _licencias = new List<LicenciaDTO>();
        private readonly ILogger<LicenciasController> _logger;

        public LicenciasController(ILogger<LicenciasController> logger)
        {
            _logger = logger;

            if (!_licencias.Any())
            {
                _licencias = new List<LicenciaDTO>
            {
                new LicenciaDTO {
                    Id = 1,
                    ConductorId = 1,
                    NumeroLicencia = "LIC-2024-001",
                    Categoria = "B1",
                    FechaExpedicion = new DateTime(2024, 1, 15),
                    FechaVencimiento = new DateTime(2030, 1, 15),
                    Estado = "Vigente",
                    PuntosDisponibles = 30
                },
                new LicenciaDTO {
                    Id = 2,
                    ConductorId = 2,
                    NumeroLicencia = "LIC-2024-002",
                    Categoria = "A2",
                    FechaExpedicion = new DateTime(2024, 2, 20),
                    FechaVencimiento = new DateTime(2030, 2, 20),
                    Estado = "Vigente",
                    PuntosDisponibles = 25
                }
            };
            }
        }

        [HttpGet]
        public ActionResult<IEnumerable<LicenciaDTO>> GetAll()
        {
            _logger.LogInformation("Obteniendo todas las licencias");
            return Ok(_licencias);
        }

        [HttpGet("{id}")]
        public ActionResult<LicenciaDTO> GetById(int id)
        {
            var licencia = _licencias.FirstOrDefault(l => l.Id == id);
            if (licencia == null)
                return NotFound();
            return Ok(licencia);
        }

        [HttpGet("conductor/{conductorId}")]
        public ActionResult<IEnumerable<LicenciaDTO>> GetByConductor(int conductorId)
        {
            var licencias = _licencias.Where(l => l.ConductorId == conductorId).ToList();
            return Ok(licencias);
        }

        [HttpPost]
        public ActionResult<LicenciaDTO> Create(LicenciaDTO licencia)
        {
            licencia.Id = _licencias.Max(l => l.Id) + 1;
            licencia.FechaExpedicion = DateTime.Now;
            _licencias.Add(licencia);
            return CreatedAtAction(nameof(GetById), new { id = licencia.Id }, licencia);
        }

        [HttpPut("{id}/descontar-puntos/{puntos}")]
        public IActionResult DescontarPuntos(int id, int puntos)
        {
            var licencia = _licencias.FirstOrDefault(l => l.Id == id);
            if (licencia == null)
                return NotFound();

            if (licencia.PuntosDisponibles < puntos)
                return BadRequest("Puntos insuficientes");

            licencia.PuntosDisponibles -= puntos;
            return Ok(licencia);
        }
    }
}
