﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts.DTOs
{
    public class ConductorDTO
    {
        public int Id { get; set; }
        public string NumeroIdentificacion { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public string Direccion { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime FechaNacimiento { get; set; }
        public string CategoriaLicencia { get; set; } = string.Empty;
    }
}
