﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts.DTOs
{
    public class VehiculoDTO
    {
        public int Id { get; set; }
        public string Placa { get; set; } = string.Empty;
        public string Marca { get; set; } = string.Empty;
        public string Modelo { get; set; } = string.Empty;
        public int Anio { get; set; }
        public string Color { get; set; } = string.Empty;
        public int PropietarioId { get; set; }
        public bool SoatVigente { get; set; }
    }
}
