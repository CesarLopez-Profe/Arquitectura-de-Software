﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts.DTOs
{
    public class PagoDTO
    {
        public int Id { get; set; }
        public string NumeroRecibo { get; set; } = string.Empty;
        public int? SancionId { get; set; }
        public int? LicenciaId { get; set; }
        public string Concepto { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public DateTime FechaPago { get; set; }
        public string MetodoPago { get; set; } = string.Empty;
        public string Estado { get; set; } = "Pendiente";
    }
}
