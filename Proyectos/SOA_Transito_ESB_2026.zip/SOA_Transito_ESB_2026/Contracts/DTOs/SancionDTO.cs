﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts.DTOs
{
    public class SancionDTO
    {
        public int Id { get; set; }
        public string NumeroComparendo { get; set; } = string.Empty;
        public int ConductorId { get; set; }
        public string PlacaVehiculo { get; set; } = string.Empty;
        public DateTime FechaInfraccion { get; set; }
        public string TipoInfraccion { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string Lugar { get; set; } = string.Empty;
        public decimal ValorMulta { get; set; }
        public int PuntosDescontar { get; set; }
        public string Estado { get; set; } = "Pendiente";
    }
}
