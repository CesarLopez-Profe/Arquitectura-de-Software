﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts.DTOs
{
    public class LicenciaDTO
    {
        public int Id { get; set; }
        public int ConductorId { get; set; }
        public string NumeroLicencia { get; set; } = string.Empty;
        public string Categoria { get; set; } = string.Empty;
        public DateTime FechaExpedicion { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public string Estado { get; set; } = "Vigente";
        public int PuntosDisponibles { get; set; } = 30;
        public string Restricciones { get; set; } = string.Empty;
    }
}
