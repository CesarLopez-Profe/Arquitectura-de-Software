﻿using System.Text;
using System.Text.Json;
using Contracts.DTOs;

namespace ClienteConsola
{
    internal class Program
    {
        static readonly HttpClient client = new HttpClient();
        static readonly string esbUrl = "http://localhost:5010";

        static async Task Main(string[] args)
        {
            Console.WriteLine("========================================");
            Console.WriteLine("🏛️  CLIENTE SOA CON ESB - OFICINA DE TRÁNSITO");
            Console.WriteLine("========================================");

            bool salir = false;
            while (!salir)
            {
                MostrarMenu();

                Console.Write("\nSeleccione una opción: ");
                string? opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        await VerLicencias();
                        break;
                    case "2":
                        await VerSanciones();
                        break;
                    case "3":
                        await RegistrarSancion();
                        break;
                    case "4":
                        await PagarSancionConESB();
                        break;
                    case "5":
                        salir = true;
                        Console.WriteLine("\n👋 ¡Hasta luego!");
                        break;
                    default:
                        Console.WriteLine("\n❌ Opción no válida");
                        break;
                }

                if (!salir)
                {
                    Console.WriteLine("\nPresione ENTER para continuar...");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }

        static void MostrarMenu()
        {
            Console.WriteLine("\n=== MENÚ PRINCIPAL ===");
            Console.WriteLine("1. 📋 Ver licencias (vía ESB)");
            Console.WriteLine("2. ⚠️  Ver sanciones (vía ESB)");
            Console.WriteLine("3. 📝 Registrar sanción (vía ESB)");
            Console.WriteLine("4. 💰 Pagar sanción con orquestación ESB");
            Console.WriteLine("5. 🚪 Salir");
        }

        static async Task VerLicencias()
        {
            try
            {
                Console.WriteLine("\n--- CONSULTANDO LICENCIAS VÍA ESB ---");
                var response = await client.GetAsync($"{esbUrl}/api/v1/esb/licencias/api/licencias");

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var licencias = JsonSerializer.Deserialize<List<LicenciaDTO>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    if (licencias == null || licencias.Count == 0)
                    {
                        Console.WriteLine("No hay licencias registradas");
                        return;
                    }

                    foreach (var l in licencias)
                    {
                        Console.WriteLine($"ID: {l.Id} | #{l.NumeroLicencia} | Conductor: {l.ConductorId} | Estado: {l.Estado} | Puntos: {l.PuntosDisponibles}");
                    }
                }
                else
                {
                    Console.WriteLine($"❌ Error: {response.StatusCode}");
                    var error = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Detalle: {error}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error de conexión: {ex.Message}");
            }
        }

        static async Task VerSanciones()
        {
            try
            {
                Console.WriteLine("\n--- CONSULTANDO SANCIONES VÍA ESB ---");
                var response = await client.GetAsync($"{esbUrl}/api/v1/esb/sanciones/api/sanciones");

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var sanciones = JsonSerializer.Deserialize<List<SancionDTO>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    if (sanciones == null || sanciones.Count == 0)
                    {
                        Console.WriteLine("No hay sanciones registradas");
                        return;
                    }

                    foreach (var s in sanciones)
                    {
                        string icono = s.Estado switch
                        {
                            "Pagada" => "✅",
                            "Pendiente" => "⏳",
                            "Apelada" => "⚖️",
                            _ => "❓"
                        };

                        Console.WriteLine($"{icono} Comparendo: {s.NumeroComparendo} | {s.TipoInfraccion} | ${s.ValorMulta:N0} | {s.Estado}");
                    }
                }
                else
                {
                    Console.WriteLine($"❌ Error: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error de conexión: {ex.Message}");
            }
        }

        static async Task RegistrarSancion()
        {
            try
            {
                Console.WriteLine("\n--- REGISTRAR SANCIÓN VÍA ESB ---");

                Console.Write("ID del conductor: ");
                if (!int.TryParse(Console.ReadLine(), out int conductorId))
                {
                    Console.WriteLine("❌ ID inválido");
                    return;
                }

                Console.Write("Placa del vehículo: ");
                string? placa = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(placa))
                {
                    Console.WriteLine("❌ Placa requerida");
                    return;
                }

                Console.Write("Tipo de infracción: ");
                string? tipo = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(tipo))
                {
                    Console.WriteLine("❌ Tipo de infracción requerido");
                    return;
                }

                Console.Write("Descripción: ");
                string? descripcion = Console.ReadLine();

                Console.Write("Valor de la multa: $");
                if (!decimal.TryParse(Console.ReadLine(), out decimal valor))
                {
                    Console.WriteLine("❌ Valor inválido");
                    return;
                }

                Console.Write("Puntos a descontar (0 si no aplica): ");
                if (!int.TryParse(Console.ReadLine(), out int puntos))
                {
                    puntos = 0;
                }

                var nuevaSancion = new
                {
                    ConductorId = conductorId,
                    PlacaVehiculo = placa,
                    TipoInfraccion = tipo,
                    Descripcion = descripcion ?? "",
                    Lugar = "Vía pública",
                    ValorMulta = valor,
                    PuntosDescontar = puntos
                };

                var json = JsonSerializer.Serialize(nuevaSancion);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                Console.WriteLine("\n📤 Enviando al ESB...");
                var response = await client.PostAsync($"{esbUrl}/api/v1/esb/sanciones/api/sanciones", content);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = await response.Content.ReadAsStringAsync();
                    var sancionCreada = JsonSerializer.Deserialize<SancionDTO>(responseJson,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    Console.WriteLine($"\n✅ SANCIÓN REGISTRADA EXITOSAMENTE");
                    Console.WriteLine($"📄 Número de comparendo: {sancionCreada?.NumeroComparendo}");
                    Console.WriteLine($"💰 Valor: ${sancionCreada?.ValorMulta:N0}");
                    Console.WriteLine($"⚠️  Puntos: {sancionCreada?.PuntosDescontar}");
                }
                else
                {
                    Console.WriteLine($"❌ Error al registrar: {response.StatusCode}");
                    var error = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Detalle: {error}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }

        static async Task PagarSancionConESB()
        {
            try
            {
                Console.WriteLine("\n--- PAGAR SANCIÓN CON ORQUESTACIÓN ESB ---");

                Console.Write("ID de la sanción a pagar: ");
                if (!int.TryParse(Console.ReadLine(), out int sancionId))
                {
                    Console.WriteLine("❌ ID inválido");
                    return;
                }

                Console.Write("Monto a pagar: $");
                if (!decimal.TryParse(Console.ReadLine(), out decimal monto))
                {
                    Console.WriteLine("❌ Monto inválido");
                    return;
                }

                Console.Write("Método de pago (Efectivo/Tarjeta/Transferencia): ");
                string? metodo = Console.ReadLine() ?? "Efectivo";

                Console.Write("¿Descontar puntos de licencia? (s/n): ");
                bool descontarPuntos = Console.ReadLine()?.ToLower() == "s";

                int? licenciaId = null;
                int puntos = 0;

                if (descontarPuntos)
                {
                    Console.Write("ID de la licencia: ");
                    if (int.TryParse(Console.ReadLine(), out int idLicencia))
                    {
                        licenciaId = idLicencia;

                        Console.Write("Puntos a descontar: ");
                        int.TryParse(Console.ReadLine(), out puntos);
                    }
                }

                var request = new
                {
                    SancionId = sancionId,
                    Monto = monto,
                    MetodoPago = metodo,
                    LicenciaId = licenciaId,
                    Puntos = puntos
                };

                var json = JsonSerializer.Serialize(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                Console.WriteLine("\n📤 Enviando al ESB para orquestación...");
                var response = await client.PostAsync($"{esbUrl}/api/v1/esb/orquestar/pago-completo", content);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = await response.Content.ReadAsStringAsync();
                    var resultado = JsonSerializer.Deserialize<JsonElement>(responseJson);

                    Console.WriteLine($"\n✅ {resultado.GetProperty("mensaje")}");
                    Console.WriteLine($"🆔 Transacción ID: {resultado.GetProperty("transaccionId")}");
                    Console.WriteLine($"📅 Fecha: {resultado.GetProperty("fecha")}");
                }
                else
                {
                    Console.WriteLine($"❌ Error en orquestación: {response.StatusCode}");
                    var error = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Detalle: {error}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }
    }
}