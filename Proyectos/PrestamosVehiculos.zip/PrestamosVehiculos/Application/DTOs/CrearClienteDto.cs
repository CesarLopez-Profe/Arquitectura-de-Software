﻿namespace PrestamosVehiculos.Application.DTOs
{
    public class CrearClienteDto
    {
        public string Nombre { get; set; }
        public int HistorialCrediticio { get; set; }
    }
}
